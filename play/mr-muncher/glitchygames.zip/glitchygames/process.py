"""Child processes: ``run_command`` and ``start_command``, the engine's child-process launchers.

``run_command`` waits for its child: used by the determinism audit's replays
(glitchygames/replay/audit.py), a watched replay's restarts (glitchygames/replay/rebuild.py),
the replay pytest plugin (glitchygames/testing/replays.py) and the driver comparison's tools
(scripts/build_sdl_x11.py, scripts/driver_configurations.py). ``start_command`` does not: the test
suite's driver comparison (tests/driver_comparison.py) runs the suite on the native driver
alongside the dummy run, and ``stop_command`` ends that child with every process it started.
Children get an argument list, never a shell, with the environment in place before the child's
interpreter starts.

The engine's child commands are its own command line with options changed, and the helpers here
are the one way they are changed (``without_option``, ``with_options_appended``): options are
added after the command's options and before any bare ``--``, after which nothing is an option.

This module is a leaf: it imports only the standard library (no engine, no pygame), so the pytest
plugin can import it at configuration time.
"""

from __future__ import annotations

import os
import signal
import subprocess  # ruff: ignore[suspicious-subprocess-import] — runs the engine's own game commands (argument list, no shell)
import sys
from enum import StrEnum
from typing import TYPE_CHECKING, TextIO

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from pathlib import Path

# What run_command raises for a child that outlives its timeout (subprocess's own exception,
# named here so callers need not import subprocess)
TimeoutExpired = subprocess.TimeoutExpired
# What run_command returns (subprocess's own class, named here for callers' annotations)
CompletedProcess = subprocess.CompletedProcess
# What start_command returns (subprocess's own class, named here for callers' annotations)
RunningProcess = subprocess.Popen
# How long stop_command lets a child end on its own before killing it
STOP_GRACE_SECONDS = 10.0


class OutputCapture(StrEnum):
    """What ``run_command`` does with a child's standard output and error.

    Attributes:
        NONE: Neither is captured: the child writes to this process's.
        TOGETHER: Both are captured together, in the result's ``stdout``.
        APART: Each is captured on its own, in ``stdout`` and ``stderr`` (a child whose
            standard output is a listing: ``glitchygames unmeasured``'s).

    """

    NONE = 'none'
    TOGETHER = 'together'
    APART = 'apart'


# The subprocess settings (stdout, stderr) that make each capture
OUTPUT_STREAMS: dict[OutputCapture, tuple[int | None, int | None]] = {
    OutputCapture.NONE: (None, None),
    OutputCapture.TOGETHER: (subprocess.PIPE, subprocess.STDOUT),
    OutputCapture.APART: (subprocess.PIPE, subprocess.PIPE),
}
# Arguments after a bare -- are not options: appended options go before it
END_OF_OPTIONS = '--'


def split_at_end_of_options(*, arguments: Sequence[str]) -> tuple[list[str], list[str]]:
    """Split a command line before its first bare ``--``.

    Args:
        arguments: A command line.

    Returns:
        The arguments before the ``--``, and the ``--`` with everything after it (empty when
        there is none).

    """
    if END_OF_OPTIONS in arguments:
        index = list(arguments).index(END_OF_OPTIONS)
        return list(arguments[:index]), list(arguments[index:])
    return list(arguments), []


def without_option(*, arguments: Sequence[str], option: str, takes_value: bool) -> list[str]:
    """Return ``arguments`` without any occurrence of a long option before a bare ``--``.

    Args:
        arguments: A command line.
        option: The option, e.g. ``--replay-trace``.
        takes_value: True for an option given as ``option VALUE`` or ``option=VALUE`` (both
            removed); False for a flag.

    Returns:
        The other arguments, in order (after a ``--``, all of them).

    """
    options, rest = split_at_end_of_options(arguments=arguments)
    kept: list[str] = []
    skips_next = False
    for argument in options:
        if skips_next:
            skips_next = False
            continue
        if argument == option:
            skips_next = takes_value
            continue
        if takes_value and argument.startswith(f'{option}='):
            continue
        kept.append(argument)
    return [*kept, *rest]


def with_options_appended(*, arguments: Sequence[str], appended: Sequence[str]) -> list[str]:
    """Return ``arguments`` with ``appended`` added after its options (before a bare ``--``).

    Args:
        arguments: A command line.
        appended: Options and their values, in order.

    Returns:
        The command line.

    """
    options, rest = split_at_end_of_options(arguments=arguments)
    return [*options, *appended, *rest]


def run_command(
    *,
    command: Sequence[str],
    environment: Mapping[str, str],
    timeout_seconds: float | None,
    capture_output: OutputCapture = OutputCapture.NONE,
    working_directory: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run a command (an argument list, never a shell) as a child process and wait for it.

    The engine's one child-process launcher: the audit's replays use it, so do a watched
    replay's restarts (glitchygames/replay/rebuild.py), the replay pytest plugin and the
    end-to-end audit tests.

    Args:
        command: The program and its arguments.
        environment: The child's whole environment, in place before its interpreter starts.
        timeout_seconds: Kill the child (TimeoutExpired) after this long; None waits for as long
            as it runs (a restarted watched replay, glitchygames/replay/rebuild.py).
        capture_output: What is captured of the child's standard output and error
            (``OutputCapture``: none, together in ``stdout``, or apart in ``stdout`` and
            ``stderr``).
        working_directory: The child's working directory (None: this process's), e.g. a
            build's directory for SDL's configure script (scripts/build_sdl_x11.py).

    Returns:
        The finished process (``returncode``; ``stdout`` when captured, else None; ``stderr``
        when captured apart, else None).

    """
    standard_output, standard_error = OUTPUT_STREAMS[capture_output]
    return subprocess.run(  # ruff: ignore[subprocess-without-shell-equals-true] — sys.executable with a game's command line plus fixed flags, as an argument list (no shell)
        list(command),
        env=dict(environment),
        stdout=standard_output,
        stderr=standard_error,
        text=True,
        check=False,
        timeout=timeout_seconds,
        cwd=working_directory,
    )


def run_command_stopped_at_timeout(
    *,
    command: Sequence[str],
    environment: Mapping[str, str],
    timeout_seconds: float,
    working_directory: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run a command as ``run_command`` does, its output not captured, stopping it gently.

    For a child that may start children of its own (a game given ``--verify`` or ``--measure``
    replays each recording in one): a child still running after ``timeout_seconds`` is asked to
    stop first (SIGTERM; on Windows, terminated), so its engine can stop and reap its own
    children as it ends (``exit_on_signal``), and is killed only if it is still running after
    STOP_GRACE_SECONDS. ``run_command`` kills a child at once, which would leave such a
    grandchild running. The child is stopped the same way, and reaped, however this process
    stops waiting (a signal's SystemExit, Ctrl-C).

    Args:
        command: The program and its arguments.
        environment: The child's whole environment, in place before its interpreter starts.
        timeout_seconds: Stop the child (TimeoutExpired) after this long.
        working_directory: The child's working directory (None: this process's).

    Returns:
        The finished process (``returncode``; ``stdout`` and ``stderr`` None: the child writes
        to this process's). A child that outlived ``timeout_seconds`` raises ``TimeoutExpired``
        once it is stopped and reaped.

    """
    child = subprocess.Popen(  # ruff: ignore[subprocess-without-shell-equals-true] — sys.executable with a game's command line plus fixed flags, as an argument list (no shell)
        list(command),
        env=dict(environment),
        text=True,
        cwd=working_directory,
    )
    try:
        returncode = child.wait(timeout=timeout_seconds)
    except BaseException:
        # The timeout, or this process being stopped (a signal's SystemExit, Ctrl-C) while waiting
        stop_and_reap(process=child)
        raise
    return subprocess.CompletedProcess(args=list(command), returncode=returncode)


def stop_and_reap(*, process: subprocess.Popen[str]) -> None:
    """Ask a child to stop, kill it if it is still running after STOP_GRACE_SECONDS, reap it.

    The child alone (``stop_command`` stops a child started in a session of its own with its
    whole group). SIGTERM lets a game end through its engine's teardown, which stops and reaps
    the children it is waiting for.

    Args:
        process: The child.

    """
    process.terminate()
    try:
        process.wait(timeout=STOP_GRACE_SECONDS)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def start_command(
    *, command: Sequence[str], environment: Mapping[str, str], output: TextIO
) -> subprocess.Popen[str]:
    """Start a command (an argument list, never a shell) as a child process; do not wait.

    On POSIX the child leads a session of its own, so ``stop_command`` can end it with every
    process it started (a pytest run's xdist workers), and a terminal's Ctrl-C reaches only this
    process, which then stops the child.

    Args:
        command: The program and its arguments.
        environment: The child's whole environment, in place before its interpreter starts.
        output: Where the child's standard output and error go (an open file).

    Returns:
        The running process (``wait()`` for its ``returncode``).

    """
    return subprocess.Popen(  # ruff: ignore[subprocess-without-shell-equals-true] — sys.executable with the suite's own command line plus fixed flags, as an argument list (no shell)
        list(command),
        env=dict(environment),
        stdout=output,
        stderr=subprocess.STDOUT,
        text=True,
        # POSIX only (Windows ignores it): stop_command terminates a Windows child alone
        start_new_session=True,
    )


def stop_command(*, process: subprocess.Popen[str], first_signal: int = signal.SIGTERM) -> None:
    """End a child ``start_command`` started, with every process in its group, and reap it.

    On POSIX the group gets ``first_signal``, then, each after STOP_GRACE_SECONDS while the child
    still runs, SIGTERM (when the first signal was another) and SIGKILL. On Windows the child is
    terminated, then killed after the grace (no group signal there; ``first_signal`` is unused).
    A child that has already ended is only reaped, also when it ends between the check and a
    signal (``_signal_the_group``).

    The group signal reaches the child and every process it started that stayed in its group
    (a pytest run's xdist workers); a grandchild that started a session of its own is not in it.
    A pytest run should be stopped with ``first_signal=signal.SIGINT``: pytest turns it into an
    orderly KeyboardInterrupt in every worker, so each test's ``finally`` and fixture teardown
    stop what the test started. SIGTERM, which pytest does not handle, kills a worker at once,
    and a test's child in a session of its own is then left running (BUGS.md #275). A game
    keeps the default: its engine turns SIGTERM into its own teardown.

    Args:
        process: The child.
        first_signal: The first signal for the group (POSIX).

    """
    if process.poll() is not None:
        return
    if sys.platform == 'win32':
        process.terminate()
        try:
            process.wait(timeout=STOP_GRACE_SECONDS)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        return
    escalation = [first_signal]
    if first_signal != signal.SIGTERM:
        escalation.append(signal.SIGTERM)
    for signal_number in escalation:
        if not _signal_the_group(process=process, signal_number=signal_number):
            return
        try:
            process.wait(timeout=STOP_GRACE_SECONDS)
        except subprocess.TimeoutExpired:
            continue
        return
    if not _signal_the_group(process=process, signal_number=signal.SIGKILL):
        return
    process.wait()


def _signal_the_group(*, process: subprocess.Popen[str], signal_number: int) -> bool:
    """Signal a running child's process group (POSIX), unless the child ended meanwhile.

    A child that is ending after ``stop_command`` asked whether it runs (exiting, or a zombie
    until reaped): macOS then answers a signal to its group with EPERM (``PermissionError``),
    even before ``poll()`` can see the exit, and any POSIX system answers ESRCH
    (``ProcessLookupError``) for a group already gone. Either is no failure to stop it, when
    the child ends within ``STOP_GRACE_SECONDS``: it is waited for and reaped here.

    Args:
        process: The child (its process group leader).
        signal_number: The signal.

    Returns:
        True when the group was signalled; False when the child was ending (it is reaped).

    Raises:
        PermissionError: If the signal is refused and the child does not end in time.
        ProcessLookupError: If the group is gone and the child does not end in time.

    """
    try:
        os.killpg(process.pid, signal_number)
    except (PermissionError, ProcessLookupError) as refusal:
        try:
            process.wait(timeout=STOP_GRACE_SECONDS)
        except subprocess.TimeoutExpired:
            raise refusal from None
        return False
    return True
