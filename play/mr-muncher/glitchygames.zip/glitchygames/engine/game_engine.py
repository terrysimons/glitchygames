#!/usr/bin/env python3
"""Contains GameEngine and helper classes for building a game."""

from __future__ import annotations

import argparse
import contextlib
import cProfile
import functools
import logging
import math
import multiprocessing
import os
import platform
import pprint
import signal
import sys
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Concatenate,
    Literal,
    NoReturn,
    Self,
    cast,
    override,
)

import pygame
from pydantic import BaseModel, ConfigDict

from glitchygames import clock, events
from glitchygames.ai_link import AiLink, create_link
from glitchygames.argument_types import non_negative_int, unit_interval
from glitchygames.backgrounds import (
    DEFAULT_BACKGROUND_PATTERN,
    BackgroundPattern,
    active_default_background_pattern,
    paint_default_background,
    set_active_default_background_pattern,
)
from glitchygames.build_info import engine_source_revision
from glitchygames.color import PURPLE
from glitchygames.crt_power_on import (
    CrtPowerOnMode,
    PowerOnOutcome,
    play_power_on,
    play_power_on_async,
    resolve_mode,
    should_play,
)
from glitchygames.display_mode import set_display_mode
from glitchygames.engine.running_game import RunningGame
from glitchygames.engine_context import ContextSlot, current_context
from glitchygames.events.app import AppEventManager
from glitchygames.events.audio import AudioEventManager
from glitchygames.events.controller import ControllerEventManager
from glitchygames.events.drop import DropEventManager
from glitchygames.events.game import GameEventManager
from glitchygames.events.joystick import JoystickEventManager
from glitchygames.events.keyboard import KeyboardEventManager
from glitchygames.events.midi import MidiEventManager
from glitchygames.events.mouse import MouseEventManager
from glitchygames.events.touch import TouchEventManager
from glitchygames.events.window import WindowEventManager
from glitchygames.exit_codes import BUG_REPORT_HINT, ExitCode
from glitchygames.fonts import FontManager
from glitchygames.host import GameHost, HostSources
from glitchygames.input.device_listing import list_input_devices
from glitchygames.input.devices import ReplayController
from glitchygames.input.input_devices import (
    InputDeviceChanges,
    InputDevices,
    InputMode,
    RecordedDevices,
)
from glitchygames.input.state import current_input, reset_current_input, set_current_input
from glitchygames.live_sources import LiveSources
from glitchygames.logical_names import logical_name
from glitchygames.machine_state import current_machine_state
from glitchygames.output_files import output_refusal, partial_path
from glitchygames.randomness import seed_engine_random
from glitchygames.read_only_views import ClassOnlyView, ReadOnlyView, ReadOnlyViews
from glitchygames.recording import (
    CUSTOM_EVENT_TYPES_HEADER_FIELD,
    DEVICE_ENUMERATION_FIELD,
    DEVICES_HEADER_FIELD,
    RECORDED_AT_HEADER_FIELD,
    SAVES_HEADER_FIELD,
    GameplayRecorder,
    RecordingSources,
    RecordingWriteError,
    TraceRecordingAlreadyStartedError,
    custom_event_types_header,
    forget_pending_posts,
    json_safe_value,
    pending_internal_posts,
    post_event,
    post_input_event,
    reset_internal_post_tracking,
    start_tracking_internal_posts,
)
from glitchygames.recording_history import (
    CONTENT_HASH_SCHEME,
    MEASUREMENT_RUNS_HEADER_FIELD,
    MeasurementRun,
)
from glitchygames.render_target import (
    hosted_start_requested,
    is_inner_context,
    note_started_engine,
    render_target,
)
from glitchygames.replay.audit import (
    AuditRunError,
    audit_command,
    audit_recording,
    environment_reaches_children,
)
from glitchygames.replay.driver import (
    GAME_HEADER_FIELD,
    REAL_REPLAY_FPS,
    RUNNING_END_REASON,
    ReplayRefusedError,
    ReplaySources,
    announce_replay,
    display_size_refusal,
    installed_engine_version,
    replayed_batch_origins,
    start_replay,
)
from glitchygames.replay.processing import machine_description
from glitchygames.replay.rebaseline import Rebaseline, RebaselineSummary, rebaseline_refusal
from glitchygames.replay.rebuild import (
    ViewerState,
    parse_viewer_state,
    relaunch_replay,
    restart_command,
)
from glitchygames.replay.tools.compare import (
    DEFAULT_COMPARE_ALPHA_PERCENT,
    CompareRefusal,
    FrameStream,
    FrameStreamAddress,
    OldRecording,
    OnionSkin,
    compare_trace_refusal,
    first_streamed_frame,
    frame_stream_refusal,
    old_game_command,
    old_recording_refusal,
    read_old_recording,
    screen_size_refusal,
)
from glitchygames.replay.tools.identity import game_source_revision
from glitchygames.replay.tools.registry import (
    add_game_flags,
    given_tools,
    path_option_destinations,
    run_game_flag_tool,
    tool_flags,
)
from glitchygames.replay.tools.settings import find_project_root, stored_path
from glitchygames.replay.viewer import run_watched_replay_async
from glitchygames.scenes import Scene, SceneManager
from glitchygames.sources import (
    active_sources,
    install_sources,
    reset_sources,
    take_redelivered_events,
)
from glitchygames.sprites.sprite import sprite_counters
from glitchygames.state.sandbox import save_namespace_snapshot
from glitchygames.supervision import BREAKPOINT_KIND
from glitchygames.timing import (
    DEFAULT_SLEEP_GRANULARITY_NS,
    DEFAULT_TARGET_FPS,
    GIL_SWITCH_INTERVAL_SECONDS,
    TIMER_BACKEND_AUTO,
    TIMER_BACKEND_FAST,
    TIMER_BACKEND_PYGAME,
    create_timer,
    pacing_timer_for_options,
)
from glitchygames.tracing import TraceFormatError

if TYPE_CHECKING:
    from collections.abc import Awaitable, Generator, Sequence
    from types import FrameType

    from glitchygames.ai_console import AiConsole
    from glitchygames.audio.voices import ChannelPartition
    from glitchygames.crt_power_on_sound import CrtPowerOnSound
    from glitchygames.input.devices import OpenedController, ReplayDeviceRegistry
    from glitchygames.input.state import InputSnapshot

LOG: logging.Logger = logging.getLogger('game.engine')
LOG.addHandler(logging.NullHandler())
# How the log lines of a game's run read, and those of the glitchygames command too
LOG_FORMAT = '%(name)s - %(levelname)s - %(message)s'


# The glitchygames package directory, and its assets (the default window icon). This module is
# glitchygames/engine/game_engine.py: both were Path(__file__).parent-based when the engine was
# glitchygames/engine.py, and pointed into glitchygames/engine/ after it became a package, so
# the default icon was never found
PACKAGE_PATH: Path = Path(__file__).parent.parent
ASSET_PATH: Path = PACKAGE_PATH / 'assets'
TEST_MODE = False

PYGAME_MIN_MAJOR_VERSION = 2
PYGAME_MIN_MINOR_VERSION = 2
UNKNOWN_SDL2_EVENT_TYPE_1543 = 1543

GAME_NOT_INITIALIZED_MSG = 'Game not initialized.  Pass a game class to the GameEngine constructor.'
ASYNC_RUN_NEEDS_HOST_MSG = (
    'start_async() runs live games and watched replays only: a headless replay never gives '
    'control back between frames; run it with start()'
)
MISSING_ATTRIBUTE_MSG = "'{cls}' object has no attribute '{attr}'"

DEFAULT_SCREEN_SHAKE_INTENSITY = 1.0
DEFAULT_RUMBLE_INTENSITY = 1.0
DEFAULT_LIVE_VOICE_POOL = 4
# The sound options' choices (sound engine impl spec 10.2; glitchygames/audio/engine.py holds the
# channel and memory defaults)
CRT_POWER_ON_SOUND_ON = 'on'
CRT_POWER_ON_SOUND_OFF = 'off'
CRT_POWER_ON_SOUND_CHOICES = (CRT_POWER_ON_SOUND_ON, CRT_POWER_ON_SOUND_OFF)
DEFAULT_CRT_POWER_ON_SOUND = CRT_POWER_ON_SOUND_ON
# The SDL video and audio driver --headless runs on (no window, no sound)
HEADLESS_SDL_DRIVER = 'dummy'
# The environment variables that choose SDL's video and audio drivers (--headless sets both)
SDL_DRIVER_VARIABLES = ('SDL_VIDEODRIVER', 'SDL_AUDIODRIVER')
# What a Linux Wayland session runs on when nothing chose a driver: alone, SDL picks x11 there
# whenever DISPLAY is also set (seen on Ubuntu 26.10), which goes through XWayland and cost a
# fullscreen window about 25% on a Raspberry Pi 4. SDL tries a list in order, so x11 still starts
# when Wayland cannot
WAYLAND_FIRST_VIDEO_DRIVERS = 'wayland,x11'
# SDL's hint that turns its own SIGINT/SIGTERM handlers off (the engine owns the signals)
SDL_NO_SIGNAL_HANDLERS_HINT = 'SDL_NO_SIGNAL_HANDLERS'
# --video-driver's choices: SDL 2's video drivers by platform.system() name (SDL's own list,
# src/video/SDL_video.c bootstrap[]; checked on macOS: cocoa, offscreen and dummy start, metal and
# x11 are not drivers of pygame-ce's SDL there), then the ones SDL builds on every platform
PLATFORM_VIDEO_DRIVERS: dict[str, tuple[str, ...]] = {
    'Darwin': ('cocoa',),
    'Windows': ('windows',),
    'Linux': ('x11', 'wayland', 'kmsdrm'),
}
PORTABLE_VIDEO_DRIVERS = ('offscreen', 'dummy')

# The signals that end a run through the normal teardown (exit_on_signal), by name:
# SIGHUP exists only on Unix and SIGBREAK only on Windows, so each is looked up where it runs.
# SIGINT needs no handler (KeyboardInterrupt); see glitchygames/exit_codes.py for those not wired
TERMINATING_SIGNAL_NAMES = ('SIGTERM', 'SIGHUP', 'SIGBREAK')


def scene_class_of(game: type[Scene] | Scene) -> type[Scene]:
    """Return the game's scene class, whether the engine was given the class or an instance.

    The one spelling of this test: it was written two ways, and the other one returned a
    stand-in instance that is not a Scene as if it were a class (BUGS.md #224 item 15).

    Args:
        game: The game scene class or instance.

    Returns:
        The scene class.

    """
    # Tested as a type, not as a Scene, so a stand-in that is no Scene is still never taken for a
    # class. ty narrows the class branch to "type[Scene] | (Scene & type)" (a Scene that is also
    # a type, a metaclass instance no game is), where basedpyright sees type[Scene] and refuses a
    # cast as unnecessary: so ty alone is told
    return game if isinstance(game, type) else type(game)  # ty: ignore[invalid-return-type]


def pygame_needs_fastevents() -> bool:
    """Report whether this pygame is older than 2.2 and so reads events with pygame.fastevent.

    Returns:
        True for pygame < 2.2.

    """
    # Compare (major, minor) as a pair: pygame 1.9 is older than 2.2 although its minor 9 is not
    # below 2 (BUGS.md #75).
    return (pygame.version.vernum[0], pygame.version.vernum[1]) < (
        PYGAME_MIN_MAJOR_VERSION,
        PYGAME_MIN_MINOR_VERSION,
    )


def target_fps_value(value: str) -> float:
    """Argparse type: a finite float >= 0 (0 means uncapped).

    Args:
        value: The command-line text.

    Returns:
        The parsed float.

    Raises:
        argparse.ArgumentTypeError: If the text is not a finite number >= 0.

    """
    try:
        number = float(value)
    except ValueError as error:
        message = f'{value!r} is not a number'
        raise argparse.ArgumentTypeError(message) from error
    if not math.isfinite(number) or number < 0.0:
        message = f'{value!r} must be a finite number >= 0 (0 = uncapped)'
        raise argparse.ArgumentTypeError(message)
    return number


def terminating_signals() -> list[int]:
    """Return the TERMINATING_SIGNAL_NAMES this platform has, as signal numbers.

    Returns:
        SIGTERM, plus SIGHUP on Unix or SIGBREAK on Windows.

    """
    return [getattr(signal, name) for name in TERMINATING_SIGNAL_NAMES if hasattr(signal, name)]


def exit_on_signal(signal_number: int, _frame: FrameType | None) -> None:
    """End the run with SystemExit, so GameEngine.start()'s teardown still runs.

    Installed by ``GameEngine.start`` for each of ``terminating_signals()`` that nothing else
    handles, for the whole run, so a recording is closed by ``_shutdown``. It ignores further
    signals of the same kind before raising: a second SIGTERM (``uv run`` forwards one to its
    child as well, and ``pkill`` can match both) would otherwise raise again inside the teardown
    and leave the recording unclosed. ``_shutdown`` restores the default handling after closing
    the recording. It does nothing else: logging here could fail with "reentrant call" if the
    signal interrupted a write to the same stream.

    Args:
        signal_number: The signal received.
        _frame: The interrupted frame (unused).

    Raises:
        SystemExit: Always, with ``ExitCode.for_signal(signal_number)`` (``TERMINATED`` for
            SIGTERM, ``HANGUP`` for SIGHUP, ``BREAK`` for SIGBREAK).

    """
    signal.signal(signal_number, signal.SIG_IGN)
    raise SystemExit(ExitCode.for_signal(signal_number))


def reserved_flag_refusal(*, game_name: str, error: argparse.ArgumentError) -> str:
    """Say which of a game's argument's flags the engine already has, and that it reserves them.

    argparse raises ``ArgumentError`` when the game's ``args`` adds an argument with a flag the
    engine's parser holds (``conflicting option string(s): --force``). Each conflicting flag is
    named: one of the engine's tools' (``registry.tool_flags``: ``glitchygames --help`` lists
    them), or one of every game's general options (its ``--help`` lists them).

    Args:
        game_name: The game's name (``NAME``).
        error: What argparse raised (its ``argument_name``: the game's argument, all its flags).

    Returns:
        The message.

    """
    # argparse's message is "conflicting option string(s): FLAG, FLAG"
    _, _, listed = error.message.partition(': ')
    flags_of_the_tools = tool_flags()
    reasons = [
        f'{flag} is reserved by the engine for its tools (glitchygames --help lists them)'
        if flag in flags_of_the_tools
        else f'{flag} is reserved by the engine (an option of every game: --help lists them)'
        for flag in listed.split(', ')
    ]
    return (
        f"{game_name}'s argument {error.argument_name}: {'; '.join(reasons)}. Rename the game's "
        'argument'
    )


def install_exit_on_signal_handlers() -> list[int]:
    """Make each of terminating_signals() raise SystemExit, if nothing else handles it yet.

    The engine's one way of installing ``exit_on_signal`` (``GameEngine._install_signal_handlers``
    for a run, ``run_inside_tool_crash_boundary`` for a tool on either front end). While it is
    installed, a SIGTERM (or SIGHUP, SIGBREAK) raises SystemExit wherever this process waits, so
    ``subprocess.run`` kills and reaps a child it is waiting for instead of leaving it running.

    Limitation: Python sets signal handlers from the main thread only. On another thread none is
    installed, and SDL's own handler is off (SDL_NO_SIGNAL_HANDLERS), so SIGTERM (or SIGHUP,
    SIGBREAK) then kills the process the system's default way, without the teardown: a recording
    is left unclosed (it still reads up to its last full frame).

    Returns:
        The signals it installed the handler for (``restore_default_signal_handling`` puts them
        back).

    """
    installed: list[int] = []
    for signal_number in terminating_signals():
        try:
            # Limitation: a C-level handler (SDL's, when pygame was initialized before the
            # engine set SDL_NO_SIGNAL_HANDLERS) is invisible here, as getsignal still
            # reports SIG_DFL; installing then replaces it, which is what the engine wants
            if signal.getsignal(signal_number) == signal.SIG_DFL:
                signal.signal(signal_number, exit_on_signal)
                installed.append(signal_number)
        except ValueError as signal_error:
            # Signal handlers can only be set from the main thread
            LOG.debug('Signal %d handler not installed: %s', signal_number, signal_error)
    return installed


def restore_default_signal_handling(*, signal_numbers: list[int]) -> None:
    """Put back the default handling of signals ``install_exit_on_signal_handlers`` claimed.

    Args:
        signal_numbers: The signals it returned.

    """
    for signal_number in signal_numbers:
        signal.signal(signal_number, signal.SIG_DFL)


def run_inside_tool_crash_boundary(
    *, run_tool: Callable[[], int], tool_description: str, report_hint: str | None
) -> tuple[int, BaseException | None]:
    """Run a tool inside the crash boundary and signal handling a game's run gets.

    The one boundary of both front ends' tools: a game flag's (``GameEngine._run_game_flag_tool``)
    and the ``glitchygames`` command's (glitchygames/replay/tools/command.py). While the tool runs,
    a terminating signal raises SystemExit with its own code (``exit_on_signal``), so a child the
    tool waits for is killed and reaped by ``subprocess.run`` before this process ends; the
    handlers are put back afterwards. However the tool ends is turned into an exit status, as
    ``start()``'s run turns a run's ending into one (``_crash_boundary``):

    - Ctrl-C (KeyboardInterrupt): ``ExitCode.INTERRUPTED`` (``subprocess.run`` has stopped and
      reaped a child first, as for a signal);
    - a recording write that failed part way: ``ExitCode.CANNOT_WRITE_OUTPUT``;
    - any other exception: ``ExitCode.INTERNAL_ERROR``, logged with its traceback as
      ``Runtime error during game execution @ tool '<tool>'``, then ``report_hint`` (an ERROR
      line of its own) when there is one.

    A SystemExit (a signal handler's) passes through with its own code.

    Args:
        run_tool: Runs the tool and returns its exit status.
        tool_description: How the log names the tool (its flag: ``--verify``).
        report_hint: What to do to report a crash (``BUG_REPORT_HINT``, on a game, which takes
            ``--log-level``), or None (the ``glitchygames`` command, which has no such option).

    Returns:
        The exit status, and the exception that ended the tool (None when it returned).

    """
    installed = install_exit_on_signal_handlers()
    cause: BaseException | None = None
    try:
        exit_status = run_tool()
    except KeyboardInterrupt as interrupt:
        # Ctrl-C: never an internal error
        exit_status, cause = ExitCode.INTERRUPTED, interrupt
    except RecordingWriteError as error:
        # The disk filled part way: logged on one line by the recorder (BUGS.md #82)
        exit_status, cause = ExitCode.CANNOT_WRITE_OUTPUT, error
    except Exception as error:
        LOG.exception("Runtime error during game execution @ tool '%s'", tool_description)
        if report_hint is not None:
            # Its own line after the traceback (logged above), where a player reads last
            LOG.error(report_hint)  # ruff: ignore[error-instead-of-exception]
        exit_status, cause = ExitCode.INTERNAL_ERROR, error
    finally:
        # A signal's SystemExit (exit_on_signal) passes through with its own code
        restore_default_signal_handling(signal_numbers=installed)
    return exit_status, cause


def input_device_prompt() -> Callable[[str], None] | None:
    """Return how --list-input-devices prompts for a device, or None when it must not wait.

    It prompts only when stdin and stdout are a terminal: a person is there to plug a device in
    (or press Ctrl-C). A script, a pipe or CI gets the listing at once, never a wait.

    Returns:
        A writer of the prompt line (to stdout, flushed), or None.

    """
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return None

    def write_prompt(message: str) -> None:
        sys.stdout.write(f'{message}\n')
        sys.stdout.flush()

    return write_prompt


def exit_with(*, exit_code: ExitCode, cause: BaseException | None = None) -> NoReturn:
    """Log the exit code the engine exits with (``ExitCode.describe()``) and exit with it.

    Args:
        exit_code: The code.
        cause: The exception that led to the exit, chained as the SystemExit's cause.

    Raises:
        SystemExit: Always, with ``exit_code``.

    """
    LOG.info('Exiting with %s', exit_code.describe())
    raise SystemExit(exit_code) from cause


@dataclass
class UnhandledEventRecord:
    """Statistics for one unhandled event type over a whole run.

    Attributes:
        count: How many events of this type went unhandled.
        first_seen_seconds: When the first one arrived, in seconds since the engine started.
        attribute_names: The first event's attribute names, sorted (never their values).

    """

    count: int
    first_seen_seconds: float
    attribute_names: tuple[str, ...]


@dataclass
class LiveDevicesBehindScope:
    """The live game's devices, set aside while a playback scope plays on its own (#184.3).

    Attributes:
        joysticks: ``joystick_manager.joysticks`` as the scope began.
        controller_manager: ``GameEngine.controller_manager`` as the scope began (None in
            joystick mode).
        controllers: That controller manager's ``controllers`` as the scope began (None
            without one).
        input_devices: ``GameEngine.input_devices`` as the scope began.
        scope_made_the_controller_manager: True when the scope made a controller manager of
            its own (the recording had one, the live game has none): released as it ends.

    """

    joysticks: dict[int, JoystickEventManager.JoystickEventProxy]
    controller_manager: ControllerEventManager | None
    controllers: dict[int, ControllerEventManager.ControllerEventProxy] | None
    input_devices: InputDevices
    scope_made_the_controller_manager: bool


# The options whose values are paths besides the tools' (the supervising replay's handoff file)
ENGINE_PATH_OPTIONS = frozenset({'replay_restart_handoff'})


def stored_options(*, options: Mapping[str, Any]) -> dict[str, Any]:
    """Return a run's options as a recording's header stores them: paths relative to the project.

    Every path option (a tool's own value or a path option of one,
    ``path_option_destinations``, and ``ENGINE_PATH_OPTIONS``) is stored relative to the project
    root the current directory is in (``find_project_root``), or as its file name when outside
    any project (``stored_path``); every other option is stored as given.

    Args:
        options: The parsed options.

    Returns:
        The options to store.

    """
    return _with_path_options_converted(options=options, convert=stored_path)


def _with_path_options_converted(
    *,
    options: Mapping[str, Any],
    convert: Callable[..., str],
) -> dict[str, Any]:
    """Return options with every path option's path (or each of its paths) converted.

    The path options are a tool's own value or a path option of one
    (``path_option_destinations``) and ``ENGINE_PATH_OPTIONS``; every other option is kept as
    given. Shared by ``stored_options`` and ``displayed_options``.

    Args:
        options: The parsed options.
        convert: Called as ``convert(path=..., project_root=...)`` with the project root the
            current directory is in (``find_project_root``); returns the path to keep.

    Returns:
        The converted options.

    """
    path_options = path_option_destinations() | ENGINE_PATH_OPTIONS
    project_root = find_project_root(start=Path.cwd())
    converted: dict[str, Any] = {}
    for name, value in options.items():
        if name in path_options and isinstance(value, str | os.PathLike):
            converted[name] = convert(
                path=cast('str | os.PathLike[str]', value), project_root=project_root
            )
        elif name in path_options and isinstance(value, list | tuple):
            converted[name] = [
                convert(path=path, project_root=project_root)
                for path in cast('Sequence[str | os.PathLike[str]]', value)
            ]
        else:
            converted[name] = value
    return converted


# The startup options block (GameEngine._log_the_startup_options): an option whose name holds
# one of these, in any case, shows REDACTED_OPTION_VALUE instead of its value (the coordinator's
# ruling, 2026-10-28; the AI tooling's API keys must never reach a log)
SECRET_OPTION_NAME_PARTS = ('key', 'token', 'secret', 'password', 'credential')
REDACTED_OPTION_VALUE = '<redacted>'
# Each nesting level of the block indents this much more
OPTIONS_BLOCK_INDENT = '    '
# pprint's width for a value that does not fit on one line
OPTIONS_BLOCK_WIDTH = 100


def is_secret_option_name(*, name: str) -> bool:
    """Tell whether an option's name suggests a secret (a key, token, password, ...).

    Args:
        name: The option's name.

    Returns:
        True when the name holds one of ``SECRET_OPTION_NAME_PARTS``, in any case.

    """
    lowered = name.lower()
    return any(part in lowered for part in SECRET_OPTION_NAME_PARTS)


def displayed_path(*, path: str | os.PathLike[str], project_root: Path | None) -> str:
    """Return a path as the startup options block shows it.

    Inside the project, its stored path (``stored_path``: relative to the root, POSIX-style);
    anywhere else absolute (the coordinator's ruling, 2026-10-28), where ``stored_path`` would
    keep only the file name, or a path in another checkout.

    Args:
        path: The path as given.
        project_root: The project's root (``find_project_root``), or None.

    Returns:
        The path to show.

    """
    resolved = Path(path).expanduser().resolve()
    if project_root is not None:
        stored = stored_path(path=path, project_root=project_root)
        # The stored path is shown only when it leads back to the path from this project's root
        if (project_root.resolve() / stored).resolve() == resolved:
            return stored
    return str(resolved)


def displayed_options(*, options: Mapping[str, Any]) -> dict[str, Any]:
    """Return a run's options with every path option shown by ``displayed_path``.

    The path options are ``stored_options``' (``path_option_destinations`` and
    ``ENGINE_PATH_OPTIONS``); every other option is kept as given.

    Args:
        options: The parsed options.

    Returns:
        The options to show.

    """
    return _with_path_options_converted(options=options, convert=displayed_path)


def options_block_lines(*, options: Mapping[Any, Any], indent: str) -> list[str]:
    """Return an options mapping's lines: sorted, ``name = value``, aligned, nested indented.

    A name that suggests a secret (``is_secret_option_name``) shows ``REDACTED_OPTION_VALUE``,
    whatever its value, at any depth. A non-empty mapping is shown below its name, one level
    deeper; any other value is ``pprint``'s, its further lines (a long list) under the first.

    Args:
        options: The options (or a mapping nested in one).
        indent: The lines' indentation.

    Returns:
        The lines, without line ends.

    """
    names = sorted(options, key=str)
    width = max((len(str(name)) for name in names), default=0)
    lines: list[str] = []
    for name in names:
        value = options[name]
        prefix = f'{indent}{str(name).ljust(width)} = '
        if is_secret_option_name(name=str(name)):
            lines.append(f'{prefix}{REDACTED_OPTION_VALUE}')
        elif isinstance(value, Mapping) and value:
            lines.append(prefix.rstrip())
            lines.extend(
                options_block_lines(
                    options=cast('Mapping[Any, Any]', value),
                    indent=indent + OPTIONS_BLOCK_INDENT,
                )
            )
        else:
            # Any value at all (an empty mapping too): pformat writes each as Python would
            first, *rest = pprint.pformat(
                cast('object', value), width=max(OPTIONS_BLOCK_WIDTH - len(prefix), 1)
            ).splitlines()
            lines.append(f'{prefix}{first}')
            lines.extend(f'{" " * len(prefix)}{line}' for line in rest)
    return lines


def startup_options_block(*, game_name: str, options: Mapping[str, Any]) -> str:
    """Return the startup options block: a run's whole options dictionary, pretty printed.

    The owner, 2026-10-28: the game's startup options dictionary, "Pretty printed", logged at
    CRITICAL so it shows at every level. Sorted names, one ``name = value`` per line, aligned;
    nested values indented; paths by ``displayed_options``; nothing secret
    (``is_secret_option_name``). The environment is never read.

    Args:
        game_name: The game's name, for the heading.
        options: The run's options.

    Returns:
        The heading line, then one line per option (more for a nested or long value).

    """
    lines = options_block_lines(
        options=displayed_options(options=options), indent=OPTIONS_BLOCK_INDENT
    )
    return '\n'.join([f'Options for {game_name} (secrets redacted):', *lines])


class ReplayReport(BaseModel):
    """A replay's settled report (``GameEngine.settle_replay_report``; read-only).

    Attributes:
        text: The report (``ReplayResult.report``, or what ended the run early).
        is_failure: True when it reports a divergence or an early end.

    """

    model_config = ConfigDict(frozen=True, extra='forbid')

    text: str
    is_failure: bool


class NoRunningEngineError(RuntimeError):
    """``current_engine()`` was called in an engine context where no game engine is running."""


@dataclass
class _CurrentEngine:
    """The engine running in an engine context (``CURRENT_ENGINE_SLOT``)."""

    # Set by GameEngine.__init__, cleared by its _shutdown; None when no engine is running
    engine: GameEngine | None = None


# The engine running in each engine context (several games can run in one process: the Arcade)
CURRENT_ENGINE_SLOT: ContextSlot[_CurrentEngine] = ContextSlot(
    name='glitchygames.engine.game_engine.current_engine', factory=_CurrentEngine
)


def current_engine() -> GameEngine:
    """Return the game engine running in the current engine context.

    Returns:
        The engine made last in this context, until it shuts down.

    Raises:
        NoRunningEngineError: If no engine is running in this context.

    """
    context = current_context()
    engine = context.value(slot=CURRENT_ENGINE_SLOT).engine
    if engine is None:
        message = f"No game engine is running in the engine context '{context.name}'"
        raise NoRunningEngineError(message)
    return engine


def _stop_being_the_current_engine(*, engine: GameEngine) -> None:
    """Clear the current context's engine when it is ``engine`` (``current_engine()``).

    Args:
        engine: The engine that shut down, or failed to finish ``__init__``.

    """
    current = current_context().value(slot=CURRENT_ENGINE_SLOT)
    if current.engine is engine:
        current.engine = None


def _running_engine_attribute[T](*, read: Callable[[GameEngine], T]) -> T | None:
    """Read the current context's engine's attribute (the ``GameEngine`` views share it).

    Args:
        read: Reads the attribute from the engine (``lambda engine: engine.event_handlers``).

    Returns:
        What ``read`` returns for the engine running in the current context, or None when no
        engine is running there.

    """
    engine = current_context().value(slot=CURRENT_ENGINE_SLOT).engine
    if engine is None:
        return None
    return read(engine)


def _clear_a_half_made_engine[EngineT: GameEngine, **InitParameters](
    initialize: Callable[Concatenate[EngineT, InitParameters], None],
) -> Callable[Concatenate[EngineT, InitParameters], None]:
    """Wrap ``GameEngine.__init__``: if it raises, the half-made engine stops being current.

    ``__init__`` makes the engine current part way through (once its own state is set); a
    failure after that (SystemExit from a game flag tool included) must not leave it current.
    A decorator, not a ``try`` in ``__init__``: basedpyright then still sees the instance
    variables the methods ``__init__`` calls set.

    Args:
        initialize: ``GameEngine.__init__``.

    Returns:
        The wrapped ``__init__``, of the same signature.

    """

    @functools.wraps(initialize)
    def initialize_or_clear(
        engine: EngineT, *args: InitParameters.args, **kwargs: InitParameters.kwargs
    ) -> None:
        try:
            initialize(engine, *args, **kwargs)
        except BaseException:
            _stop_being_the_current_engine(engine=engine)
            raise

    return initialize_or_clear


class GameEngine(events.EventManager, metaclass=ReadOnlyViews):  # ruff: ignore[too-many-public-methods]
    """Glitchy Games' Game engine.

    The game engine is responsible for initializing pygame and
    handling events.  It also provides a number of helper methods
    for common tasks such as setting the screen resolution and
    setting the cursor.

    Every Glitchy Game game inherits the GameEngine command line
    options, so you can add your own command line options by
    implementing the args() class method in your Scene class.
    """

    log: ClassVar[logging.Logger] = LOG
    # The game's scene class, before and after start() (the scene it builds is
    # running_game.instance), one per engine (audit C9: set by __init__, so a second engine's
    # game never replaces the first's); a class-only view:
    # GameEngine.game is the current engine's, an engine's game its own attribute (an engine
    # whose __init__ never ran reads None)
    game = ClassOnlyView[Any](
        read_current=lambda _owner: _running_engine_attribute(read=lambda engine: engine.game),
        write_instead="the engine's own: engine.game",
    )

    _icon_path = Path(ASSET_PATH) / 'glitch.png'
    icon: pygame.Surface = (
        pygame.image.load(_icon_path) if _icon_path.exists() else pygame.Surface((32, 32))
    )

    NAME: Literal['Boilerplate Adventures'] = 'Boilerplate Adventures'
    VERSION: Literal['1.0'] = '1.0'
    # The parsed command line, one per engine (audit C8: set by __init__ from
    # initialize_arguments, so a second engine's options never replace the first's); a
    # read-only view of options
    OPTIONS = ReadOnlyView[dict[str, Any] | None, dict[str, Any]](
        read_current=lambda _owner: _running_engine_attribute(read=lambda engine: engine.options),
        read_own=lambda engine: engine.options,
        write_instead="the engine's own: engine.options",
    )

    # The on_*_event name last looked up and missed, the names missed (each logged once) and
    # the event types no handler took (each logged once), one set per engine (audit C11: so
    # one engine's misses never silence another's); read-only views of last_event_miss,
    # missing_events and unimplemented_events
    LAST_EVENT_MISS = ReadOnlyView[str | None, str](
        read_current=lambda _owner: _running_engine_attribute(
            read=lambda engine: engine.last_event_miss
        ),
        read_own=lambda engine: engine.last_event_miss,
        write_instead="the engine's own: engine.last_event_miss",
    )
    MISSING_EVENTS = ReadOnlyView[list[str] | None, list[str]](
        read_current=lambda _owner: _running_engine_attribute(
            read=lambda engine: engine.missing_events
        ),
        read_own=lambda engine: engine.missing_events,
        write_instead="the engine's own: engine.missing_events",
    )
    UNIMPLEMENTED_EVENTS = ReadOnlyView[list[int] | None, list[int]](
        read_current=lambda _owner: _running_engine_attribute(
            read=lambda engine: engine.unimplemented_events
        ),
        read_own=lambda engine: engine.unimplemented_events,
        write_instead="the engine's own: engine.unimplemented_events",
    )
    USE_FASTEVENTS: ClassVar[bool] = False
    # pygame was found running without SDL_NO_SIGNAL_HANDLERS (SDL owns the signals): every
    # engine warns until pygame is found stopped, even after the first engine set the hint
    PYGAME_FOUND_WITH_SDL_SIGNAL_HANDLERS: ClassVar[bool] = False

    # We add a layer of encapsulation here to simplify
    # the processing of events.  New event types added
    # to the events module need to be accounted for here
    # if they're not already handled
    #
    # These are wired up at the end of __init__(), one per engine; a read-only view of
    # event_handlers
    EVENT_HANDLERS = ReadOnlyView[
        dict[int, Callable[..., Any]] | None, dict[int, Callable[..., Any]]
    ](
        read_current=lambda _owner: _running_engine_attribute(
            read=lambda engine: engine.event_handlers
        ),
        read_own=lambda engine: engine.event_handlers,
        write_instead="the engine's own: engine.event_handlers",
    )

    # The --record-trace recorder while recording (start_trace_recording), else None; the
    # RecordingSources it installs write to it. A class default so it reads None on an engine
    # whose __init__ did not run.
    trace_recorder: GameplayRecorder | None = None
    # True once a recording's file could not be written (GameplayRecorder.write_failed, read as
    # it is closed): the run then exits CANNOT_WRITE_OUTPUT (BUGS.md #82). Set on the instance
    # only; the class default reads False on an engine whose __init__ did not run.
    recording_write_failed: bool = False
    # The --replay-trace doors while replaying (installed in __init__ before the first frame),
    # else None. A class default so it reads None on an engine whose __init__ did not run.
    replay_sources: ReplaySources | None = None
    # The --rebaseline writer while rebaselining (glitchygames/replay/rebaseline.py), else None.
    # A class default so it reads None on an engine whose __init__ did not run.
    rebaseline: Rebaseline | None = None
    # --compare-trace's onion skin (OLD's child and its frames; glitchygames/replay/tools/
    # compare.py) and a headless child's --replay-frame-stream, else None; both are stopped by
    # the teardown (_shutdown). Class defaults so they read None on an engine whose __init__
    # did not run.
    onion_skin: OnionSkin | None = None
    # The AI's console, for a run with a link (glitchygames/ai_console.py); the debug overlay's
    # AI panel reads it
    ai_console: AiConsole | None = None
    frame_stream: FrameStream | None = None
    # OLD when --compare-trace OLD is played live (no --replay-trace; rule 9 of
    # glitchygames/replay/tools/compare.py), else None
    live_old_recording: OldRecording | None = None

    @classmethod
    def initialize_icon(cls: Any, icon: pygame.Surface | Path | str | None = None) -> None:
        """Initialize the game icon.

        Args:
            cls: the GlitchyGames GameEngine class.
            icon: a pygame.Surface, Path, str path, or None.

        """
        if icon is None:
            return

        # If it's already a pygame.Surface, use it directly
        if isinstance(icon, pygame.Surface):
            GameEngine.icon = icon
        else:
            # If it's not a pygame.Surface, assume it's a path
            icon_path: Path = Path(icon)

            with contextlib.suppress(FileNotFoundError):
                GameEngine.icon = pygame.image.load(icon_path)

    @classmethod
    def args(cls: Any, parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
        """Add Glitchy Games arguments to the argument parser.

        All Glitchy Games will inherit these arguments.

        The effective target FPS is resolved in initialize_arguments: an explicit
        --target-fps (including 0 = uncapped) wins, then the game scene class's
        TARGET_FPS if it is not None, then DEFAULT_TARGET_FPS (60.01).

        Supported Arguments:
            -f, --target-fps (default: the game's TARGET_FPS, else 60.01; 0 = uncapped)
            --fps-log-interval-ms
            -w, --windowed, --no-windowed (default: windowed)
            -r, --resolution
            --use-gfxdraw
            --update-type
            --video-driver
            --debug-events

        Args:
            parser (argparse.ArgumentParser): The argument parser.

        Returns:
            argparse.ArgumentParser: The result.

        """
        group = parser.add_argument_group('Graphics Options')
        # How any run is watched, recorded, replayed or diagnosed, whatever the game
        diagnostics_group = parser.add_argument_group('Diagnostics Options')

        group.add_argument(
            '-f',
            '--target-fps',
            help="cap the framerate (default: the game's TARGET_FPS, else 60.01; 0 = uncapped)",
            type=target_fps_value,
            default=None,
        )
        group.add_argument(
            '--fps-log-interval-ms',
            help='how often to log the FPS counter in ms (default: 1000)',
            type=float,
            default=1000,
        )
        # A store_true flag defaulting to True could never ask for fullscreen (BUGS.md #76):
        # --no-windowed does, and -w/--windowed keep the command lines from before working
        group.add_argument(
            '-w',
            '--windowed',
            help='run in a window; --no-windowed runs fullscreen (default: windowed)',
            action=argparse.BooleanOptionalAction,
            default=True,
        )
        # Not a tool in the registry: two tool flags at once are refused, and this is on by default
        group.add_argument(
            '--ai',
            help=(
                'connect to the local AI service if it is installed, starting its models as '
                'the game loads; --no-ai never touches it (default: on, but never with '
                '--headless or in a replay)'
            ),
            action=argparse.BooleanOptionalAction,
            default=True,
        )
        group.add_argument(
            '-r',
            '--resolution',
            help='the resolution to use (default: %(default)s)',
            default='800x480',
        )
        # Kept as GameEngine.use_gfxdraw, but nothing reads it (Ball and Paddle set their own)
        group.add_argument(
            '--use-gfxdraw',
            help='not used yet: stored, but nothing draws with pygame.gfxdraw because of it',
            action='store_true',
            default=False,
        )
        group.add_argument(
            '--update-type',
            help='update or flip (default: update)',
            choices=['update', 'flip'],
            default='update',
        )
        group.add_argument(
            '--timer-backend',
            help=(
                'timer backend for draw loop pacing (default: auto, the fast backend with this '
                "machine's sleep delay measured, so each sleep wakes in time; fast assumes sleeps "
                'wake on time; pygame is the legacy backend)'
            ),
            choices=[TIMER_BACKEND_AUTO, TIMER_BACKEND_FAST, TIMER_BACKEND_PYGAME],
            default=TIMER_BACKEND_AUTO,
        )
        group.add_argument(
            '--sleep-granularity-ns',
            type=int,
            help=(
                'how long before each frame deadline the fast backend is to wake from its sleep '
                'and spin (ns); 0 spins only'
            ),
            default=DEFAULT_SLEEP_GRANULARITY_NS,
        )
        group.add_argument(
            '--windows-timer-1ms',
            help='on Windows, request 1ms system timer resolution',
            action='store_true',
            default=False,
        )
        diagnostics_group.add_argument(
            '--log-timer-jitter',
            help='log frame pacing jitter statistics periodically',
            action='store_true',
            default=False,
        )
        diagnostics_group.add_argument(
            '--perf-trim-percent',
            type=float,
            help="percent of frames to trim from top and bottom in the game's global FPS report",
            default=5.0,
        )
        diagnostics_group.add_argument(
            '--fps-histogram',
            choices=['equal-range', 'target-relative'],
            help=(
                "FPS histogram buckets in the game's shutdown report: equal-range (10 equal "
                'buckets spanning the analyzed min to max, default) or target-relative (10%% '
                'steps of the target FPS)'
            ),
            default='equal-range',
        )
        diagnostics_group.add_argument(
            '--debug-overlay',
            help='show the debug overlay at startup (F3 toggles, F4 cycles panels)',
            action=argparse.BooleanOptionalAction,
            default=False,
        )
        diagnostics_group.add_argument(
            '--sound-diagnostics',
            help='start with the debug overlay on, showing the Audio panel',
            action='store_true',
            default=False,
        )
        # Read by events.unhandled_event (glitchygames/events/base.py); how this run is
        # diagnosed, not what the game does, so a replay keeps its own (REPLAY_LOCAL_OPTIONS)
        diagnostics_group.add_argument(
            '--debug-events',
            help=(
                'log a warning the first time each unhandled event type arrives '
                '(--no-unhandled-events raises on one instead)'
            ),
            action='store_true',
            default=False,
        )
        # Every tool flag and the options the tools list come from the one table both front
        # ends are built from (glitchygames/replay/tools/registry.py)
        add_game_flags(parser=diagnostics_group)
        diagnostics_group.add_argument(
            '--replay-restart-handoff',
            metavar='PATH',
            # Internal: the supervising replay process passes it to each replay it restarts,
            # as glitchygames/replay/rebuild.py describes
            help=argparse.SUPPRESS,
            default=None,
        )
        diagnostics_group.add_argument(
            '--replay-viewer-state',
            metavar='JSON',
            type=parse_viewer_state,
            # Internal: a restarted replay's viewer state (speed, debug panel, divergence frame),
            # as glitchygames/replay/rebuild.py describes
            help=argparse.SUPPRESS,
            default=None,
        )
        group.add_argument(
            '--screen-shake-intensity',
            type=unit_interval,
            help='screen shake strength from 0.0 (off) to 1.0 (default: 1.0)',
            default=DEFAULT_SCREEN_SHAKE_INTENSITY,
        )
        group.add_argument(
            '--rumble-intensity',
            type=unit_interval,
            help='controller rumble strength from 0.0 (off) to 1.0 (default: 1.0)',
            default=DEFAULT_RUMBLE_INTENSITY,
        )
        group.add_argument(
            '--live-voice-pool',
            type=non_negative_int,
            help='mixer channels reserved for real-time synth voices (default: 4)',
            default=DEFAULT_LIVE_VOICE_POOL,
        )
        # The sound engine's options (impl spec 10.2): imported here, as the engine's start
        # imports the audio package (its channels are reserved then)
        from glitchygames.audio.engine import (
            DEFAULT_CACHE_MEMORY_MEGABYTES,
            DEFAULT_LIBRARY_CHANNELS,
        )
        from glitchygames.audio.library import CacheMode

        group.add_argument(
            '--sound-channels',
            type=non_negative_int,
            help=(
                'mixer channels reserved for the sound library (scene_manager.audio) '
                f'(default: {DEFAULT_LIBRARY_CHANNELS})'
            ),
            default=DEFAULT_LIBRARY_CHANNELS,
        )
        group.add_argument(
            '--sound-cache',
            choices=[mode.value for mode in CacheMode],
            help=(
                'how compiled sounds are kept: none (compiled again at every play), ram (in '
                'memory, default) or disk (arrives in M3; refused until then)'
            ),
            default=CacheMode.RAM.value,
        )
        group.add_argument(
            '--sound-cache-memory',
            metavar='MB',
            type=non_negative_int,
            help=(
                'megabytes the ram sound cache may hold before the least recently played idle '
                f'sounds go (default: {DEFAULT_CACHE_MEMORY_MEGABYTES})'
            ),
            default=DEFAULT_CACHE_MEMORY_MEGABYTES,
        )
        group.add_argument(
            '--crt-power-on-sound',
            choices=CRT_POWER_ON_SOUND_CHOICES,
            help='play the CRT power-on sequence with its sound (default: on)',
            default=DEFAULT_CRT_POWER_ON_SOUND,
        )
        group.add_argument(
            '--crt-power-on',
            choices=[mode.value for mode in CrtPowerOnMode],
            help=(
                "show the game's canvas switching on like a CRT before the game starts: auto "
                "(when someone can see it, so not on SDL's dummy driver or before a replay, "
                'audit, rebaseline or recording), on (always; refused with a replay or a '
                'recording) or off. Not given: the GLITCHYGAMES_CRT_POWER_ON environment '
                'variable, else auto'
            ),
            default=None,
        )
        group.add_argument(
            '--default-background',
            choices=[pattern.value for pattern in BackgroundPattern],
            help=(
                'the background of a scene that sets none: the TV test pattern or the channel 3 '
                f'blue screen (default: {DEFAULT_BACKGROUND_PATTERN.value})'
            ),
            default=None,
        )

        # SDL 2's video drivers for this platform (SDL_VIDEODRIVER names; the old list held SDL 1's,
        # and its macOS branch compared with 'MacOS', which platform.system() never returns:
        # macOS is 'Darwin', BUGS.md #76). offscreen and dummy are built into SDL everywhere.
        video_driver_choices = [
            *PLATFORM_VIDEO_DRIVERS.get(platform.system(), ()),
            *PORTABLE_VIDEO_DRIVERS,
        ]
        LOG.debug('Video Driver Choices: %s', video_driver_choices)
        # Sets SDL_VIDEODRIVER before the display starts (_enter_video_driver, BUGS.md #210)
        group.add_argument(
            '--video-driver',
            help=(
                "SDL's video driver for the display (sets SDL_VIDEODRIVER for the run; default: "
                "SDL_VIDEODRIVER's own value, then Wayland on a Linux Wayland session, then "
                "SDL's choice; --headless overrides it)"
            ),
            default=None,
            choices=video_driver_choices,
        )

        diagnostics_group.add_argument(
            '--list-input-devices',
            action='store_true',
            help=(
                'print every joystick and game controller the game would see (index, instance '
                'id, name, GUID, whether SDL maps it as a game controller, its axes, buttons, '
                'hats and balls; how many SDL counted before its queue was pumped and each '
                'device added or removed while listening, with when), then exit '
                f'{ExitCode.SUCCESS:d} without running the game. At a terminal, when none is '
                'found it asks you to plug one in and waits for it (Ctrl-C stops). Refused with '
                '--replay-trace or --record-trace'
            ),
            default=False,
        )

        event_managers = (
            AppEventManager,
            AudioEventManager,
            ControllerEventManager,
            DropEventManager,
            FontManager,
            GameEventManager,
            JoystickEventManager,
            KeyboardEventManager,
            MidiEventManager,
            MouseEventManager,
            TouchEventManager,
            WindowEventManager,
        )

        for event_manager in event_managers:
            parser = event_manager.args(parser=parser)

        return parser

    @staticmethod
    def resolve_target_fps(
        *,
        command_line_target_fps: float | None,
        game: type[Scene] | Scene,
    ) -> float:
        """Resolve the effective target FPS.

        Order: explicit command line value (0 = uncapped) > the game's TARGET_FPS
        (when not None) > DEFAULT_TARGET_FPS.

        Args:
            command_line_target_fps: The --target-fps value, or None if it was not passed.
            game: The game scene class or instance, which may declare TARGET_FPS.

        Returns:
            float: The effective target FPS (0 means uncapped).

        Raises:
            TypeError: If the game's TARGET_FPS is neither None nor a (non-bool) number.
            ValueError: If the game's TARGET_FPS is negative, NaN or infinite.

        """
        if command_line_target_fps is not None:
            return float(command_line_target_fps)

        # Looked up by name: TARGET_FPS is optional on a game (Scene does not declare it)
        game_target_fps = getattr(game, 'TARGET_FPS', None)
        if game_target_fps is None:
            return DEFAULT_TARGET_FPS

        scene_class = scene_class_of(game)
        # bool is a subclass of int, so it must be rejected explicitly.
        if isinstance(game_target_fps, bool) or not isinstance(game_target_fps, (int, float)):
            message = (
                f'{scene_class.__name__}.TARGET_FPS must be a number or None, '
                f'got {game_target_fps!r}'
            )
            raise TypeError(message)
        if not math.isfinite(game_target_fps) or game_target_fps < 0:
            message = (
                f'{scene_class.__name__}.TARGET_FPS must be a finite number >= 0 '
                f'(0 = uncapped), got {game_target_fps!r}'
            )
            raise ValueError(message)

        return float(game_target_fps)

    @classmethod
    def initialize_arguments(cls, game: type[Scene] | Scene) -> dict[str, Any]:
        """Initialize the game arguments.

        A game argument with a flag the engine already added (a tool's, ``--force``, or a
        general one, ``--resolution``) is refused before anything runs: the process exits
        ``ExitCode.OPTIONS_REFUSED`` with a message naming the flag
        (``reserved_flag_refusal``), not argparse's traceback.

        Args:
            game: The game instance.

        Returns:
            options (dict[str, Any]): The game arguments. They are returned, never stored on
                the game: the game's class is shared by every context, so each engine keeps its
                own (``self.options``) and the scene gets them at construction.

        """
        parser: argparse.ArgumentParser = argparse.ArgumentParser(
            f'{game.NAME} version {game.VERSION}',
        )

        parser = GameEngine.args(parser)

        # args is a class method, which allows us to call it before initializing a game
        # object, which allows us to query all of the game engine objects for their
        # command line parameters. It is optional (Scene does not declare it): looked up by name
        game_args_method: Callable[..., Any] | None = getattr(game, 'args', None)
        if game_args_method is not None:
            try:
                game_args_method(parser.add_argument_group(f'{game.NAME} v{game.VERSION} Options'))
            except argparse.ArgumentError as error:
                # Every game has the engine's flags, so a clash fails every run of the game, not
                # only a tool's: said as a usage error, with the engine's code for one
                parser.exit(
                    status=ExitCode.OPTIONS_REFUSED,
                    message=(
                        f'{parser.prog}: error: '
                        f'{reserved_flag_refusal(game_name=game.NAME, error=error)}\n'
                    ),
                )

        args: argparse.Namespace = parser.parse_args()

        # Set the logging level
        logging.basicConfig(
            format=LOG_FORMAT,
            level=args.log_level.upper(),
        )
        if game_args_method is None:
            # A hint for the game's author, at INFO (--log-level info shows it). Logged once the
            # level is set: before basicConfig only Python's last-resort handler saw it, which
            # drops INFO, so it never showed at any level (D18's report)
            cls.log.info('Game does not implement arguments.  Add a def args(parser) class method.')

        # Stored on nothing here: __init__ keeps them as the engine's own (self.options)
        options: dict[str, Any] = vars(args)

        # Resolve the effective target FPS; --target-fps defaults to None so that an explicit
        # value (including 0 = uncapped) can be told apart from "not passed".
        options['target_fps'] = cls.resolve_target_fps(
            command_line_target_fps=options.get('target_fps'),
            game=game,
        )

        return options

    def _warn_about_a_pygame_that_may_own_the_signals(self: Self) -> None:
        """Warn when pygame runs already, started without SDL's signal handlers turned off.

        pygame started with the hint already '1' (an earlier engine in this process, or a host
        that set it, such as the test harness) has no SDL handlers: nothing to warn about. The
        hint now is not the hint pygame started under: one found started without it stays
        suspect (every engine warns) until pygame is found stopped.
        """
        if not pygame.get_init():
            GameEngine.PYGAME_FOUND_WITH_SDL_SIGNAL_HANDLERS = False  # type: ignore[reportConstantRedefinition]
        elif (
            GameEngine.PYGAME_FOUND_WITH_SDL_SIGNAL_HANDLERS
            or os.environ.get(SDL_NO_SIGNAL_HANDLERS_HINT) != '1'
        ):
            GameEngine.PYGAME_FOUND_WITH_SDL_SIGNAL_HANDLERS = True  # type: ignore[reportConstantRedefinition]
            self.log.warning(
                'pygame was initialized before the engine, so SDL may own SIGINT and SIGTERM '
                '(turning them into QUIT events); the engine still installs its own handlers '
                "when it starts, which replace SDL's"
            )

    @_clear_a_half_made_engine
    def __init__(  # ruff: ignore[too-many-statements]
        self: Self,
        game: type[Scene] | Scene,
        icon: pygame.Surface | Path | str | None = None,
    ) -> None:
        """Initialize the game engine.

        Args:
            game: The game instance.
            icon: The game icon.

        """
        super().__init__()
        # The game's scene class, before and after start() (audit C9: this engine's own;
        # GameEngine.game is a class-only view of it), set first so no view finds the engine
        # without its game. The scene start() builds from it is running_game.instance
        # (glitchygames/engine/running_game.py; the owner, 2026-10-29)
        self.game: Any = game
        self.running_game = RunningGame(game_class=game)
        # The on_*_event names this engine missed (each logged once), the last one looked up,
        # and the event types no handler took (each logged once): audit C11, one set per engine
        self.missing_events: list[str] = []
        self.last_event_miss: str = ''
        self.unimplemented_events: list[int] = []
        # The frame-pacing timer, created as the run starts (_configure_timer_and_performance);
        # declared early, as a rebaseline names its run (measurement_run) before then
        self.timer: Any = None
        # Event type -> this engine's handler, filled by initialize_event_handlers (audit C10:
        # one map per engine, so a second engine's handlers never replace the first's)
        self.event_handlers: dict[int, Callable[..., Any]] = {}

        self.initialize_icon(icon=icon)

        options = self.initialize_arguments(game=game)
        # This engine's parsed command line (audit C8: its own; GameEngine.OPTIONS is a
        # read-only view of it), set before the engine is current below
        self.options: dict[str, Any] = options
        # The current context's engine from here on (current_engine()): every piece of the
        # engine's own state is set above this line, so no view finds a half-made engine (if
        # the rest raises, _clear_a_half_made_engine clears it again)
        current_context().value(slot=CURRENT_ENGINE_SLOT).engine = self
        # The SDL driver variables as they were before --headless or --video-driver set them
        # (by name; None: the variable was not set), put back when the run ends
        # (_restore_sdl_driver_variables); None when the run changed neither
        self._sdl_driver_variables_before_run: dict[str, str | None] | None = None
        # Before anything starts the display or the mixer (pygame.init() below)
        # An inner context (glitchygames/render_target.py) shares the process's drivers with
        # every other context: it never changes the variables or restarts the display or mixer
        if not is_inner_context():
            self._choose_sdl_drivers(options=options)

        # NOTE: Game is coupled to event manager for unhandled event routing.
        # Decoupling tracked in https://glitchy-games.atlassian.net/browse/GG-22
        super().__init__()

        self._active_scene: Scene | None = None
        # The signals exit_on_signal is installed for (by start(), and around a wait for child
        # processes: _waiting_for_child_processes, which --audit uses before start() runs)
        self._installed_signal_handlers: list[int] = []

        # A tool given as a game flag that runs in place of the game runs now, before this
        # engine starts pygame or opens a window: a harness tool builds its own engine (a second
        # one inside this one would find pygame started and resize this one's window), and a
        # tool that runs no game needs none
        self._run_game_flag_tool(game=game, options=options)

        # A replay's recorded options and seed are in place from here on (start_replay), so
        # everything below reads the options as the recorded run did
        self.replay_sources = self._start_requested_replay(game=game, options=options)
        # --rebaseline NEW records the replay into NEW (glitchygames/replay/rebaseline.py); its
        # options were checked with the replay's
        rebaseline_path = options.get('rebaseline')
        self.rebaseline = (
            None
            if self.replay_sources is None or rebaseline_path is None
            else Rebaseline(
                replay_sources=self.replay_sources,
                source_path=Path(options['replay_trace']),
                destination=Path(rebaseline_path),
                # A headless replay: its frames are not paced
                measurement_run=self.measurement_run(
                    game=game,
                    processing_paced=False,
                    rebaselined_from=stored_path(
                        path=options['replay_trace'],
                        project_root=find_project_root(start=Path.cwd()),
                    ),
                ),
                game_class=scene_class_of(game),
            )
        )
        # Set the master seed of the engine random streams before any game code runs
        # (see glitchygames/randomness.py); start_replay already seeded them with the recorded
        # seed
        self.random_seed: int = (
            self.replay_sources.random_seed
            if self.replay_sources is not None
            else seed_engine_random(seed=self._live_random_seed(options=options))
        )
        self._log_the_runs_seed(options=options)
        # The background a scene that sets none shows (glitchygames/backgrounds.py); without
        # the option the process's default (the test pattern) stays
        default_background = options.get('default_background')
        if default_background is not None:
            set_active_default_background_pattern(pattern=BackgroundPattern(default_background))

        # Unhandled events by type, reported at teardown (see unhandled_event_report); their
        # first-seen times are elapsed_seconds() readings, the frame clock that
        # reset_sources() below restarts, so they count from this engine's start
        self.unhandled_events: dict[int, UnhandledEventRecord] = {}

        # Pygame stuff.
        pygame.register_quit(self.quit_game)
        self.fps: float = options.get('target_fps', DEFAULT_TARGET_FPS)
        self.update_type: str = options.get('update_type', 'update')
        self.use_gfxdraw = options.get('use_gfxdraw')
        self.windowed = options.get('windowed')
        self.desired_resolution: Any = options.get('resolution')
        self.fps_log_interval_ms = options.get('fps_log_interval_ms')
        self.pygame_version = {'major': 0, 'minor': 0, 'patch': 0}

        self.pygame_version['major'] = pygame.version.vernum[0]
        self.pygame_version['minor'] = pygame.version.vernum[1]
        self.pygame_version['patch'] = pygame.version.vernum[2]

        # For compatibility with older versions of pygame, use fast events
        #
        # For versions >= 2.2, we can use the new event loop
        if pygame_needs_fastevents():
            GameEngine.USE_FASTEVENTS = True  # type: ignore[reportConstantRedefinition]

        # Ensure Linux/X11 sends DOWN on focus clicks
        os.environ.setdefault('SDL_MOUSE_FOCUS_CLICKTHROUGH', '1')

        # The engine alone owns the process's signals. By default SDL installs a C-level
        # SIGINT/SIGTERM handler at init (wherever the signal is still SIG_DFL) that turns the
        # signal into a QUIT event, which signal.getsignal cannot see (it still reports
        # SIG_DFL): SIGTERM would end the run as a normal quit, exit SUCCESS and be recorded as
        # an external QUIT. A value set beforehand wins. SDL_HINT_NO_SIGNAL_HANDLERS:
        # https://wiki.libsdl.org/SDL2/SDL_HINT_NO_SIGNAL_HANDLERS
        self._warn_about_a_pygame_that_may_own_the_signals()
        os.environ.setdefault(SDL_NO_SIGNAL_HANDLERS_HINT, '1')

        # Shorten the GIL switch interval before audio starts: the mixer's channel-finished
        # callback needs the GIL to queue the next live-voice chunk (BUGS.md #27).
        sys.setswitchinterval(GIL_SWITCH_INTERVAL_SECONDS)
        self.log.debug('GIL switch interval set to %s seconds', GIL_SWITCH_INTERVAL_SECONDS)

        # Initialize all of the Pygame modules.
        self.init_pass, self.init_fail = pygame.init()
        self.print_game_info(game=game)

        # Enable fast events for multithreaded applications on older
        # versions of pygame, or use the new event loop for newer
        # versions of pygame >= 2.2
        if self.USE_FASTEVENTS and hasattr(pygame, 'fastevent'):
            self.log.info('Using pygame.fastevents for pygame version %s', pygame.version.ver)
            pygame.fastevent.init()  # type: ignore[attr-defined]
        else:
            # This is the default mode when USE_FASTEVENTS is disabled.
            #
            # pygame.event doesn't have an init() method, so nothing to do.
            self.log.info('Using pygame.events for pygame version %s', pygame.version.ver)

        # Fresh doors for this run (glitchygames/sources.py): the replay's when --replay-trace
        # is given, else live ones
        reset_sources()
        # reset_sources() leaves the polled input alone (glitchygames/sources.py is a leaf)
        reset_current_input()
        # ...and the internal-post tracker (glitchygames/recording.py): no owners, none pending.
        # Then the engine owns it for the whole run, so every code-posted event's origin is
        # known whenever it is needed (an instant-replay journal begun mid-run, a recording
        # started late); _pump_events forgets the posts after each pump
        reset_internal_post_tracking()
        start_tracking_internal_posts()
        # A live run is hosted: the outer game (glitchygames/host.py) reads through the live
        # doors and drives the frames. A replay has no host (its viewer is its outer game)
        self.host: GameHost | None = None
        # The run's session with the local AI service, if it has one (glitchygames/ai_link.py)
        self.ai_link: AiLink | None = None
        if self.replay_sources is None:
            live_sources = self.build_live_sources(
                random_seed=self.random_seed,
                # A recorded run captures scene starts from its first scene on, which
                # is built before recording starts (glitchygames/scene_start.py)
                captures_scene_starts=options.get('record_trace') is not None,
            )
            self.ai_link = create_link(options=options)
            self.host = GameHost(
                # Live play against OLD draws OLD over each presented frame
                sources=self._host_sources(inner=live_sources, overlay=self.onion_skin)
            )
            install_sources(sources=self.host.sources)
        else:
            install_sources(sources=self.replay_sources)

        # We are fully initialized now; the scene (self.game, set at the top) starts once
        # .start() is called on the GameEngine object

        # SceneManager is a singleton.
        self.scene_manager: SceneManager = SceneManager()
        # A watched replay's F3/F4 (and its pause at a divergence) act on the scene manager's
        # debug overlay, the one drawn (glitchygames/replay/controls.py)
        if self.replay_sources is not None:
            # With the panel a restarted replay's viewer had chosen (ReplayOptions.viewer_state)
            self.scene_manager.debug_overlay.panel = (
                self.replay_sources.controls.debug_overlay.panel
            )
            self.replay_sources.controls.debug_overlay = self.scene_manager.debug_overlay
        # The singleton outlives an earlier engine in this process: this run starts fresh (its
        # frames numbered from 0, as reset_sources() above restarted the frame clock, and no
        # supervision, quit request, shake or playback state left from an earlier run)
        self.scene_manager.begin_run()
        # An earlier run's audio engine in this process (a test run, a recording and then its
        # replay) plays on that run's partition: this run makes its own on first use
        from glitchygames.audio.engine import discard_audio_engine

        discard_audio_engine(wait_seconds=0.0)
        # A watched replay pauses at each recorded breakpoint, such as a saved bookmark (rule 16
        # of glitchygames/replay/driver.py); nobody could unpause a headless one
        if self.replay_sources is not None and not self.replay_sources.options.headless:
            self.scene_manager.add_control_event_handler(
                kind=BREAKPOINT_KIND, handler=self.replay_sources.controls.pause_at_breakpoint
            )

        # Update the scene manager's update_type from the engine's options
        self.scene_manager.update_type = self.update_type

        # Resolution initialization.
        # Convert our resolution to a tuple
        resolution_parts: list[str] = str(self.desired_resolution).split('x')
        desired_width: str = resolution_parts[0]
        desired_height: str = resolution_parts[1]

        if options.get('headless'):
            # No window to scale or resize: SCALED asks the dummy driver for a renderer it does
            # not have ("no fast renderer available") (BUGS.md #178 item 32)
            self.mode_flags: int = 0
        elif self.windowed:
            self.mode_flags = pygame.DOUBLEBUF | pygame.SCALED | pygame.RESIZABLE
        else:
            self.mode_flags = (
                pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.SCALED | pygame.RESIZABLE
            )

        self.desired_resolution = self.suggested_resolution(
            int(desired_width),
            int(desired_height),
        )

        # window icon and system tray/dock icon
        self.initialize_system_icons()

        # Initialize display
        self.initialize_display()
        # A replay's window opened at the recorded size (start_replay asked for it), or the
        # replay is refused: the game would be set up on another size (rule 1 of
        # glitchygames/replay/driver.py)
        self._refuse_a_replay_display_of_another_size(options=options)
        # Live play against OLD needs OLD's size too, checked on the window as it opened
        self._refuse_a_live_display_of_another_size_than_old()

        self.initialize_event_handlers()

        self.print_system_info()

        # Declare instance variables that are initialized later by _initialize_event_managers()
        # (called from start()) and by start() itself. Declaring them here satisfies
        # basedpyright's reportUninitializedInstanceVariable check.
        self.registered_events: dict[int, Callable[..., Any]] = {}
        self.app_manager: AppEventManager
        self.audio_manager: AudioEventManager
        self.live_voice_channels: tuple[int, ...] = ()
        # The mixer's channels: live voices, the sound library's, the legacy rest (set as the
        # event managers are made; None before)
        self.channel_partition: ChannelPartition | None = None
        self.drop_manager: DropEventManager
        self.controller_manager: ControllerEventManager | None = None
        self.touch_manager: TouchEventManager
        self.font_manager: FontManager
        self.game_manager: GameEventManager
        self.joystick_manager: JoystickEventManager
        self.keyboard_manager: KeyboardEventManager
        self.midi_manager: MidiEventManager
        self.mouse_manager: MouseEventManager
        self.window_manager: WindowEventManager
        # Every joystick and game controller the game sees (glitchygames/input/input_devices.py),
        # following the joystick and controller managers; built with them
        self.input_devices: InputDevices = InputDevices()
        # The live devices while a playback scope plays on its own (enter_playback_devices)
        self._live_devices_behind_scope: LiveDevicesBehindScope | None = None

    def initialize_display(self: Self) -> None:
        """Initialize the display."""
        # Let's try to set a resolution to the most compatible for
        # the system.  If we don't provide any parameters, we'll get
        # a reasonble default, but you should consider whether that's
        # a good idea for your particular application.
        #
        # There are various caveats for hardware accelerated blitting
        # that make it undesirable in a lot of cases, so we'll just use
        # software.
        # An inner context draws on its render target: it never opens or resizes the window nor
        # sets its cursor (row S1 of plans/2026-10-25-engine-context.md;
        # glitchygames/render_target.py)
        inner_target = render_target()
        if inner_target is not None:
            self.display_info = pygame.display.Info()
            self.initial_resolution = inner_target.get_size()
            self.cursor = []
            self.display_update = pygame.display.update
            self.screen = inner_target
            paint_default_background(surface=self.screen)
            self.scene_manager.screen = self.screen
            return
        self.display_info = pygame.display.Info()
        self.initial_resolution: tuple[int, int] = (
            self.display_info.current_w,
            self.display_info.current_h,
        )

        self.cursor: list[str] = self.set_cursor(cursor=None)

        # Set the screen update type.
        if self.scene_manager.update_type == 'update':
            self.display_update = pygame.display.update
        elif self.scene_manager.update_type == 'flip':
            self.display_update = pygame.display.flip
        else:
            self.log.error('Screen update type was neither "update" nor "flip".')

        # The Pygame documentation recommends against using hardware accelerated blitting.
        #
        # Note that you can also get the screen with pygame.display.get_surface()
        #
        # An existing window (a test's, or one a game opened first) may take its new size
        # only after set_mode returns (x11): the game is set up on the size it really has
        self.screen: pygame.Surface = set_display_mode(
            size=self.desired_resolution,
            flags=self.mode_flags,
        )
        # A new display is black, which cannot be told from "nothing rendered": until the
        # first scene draws, it shows the default background (glitchygames/backgrounds.py)
        paint_default_background(surface=self.screen)
        # A scene manager made before this display (pygame started first) holds the surface
        # of the display it saw then, which a --headless restart closed: it draws on this one
        self.scene_manager.screen = self.screen

    def initialize_event_handlers(self: Self) -> None:
        """Initialize event handlers.

        The engine calls this on your behalf.

        Event subsystem bootstrapping

        This gives us much faster event processing than
        doing a lookup every time an event comes in since
        we can just call the processing function directly.

        It's not as fast as a raw pygame event loop,
        but since we layer richer event types on top of
        the pygame raw events, this gives us a nice balance
        of extensibility with performance.

        """
        for event_type in events.AUDIO_EVENTS:
            self.event_handlers[event_type] = self.process_audio_event

        for event_type in events.APP_EVENTS:
            self.event_handlers[event_type] = self.process_app_event

        for event_type in events.MIDI_EVENTS:
            self.event_handlers[event_type] = self.process_midi_event

        for event_type in events.WINDOW_EVENTS:
            self.event_handlers[event_type] = self.process_window_event

        for event_type in events.GAME_EVENTS:
            self.event_handlers[event_type] = self.process_game_event

        self.initialize_input_event_handlers()

        # Enable all events, except the window system's raw messages (SYSWMEVENT) unless the
        # game declares NATIVE_WINDOW_MESSAGES = True.
        # Note that glitchygames will auto-suppress events not handled
        # by the game once they are encountered, so it is recommended to enable all.
        events.allow_every_event_type(
            native_window_messages=self.native_window_messages(game=self.game)
        )

    @staticmethod
    def native_window_messages(*, game: type[Scene] | Scene) -> bool:
        """Read whether the game asks for the window system's raw messages (SYSWMEVENT).

        Args:
            game: The game scene class or instance, which may declare NATIVE_WINDOW_MESSAGES.

        Returns:
            bool: The game's NATIVE_WINDOW_MESSAGES (False when it declares none).

        Raises:
            TypeError: If the game's NATIVE_WINDOW_MESSAGES is not a bool.

        """
        # Looked up by name: a game need not be a Scene subclass
        native_window_messages = getattr(game, 'NATIVE_WINDOW_MESSAGES', False)
        if not isinstance(native_window_messages, bool):
            scene_class = scene_class_of(game)
            message = (
                f'{scene_class.__name__}.NATIVE_WINDOW_MESSAGES must be a bool, '
                f'got {native_window_messages!r}'
            )
            raise TypeError(message)
        return native_window_messages

    def initialize_input_event_handlers(self: Self) -> None:
        """Initialize input event handlers.

        The engine calls this on your behalf.

        This initializes the input event handlers.

        """
        for event_type in events.CONTROLLER_EVENTS:
            self.event_handlers[event_type] = self.process_controller_event

        for event_type in events.DROP_EVENTS:
            self.event_handlers[event_type] = self.process_drop_event

        for event_type in events.TOUCH_EVENTS:
            self.event_handlers[event_type] = self.process_touch_event

        for event_type in events.JOYSTICK_EVENTS:
            self.event_handlers[event_type] = self.process_joystick_event

        for event_type in events.KEYBOARD_EVENTS:
            self.event_handlers[event_type] = self.process_keyboard_event

        for event_type in events.MOUSE_EVENTS:
            self.event_handlers[event_type] = self.process_mouse_event

        for event_type in events.TEXT_EVENTS:
            self.event_handlers[event_type] = self.process_text_event

    @property
    def input(self: Self) -> InputSnapshot:
        """The polled input captured at the latest pump (glitchygames/input/state.py).

        Read in ``dt_tick``, which runs before the frame's pump, it is the previous frame's
        snapshot; see ``current_input``.

        Returns:
            The snapshot.

        """
        return current_input()

    @property
    def screen_width(self: Self) -> int:
        """The screen width.

        Returns:
            int: The screen width.

        """
        return self.screen.get_width()

    @property
    def screen_height(self: Self) -> int:
        """The screen height.

        Returns:
            int: The screen height.

        """
        return self.screen.get_height()

    def print_system_info(self: Self) -> None:
        """Print system information."""
        # General Info
        self.log.info('Pygame Version: %s', pygame.version.ver)
        self.log.info('CPU Count: %s', multiprocessing.cpu_count())
        self.log.info('System: %s', platform.system())
        self.log.info('Machine: %s', platform.machine())
        self.log.info('Platform: %s', platform.platform())
        self.log.info('Platform (Terse): %s', platform.platform(aliased=False, terse=True))
        self.log.info('Processor: %s', platform.processor())
        self.log.info('Release: %s', platform.release())

        # Set up a display mode.
        # Note: pygame.display.init() isn't necessary here
        # because we've already called pygame.init() which
        # initializes all available modules.
        #
        # Let's do a sanity check and make sure we're initialized.
        self.log.info('Display inited: %s', pygame.display.get_init())

        # Display some configuration information.
        self.log.info('SDL Version: %s', pygame.get_sdl_version())
        self.log.info('SDL Byte Order: %s', pygame.get_sdl_byteorder())

        # Dump a bit more info about the configured mode.
        self.log.info('Display Driver: %s', pygame.display.get_driver())
        # Formatted here, not by logging: LogRecord checks isinstance(args[0], Mapping), and
        # pygame-ce's VidInfo raises AttributeError for __class__, which CPython 3.14.2
        # (Pyodide 314's) lets through isinstance (fixed in the pygame-ce fork; see
        # plans/2026-10-23-game-host-and-browser-runner.md)
        self.log.info('Display Info: %s', str(self.display_info))  # ruff: ignore[logging-eager-conversion] - VidInfo breaks LogRecord's isinstance (above)
        self.log.info('Initial Resolution: %s', self.initial_resolution)
        self.log.info('8-bit Modes: %s', pygame.display.list_modes(8))
        self.log.info('16-bit Modes: %s', pygame.display.list_modes(16))
        self.log.info('24-bit Modes: %s', pygame.display.list_modes(24))
        self.log.info('32-bit Modes: %s', pygame.display.list_modes(32))
        self.log.info(
            'Best Color Depth: %s (%s)',
            (pygame.display.mode_ok(self.initial_resolution), self.mode_flags),
            self.mode_flags,
        )
        self.log.info('Window Manager Info: %s', pygame.display.get_wm_info())
        self.log.info('Platform Timer Resolution: %s', pygame.TIMER_RESOLUTION)

    def print_game_info(self: Self, *, game: type[Scene] | Scene) -> None:
        """Log the game's title and version.

        Args:
            game: The game scene class or instance (the engine's own ``game``, which
                __init__ sets first).

        """
        self.log.debug(
            'Successfully loaded %s modules and failed loading %s modules.',
            self.init_pass,
            self.init_fail,
        )

        # The game's name and version, not the engine's placeholder "Boilerplate Adventures"
        # (BUGS.md #178 item 27)
        self.log.info('Game Title: %s', game.NAME)
        self.log.info('Game Version: %s', game.VERSION)

    def suggested_resolution(
        self: Self,
        desired_width: int = 0,
        desired_height: int = 0,
    ) -> tuple[int, int]:
        """Suggest a resolution.

        Args:
            desired_width (int): The desired width.
            desired_height (int): The desired height.

        Returns:
            tuple[int, int]: The suggested resolution.

        """
        # For Ubuntu 19.04, we can't reset the original res
        # so let's just let the system figure it out.
        if platform.system() == 'Linux':
            if 'arm' not in platform.machine():
                self.log.info('Ignoring full screen resolution change on Linux.')
            else:
                # RPi Hack
                #
                # The Raspberry Pi screen exposes
                # 2 resolutions, but only one works properly
                desired_width = 800
                desired_height = 480

        return (int(desired_width), int(desired_height))

    @classmethod
    def set_cursor(
        cls,
        cursor: list[str] | None,
        cursor_black: str = '.',
        cursor_white: str = 'X',
        cursor_xor: str = 'o',
    ) -> list[str]:
        """Set the cursor.

        Args:
            cursor (list[str]): The cursor.
            cursor_black (str): The black cursor.
            cursor_white (str): The white cursor.
            cursor_xor (str): The xor cursor.

        Returns:
            list[str]: The cursor.

        """
        if not cursor:
            # Cursor setup.
            # Cursor width/height must be a multiple of 8
            cursor = [
                'XX                      ',
                'XXX                     ',
                'XXXX                    ',
                'XX.XX                   ',
                'XX..XX                  ',
                'XX...XX                 ',
                'XX....XX                ',
                'XX.....XX               ',
                'XX......XX              ',
                'XX.......XX             ',
                'XX........XX            ',
                'XX........XXX           ',
                'XX......XXXXX           ',
                'XX.XXX..XX              ',
                'XXXX XX..XX             ',
                'XX   XX..XX             ',
                '     XX..XX             ',
                '      XX..XX            ',
                '      XX..XX            ',
                '       XXXX             ',
                '       XX               ',
                '                        ',
                '                        ',
                '                        ',
            ]

        cursor_width: int = len(cursor[0])
        cursor_height: int = len(cursor)

        # Compile our cursor so we can draw it to the screen.
        cursor_data, cursor_mask = pygame.cursors.compile(
            cursor,
            black=cursor_black,
            white=cursor_white,
            xor=cursor_xor,
        )

        # Now set the cursor as the active cursor.
        pygame.mouse.set_cursor((cursor_width, cursor_height), (0, 0), cursor_data, cursor_mask)

        return cursor

    def initialize_system_icons(self: Self) -> None:
        """Initialize system icons."""
        # Set the window icon.
        #
        # Always call this before you call set_mode()

        # Looked up by name: icon is optional on a game (Scene does not declare it)
        icon_attr: pygame.Surface | None = getattr(self.game, 'icon', GameEngine.icon)

        if icon_attr is None:
            icon_attr = pygame.Surface((32, 32))
            icon_attr.fill(PURPLE)

        icon: pygame.Surface = icon_attr

        # The window's icon and caption are its owner's: an inner context sets neither (row S2
        # of plans/2026-10-25-engine-context.md)
        if is_inner_context():
            return
        pygame.display.set_icon(icon)

        # The game's caption until its scene sets its own, not the engine's placeholder
        # "Boilerplate Adventures" (BUGS.md #178 item 27)
        caption = f'{self._game_name()} v{getattr(self.game, "VERSION", self.VERSION)}'
        pygame.display.set_caption(caption, caption)

        # Get captions:
        (title, icontitle) = pygame.display.get_caption()
        self.log.info('Window Title: %s', title)
        self.log.info('Icon Title: %s', icontitle)

    def _initialize_event_managers(self: Self) -> None:
        """Initialize all event managers for the game engine."""
        self.registered_events = {}
        # The managers are shared instances (ResourceManager): this run builds its own, opening
        # devices through its own doors, instead of getting an earlier run's in this process
        events.ResourceManager.release_shared_instances()
        from glitchygames.events.app import AppEventManager

        self.app_manager = AppEventManager(game=self.scene_manager)
        self.audio_manager = AudioEventManager(game=self.scene_manager)

        # Partition the mixer's channels now, before anything can play (sound engine impl spec
        # 7.1), unless the game's construction already asked for audio
        self.reserved_channel_partition()

        self.drop_manager = DropEventManager(game=self.scene_manager)

        # Which devices and events the game sees (glitchygames/input/input_devices.py, rule 2):
        # auto (the default) both layers, a mapped pad dispatching its controller events and
        # any other device its joystick events; joystick the joystick layer only; controller
        # mapped pads only. Joystick events are never blocked at SDL: blocking them interferes
        # with CONTROLLERDEVICEADDED/REMOVED on macOS (they are dropped at dispatch instead)
        input_mode = InputMode(self.options.get('input_mode', InputMode.AUTO))

        if input_mode is InputMode.JOYSTICK:
            self.controller_manager = None
            events.set_event_types_allowed(event_types=events.CONTROLLER_EVENTS, allowed=False)
            LOG.info('Input mode: joystick (controller events blocked)')
        else:
            self.controller_manager = ControllerEventManager(game=self.scene_manager)
            LOG.info('Input mode: %s (SDL Game Controller API)', input_mode)

        self.touch_manager = TouchEventManager(game=self.scene_manager)
        # https://glitchy-games.atlassian.net/browse/GG-23
        self.font_manager = FontManager(game=self.scene_manager)
        self.game_manager = GameEventManager(game=self.scene_manager)
        self.joystick_manager = JoystickEventManager(game=self.scene_manager)
        self.keyboard_manager = KeyboardEventManager(game=self.scene_manager)
        self.midi_manager = MidiEventManager(game=self.scene_manager)
        self.mouse_manager = MouseEventManager(game=self.scene_manager)
        self.window_manager = WindowEventManager(game=self.scene_manager)

        # The devices the managers just opened (no scene is running yet to be told)
        self.input_devices = InputDevices(input_mode=input_mode)
        self._synchronize_input_devices()

    def _synchronize_input_devices(self: Self) -> None:
        """Follow the managers' devices, telling the active scene which came and went.

        Called once the managers are made and after every device event they handle
        (glitchygames/input/input_devices.py, rule 3).
        """
        changes = self._follow_the_managers_devices()
        for device in changes.removed:
            self.scene_manager.on_input_device_removed(device=device)
        for device in changes.added:
            self.scene_manager.on_input_device_added(device=device)

    def _follow_the_managers_devices(
        self: Self, *, controllers_complete: bool = False
    ) -> InputDeviceChanges:
        """Bring ``input_devices`` in line with the devices the managers hold, telling no scene.

        Args:
            controllers_complete: True when the controller manager holds every game controller
                (``InputDevices.synchronize``): an instant replay's adopted devices.

        Returns:
            The devices added and removed.

        """
        controller_manager = self.controller_manager
        return self.input_devices.synchronize(
            controllers_complete=controllers_complete,
            joysticks={
                proxy.instance_id: proxy.joystick
                for proxy in self.joystick_manager.joysticks.values()
            },
            controllers=(
                {}
                if controller_manager is None
                else {
                    proxy.instance_id: proxy.controller
                    for proxy in controller_manager.controllers.values()
                }
            ),
        )

    def enter_playback_devices(
        self: Self, *, recorded: RecordedDevices, registry: ReplayDeviceRegistry
    ) -> None:
        """Set the live devices aside and open the playback's own (SceneManager._enter_playback).

        Called once the scope's doors are pushed, in the input mode the recording was made in,
        so the played scene sees the devices the recorded run saw and its recorded device
        events (JOYDEVICEADDED, ...) change only those (BUGS.md #184.3). A recording file's
        devices are opened through the scope's devices door as the recorded engine opened them
        at startup (the same calls, so the answers it gave are taken in order); an instant
        replay's are adopted from its journal (``recorded.scene_start_devices``) asking the door
        nothing, since its answers are the scene's own. The managers stay the same shared
        instances; only the devices they hold change. No scene is told: the played scene is
        rebuilt and reads ``input_devices`` as the recorded one did.

        Args:
            recorded: The recording's input mode and, for an instant replay, its devices.
            registry: The scope's devices door (the played recording's).

        Raises:
            RuntimeError: If a scope's devices are already in place.

        """
        if self._live_devices_behind_scope is not None:
            message = 'A playback scope already holds the devices'
            raise RuntimeError(message)
        input_mode = recorded.input_mode
        live_controller_manager = self.controller_manager
        self._live_devices_behind_scope = LiveDevicesBehindScope(
            joysticks=self.joystick_manager.joysticks,
            controller_manager=live_controller_manager,
            controllers=(
                None if live_controller_manager is None else live_controller_manager.controllers
            ),
            input_devices=self.input_devices,
            scope_made_the_controller_manager=(
                live_controller_manager is None and input_mode is not InputMode.JOYSTICK
            ),
        )
        adopted = recorded.scene_start_devices
        adopted_controllers: dict[int, OpenedController] = {}
        if adopted is not None:
            for descriptor in adopted:
                device = registry.adopt_device(descriptor=descriptor)
                if isinstance(device, ReplayController):
                    adopted_controllers[descriptor.device_index] = device
        # The controller layer first, as the engine makes its managers (_initialize_event_managers)
        if input_mode is InputMode.JOYSTICK:
            self.controller_manager = None
        elif live_controller_manager is not None:
            live_controller_manager.controllers = (
                live_controller_manager.open_connected_controllers()
                if adopted is None
                else live_controller_manager.adopt_controllers(controllers=adopted_controllers)
            )
        else:
            # A recording file's (an instant replay's mode is the live game's): it opens the
            # recording's controllers as it is made. Its construction allows controller events
            # at SDL: the live game (joystick mode) keeps them blocked, and the scope's events
            # come from the recording, not SDL
            self.controller_manager = ControllerEventManager(game=self.scene_manager)
            events.set_event_types_allowed(event_types=events.CONTROLLER_EVENTS, allowed=False)
        self.joystick_manager.joysticks = (
            self.joystick_manager.open_connected_joysticks()
            if adopted is None
            else self.joystick_manager.adopt_joysticks(descriptors=adopted)
        )
        self.input_devices = InputDevices(input_mode=input_mode)
        # The journal says which of its devices are game controllers: the door is not asked
        self._follow_the_managers_devices(controllers_complete=adopted is not None)

    def exit_playback_devices(self: Self) -> None:
        """Put the live devices back as the scope ends (SceneManager._exit_playback; none if none).

        The playback's devices are dropped (a replay's stand-ins hold no hardware). No scene is
        told: the live scene's devices are the ones it had, and the player's device events
        during the scope were held and are delivered after it (glitchygames/replay/playback.py,
        rule 5).
        """
        live = self._live_devices_behind_scope
        if live is None:
            return
        self._live_devices_behind_scope = None
        self.joystick_manager.joysticks = live.joysticks
        if live.scope_made_the_controller_manager:
            ControllerEventManager.release_shared_instance()
        self.controller_manager = live.controller_manager
        if live.controller_manager is not None and live.controllers is not None:
            live.controller_manager.controllers = live.controllers
        self.input_devices = live.input_devices

    def _resolve_scene_name_for_error(self: Self) -> str:
        """Resolve the current or previous scene name for error reporting.

        Returns:
            The scene name string for error messages.

        """
        # The scene that was running, else (none active: the run ended before a scene began,
        # or after the last one) the scene before it
        scene = self.scene_manager.active_scene
        if scene is None:
            scene = self.scene_manager.previous_scene
        if scene is None:
            return 'None'
        # A scene without a name (an empty NAME) is named by its class
        return scene.NAME or scene.__class__.__name__

    def measurement_run(
        self: Self,
        *,
        game: type[Scene] | Scene,
        processing_paced: bool,
        rebaselined_from: str | None,
    ) -> MeasurementRun:
        """Return this run's provenance for a recording's ``measurement_runs`` (newest first).

        Its ``measured_at`` is the real time now: provenance only, never replayed or served to
        the game (tests/test_engine_doors.py allows this read for that reason). It names the
        game's source revision beside the engine's (``game_source_revision``): a ledger row's
        commit is the game's, so a game outside this repository names its own.

        Args:
            game: The game scene class or instance (a rebaseline names its run from
                ``__init__``, given the game it was constructed with).
            processing_paced: Whether the run paces its frames (a live run with a target FPS; a
                rebaseline, a headless replay, is not paced).
            rebaselined_from: The recording this run rebaselines, or None for a fresh recording.

        Returns:
            The run.

        """
        # Every run names its timer, paced or not: the one it has, or (a rebaseline names its run
        # while the engine starts, before any timer exists; a timer that failed to start) the
        # one its options make, uncalibrated
        pacing_timer = (
            pacing_timer_for_options(options=self.options)
            if self.timer is None
            else self.timer.pacing_timer()
        )
        return MeasurementRun(
            machine=machine_description(),
            processing_paced=processing_paced,
            engine_version=installed_engine_version(),
            pygame_version=pygame.version.ver,
            python_version=platform.python_version(),
            measured_at=clock.raw_wall_clock_time().isoformat(),
            rebaselined_from=rebaselined_from,
            hash_scheme=CONTENT_HASH_SCHEME,
            pacing_timer=pacing_timer,
            source_revision=engine_source_revision(),
            game_source_revision=game_source_revision(game=game),
            machine_state=current_machine_state(),
        )

    def trace_recording_header(self: Self) -> dict[str, Any]:
        """Build the header of a --record-trace recording.

        Returns:
            The game and scene class names, engine, pygame and Python versions, the screen
            size, every command-line option (JSON-safe), the start time and the random seed.

        """
        active_scene = self.scene_manager.active_scene
        engine_version = installed_engine_version()
        # The running game's scene (_build_game built it before any recording starts)
        game: Scene = self.running_game.instance
        game_class = type(game)
        return {
            'game_class': game_class.__name__,
            # With the class name, tells apart two games whose classes share a name
            'game_module': game_class.__module__,
            # The game's logical name, which replays compare (glitchygames/logical_names.py):
            # unchanged when the game's code moves
            GAME_HEADER_FIELD: logical_name(scene_class=game_class),
            'scene_class': None if active_scene is None else type(active_scene).__name__,
            'engine_version': engine_version,
            'pygame_version': pygame.version.ver,
            'python_version': platform.python_version(),
            'screen_size': [self.screen_width, self.screen_height],
            # Path options relative to the project root (stored_options)
            'options': {
                str(name): json_safe_value(value)
                for name, value in stored_options(options=self.options).items()
            },
            # The origin of the run's wall clock from here on, recorded and replayed alike:
            # recorded_at plus the frame clock (RecordingSources.wall_clock_time; rule 9 of
            # glitchygames/replay/driver.py), so game code reading it replays exactly
            RECORDED_AT_HEADER_FIELD: clock.raw_wall_clock_time().isoformat(),
            'random_seed': self.random_seed,
            # The engine's custom event ids this run allocated: a replay in a process that
            # allocated them otherwise moves the recorded events to its own (BUGS.md #211.1)
            CUSTOM_EVENT_TYPES_HEADER_FIELD: custom_event_types_header(),
            # Each run's provenance, newest first (glitchygames/recording_history.py): this one
            # paces its frames when it has a target FPS (0 is uncapped)
            MEASUREMENT_RUNS_HEADER_FIELD: [
                self.measurement_run(
                    game=game_class,
                    processing_paced=self.scene_manager.target_fps > 0,
                    rebaselined_from=None,
                ).to_json()
            ],
        }

    def start_trace_recording(self: Self, *, path: Path) -> GameplayRecorder:
        """Start recording the session to a trace file (before the first frame).

        The header also holds what the run took in before recording started: a snapshot of
        every save store the doors opened (``saves``), the descriptors of devices opened
        (``devices``) and the enumeration answers given (``device_enumeration``). Then
        ``RecordingSources`` are installed around the active doors and record every frame
        from what passes through them (glitchygames/recording.py). SIGTERM (and SIGHUP on
        Unix, SIGBREAK on Windows) ends a started run through the normal teardown
        (``exit_on_signal``, installed by ``start``), and so does SIGINT (KeyboardInterrupt).
        ``stop_trace_recording`` (called by ``_shutdown``) closes the file.

        Recording must start before the first frame: afterwards installing its doors raises
        ``SourcesAlreadyRunningError`` (from ``install_sources``; glitchygames/sources.py).

        Args:
            path: The recording's file.

        Returns:
            The recorder.

        Raises:
            TraceRecordingAlreadyStartedError: If this engine is already recording.

        """
        if self.trace_recorder is not None:
            message = (
                f'start_trace_recording() was called while recording to '
                f'{self.trace_recorder.path}; one run records once'
            )
            raise TraceRecordingAlreadyStartedError(message)
        inner = active_sources()
        registry = inner.devices()
        # A store a run started with --record-trace opened before recording started is in the
        # header as first opened: the first scene's setup() may have written to it since, and
        # the replay runs that setup() again (LiveSources.first_open_save_snapshots, read
        # through the host's doors in a hosted run)
        first_open_snapshots: Mapping[str, dict[str, Any]] = (
            inner.first_open_save_snapshots if isinstance(inner, LiveSources | HostSources) else {}
        )
        # A rebaseline copies these fields from the replayed recording instead (rebaseline.py)
        header = {
            **self.trace_recording_header(),
            SAVES_HEADER_FIELD: {
                namespace: (
                    first_open_snapshots[namespace]
                    if namespace in first_open_snapshots
                    else save_namespace_snapshot(saves=store)
                )
                for namespace, store in inner.opened_save_namespaces.items()
            },
            DEVICES_HEADER_FIELD: [
                descriptor.to_json() for descriptor in registry.take_opened_descriptors()
            ],
            DEVICE_ENUMERATION_FIELD: [
                answer.to_json() for answer in registry.take_enumeration_answers()
            ],
        }
        recorder = GameplayRecorder(path=path, header=header)
        install_sources(sources=RecordingSources(inner=inner, recorder=recorder))
        self.trace_recorder = recorder
        self.log.info('Recording gameplay to %s (random seed %s)', path, self.random_seed)
        return recorder

    def _start_requested_trace_recording(self: Self) -> None:
        """Start recording if --record-trace or --rebaseline was given (off by default).

        A rebaseline records over the replay (glitchygames/replay/rebaseline.py), with the
        replayed recording's header; ``stop_trace_recording`` closes it like any recording.
        """
        if self.rebaseline is not None:
            self.trace_recorder = self.rebaseline.start_recording()
            return
        record_trace_path = self.options.get('record_trace')
        if record_trace_path is not None:
            self.start_trace_recording(path=Path(record_trace_path))

    def stop_trace_recording(self: Self) -> None:
        """Close the recording, if one is running.

        The ``RecordingSources`` stay installed (the run is ending); with the recorder closed
        they only delegate.
        """
        recorder = self.trace_recorder
        if recorder is None:
            return
        self.trace_recorder = None
        recorder.close()
        if recorder.write_failed:
            self.recording_write_failed = True

    def _install_signal_handlers(self: Self) -> None:
        """Make each of terminating_signals() raise SystemExit, if nothing else handles it yet.

        Through ``install_exit_on_signal_handlers``, whose limitation applies: an engine started
        on another thread installs none (a recording is then left unclosed by SIGTERM).
        """
        self._installed_signal_handlers.extend(install_exit_on_signal_handlers())

    def _restore_signal_handlers(self: Self) -> None:
        """Put back the default handling of each signal _install_signal_handlers claimed."""
        installed, self._installed_signal_handlers = self._installed_signal_handlers, []
        restore_default_signal_handling(signal_numbers=installed)

    @contextlib.contextmanager
    def _waiting_for_child_processes(self: Self) -> Generator[None]:
        """Install the engine's signal handlers while this process waits for child processes.

        The one way the engine waits for children (``--audit``'s replays, which run in
        ``__init__`` before ``start`` installs the handlers; a watched replay's restarts, after
        ``_shutdown`` restored them): a SIGTERM (or SIGHUP, SIGBREAK) raises SystemExit
        (``exit_on_signal``), so ``subprocess.run`` kills and reaps the child instead of leaving
        it running, and this process exits with the signal's ``ExitCode``. The default handling
        comes back afterwards.

        Yields:
            Nothing: the wait runs inside.

        """
        self._install_signal_handlers()
        try:
            yield
        finally:
            self._restore_signal_handlers()

    def _log_the_runs_seed(self: Self, *, options: dict[str, Any]) -> None:
        """Log the seed a run uses, rolled or given (rows 1 and 2 of the user's seed rule).

        Every run names its seed at INFO, so a plain run (one that records nothing) can be run
        again under it with ``--random-seed``. A replay announces its seed itself
        (``announce_replay``).

        Args:
            options: The parsed options (``random_seed``: the seed given, or None).

        """
        if self.replay_sources is not None:
            return
        old = self.live_old_recording
        if old is None:
            how = 'rolled' if options.get('random_seed') is None else 'given'
        elif options.get('random_seed') is None:
            how = f"OLD's, from --compare-trace {old.path}"
        else:
            how = f'given; OLD was recorded under {old.random_seed}'
        self.log.info('Random seed %d (%s)', self.random_seed, how)

    def _live_random_seed(self: Self, *, options: dict[str, Any]) -> int | None:
        """Return the seed live play is given: ``--random-seed N``, else OLD's, else None.

        Live play against OLD starts under OLD's recorded seed, so OLD's ghost starts in the
        same world (rule 9 of glitchygames/replay/tools/compare.py), unless a seed is given.

        Args:
            options: The parsed options.

        Returns:
            The seed, or None to roll one.

        """
        given_seed: int | None = options.get('random_seed')
        if given_seed is None and self.live_old_recording is not None:
            return self.live_old_recording.random_seed
        return given_seed

    def _run_game_flag_tool(
        self: Self, *, game: type[Scene] | Scene, options: dict[str, Any]
    ) -> None:
        """Run the tool given as a game flag in place of the game, and end the process.

        Called by ``__init__`` right after the options are read (and ``--headless`` chose the
        dummy drivers), before this engine starts pygame, opens its window or installs its
        doors: a tool with a game handler (``run_game_flag_tool``,
        glitchygames/replay/tools/registry.py) never needs them. The golden-trace and
        scripted-session tools build their own engine for the game, which then starts pygame
        once, at its own size; a tool that runs no game builds nothing. The process ends with
        the tool's exit code (``exit_with``: SystemExit), ``ExitCode.SUCCESS`` included, so the
        game's ``start()`` never runs. The tool runs inside the exit-code mapping and signal
        handlers of ``start()``'s crash boundary, as it did when it ran there: an uncaught
        exception exits ``ExitCode.INTERNAL_ERROR`` (logged with its traceback), Ctrl-C
        ``ExitCode.INTERRUPTED``, a failed recording write ``ExitCode.CANNOT_WRITE_OUTPUT``, and
        a terminating signal its own code (``exit_on_signal``). The handlers and the SDL driver
        variables ``--headless`` set are put back first. Nothing happens when no such tool was
        given.

        Args:
            game: The game (its class, or a scene the game passed in).
            options: The game's parsed options.

        """
        # Only a tool with a game handler runs here; two tool flags without one (--record-trace
        # with --replay-trace) are left to the replay's own refusal, which says what to use
        tools = [tool for tool in given_tools(options=options) if tool.game_handler is not None]
        if not tools:
            return

        def run_the_tool() -> int:
            tool_exit_code = run_game_flag_tool(options=options, game=game)
            # A tool with a game handler always ends the run (its code, or a refusal's)
            assert tool_exit_code is not None
            return tool_exit_code

        # The crash boundary and signal handling start()'s run gives a game (_crash_boundary),
        # so a tool ends the process with the exit codes it had when it ran inside start(); the
        # glitchygames command runs its tools inside the same one (replay/tools/command.py)
        try:
            exit_status, cause = run_inside_tool_crash_boundary(
                run_tool=run_the_tool,
                tool_description=' and '.join(tool.flag for tool in tools),
                report_hint=BUG_REPORT_HINT,
            )
        finally:
            # After a signal's SystemExit (exit_on_signal) too, which passes through
            self._restore_sdl_driver_variables()
        # A game handler returns an ExitCode, and the boundary maps everything else to one
        exit_with(exit_code=ExitCode(exit_status), cause=cause)

    def _start_requested_replay(
        self: Self, *, game: type[Scene] | Scene, options: dict[str, Any]
    ) -> ReplaySources | None:
        """Prepare the replay if --replay-trace was given (rule 1 of glitchygames/replay/driver.py).

        With --audit the recording is audited instead (glitchygames/replay/audit.py), once it is
        known to be replayable, and the process exits with the audit's outcome
        (``_audit_replay``).

        Refusals exit (``exit_with``) with ``ExitCode.UNUSABLE_INPUT`` when the recording cannot
        be replayed (a recording of another game, an unsupported format version, an unreadable
        file), ``ExitCode.MISSING_INPUT`` when it does not exist, and
        ``ExitCode.OPTIONS_REFUSED`` when --record-trace is given too (recording over a replay
        is --rebaseline's job), --rebaseline's options are unsound (``rebaseline_refusal``) or
        it or --audit is given without --replay-trace, or --audit with --replay-fps real or
        to an interpreter started with -E or -I. Auditing a truncated recording exits with
        ``ExitCode.UNUSABLE_INPUT`` too (an audit needs the whole recording). --compare-trace
        and --replay-frame-stream are refused as glitchygames/replay/tools/compare.py (rule 6)
        says.

        Args:
            game: The game scene class or instance (its class name must match the recording's).
            options: The parsed options; a replay puts the recorded ones in place.

        Returns:
            The replay's sources (not installed yet), or None when not replaying.

        """
        self._refuse_listing_input_devices_during_a_run(options=options)
        self._refuse_a_forced_power_on_during_a_run(options=options)
        self._refuse_the_disk_sound_cache(options=options)
        replay_trace_path = options.get('replay_trace')
        if replay_trace_path is None:
            self._check_replay_options_without_a_recording(options=options)
            self._refuse_unwritable_outputs(options=options)
            self._prepare_the_live_comparison_with_old(options=options)
            return None
        self._refuse_an_unsound_comparison_with_old(
            replay_trace_path=replay_trace_path, options=options
        )
        self._refuse_an_unsound_recording_over_the_replay(
            replay_trace_path=replay_trace_path, options=options
        )
        self._refuse_an_unsound_processing_comparison(
            replay_trace_path=replay_trace_path, options=options
        )
        if options.get('audit'):
            self._refuse_an_unsound_audit(replay_trace_path=replay_trace_path, options=options)
        game_class = scene_class_of(game)
        try:
            sources = start_replay(
                path=Path(replay_trace_path),
                game_class=game_class,
                options=options,
                # Set by the version check this __init__ runs later, so pygame's version is
                # asked here too
                use_fastevents=GameEngine.USE_FASTEVENTS or pygame_needs_fastevents(),
            )
        except (ReplayRefusedError, TraceFormatError, OSError) as error:
            refusal = error
        else:
            if options.get('audit'):
                self._refuse_an_audit_under_another_seed(
                    replay_trace_path=replay_trace_path, sources=sources
                )
                self._refuse_auditing_a_truncated_recording(
                    replay_trace_path=replay_trace_path, sources=sources
                )
                self._audit_replay(path=Path(replay_trace_path))
            self._refuse_unwritable_outputs(options=options)
            self._prepare_the_comparison_with_old(
                replay_trace_path=replay_trace_path, sources=sources, options=options
            )
            self._connect_the_frame_stream(sources=sources, options=options)
            announce_replay(path=Path(replay_trace_path), sources=sources)
            return sources
        # Logged without a traceback: the message says what is wrong with the recording
        self.log.error('Cannot replay %s: %s', replay_trace_path, refusal)
        # Only a file that does not exist is missing input; one that cannot be read (no
        # permission, a directory, not gzip: gzip.BadGzipFile is an OSError) is unusable
        exit_with(
            exit_code=(
                ExitCode.MISSING_INPUT
                if isinstance(refusal, FileNotFoundError)
                else ExitCode.UNUSABLE_INPUT
            ),
            cause=refusal,
        )

    def _refuse_an_audit_under_another_seed(
        self: Self, *, replay_trace_path: str, sources: ReplaySources
    ) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED for ``--audit`` under another seed than recorded.

        An audit checks that a recording replays the same each time; under another seed
        (``--random-seed N``, rule 19 of glitchygames/replay/driver.py) nothing is compared, so
        there is nothing to check, and it is refused before anything runs (the user's decision,
        2026-10-26). A plain replay under that seed plays the inputs out, and a rebaseline
        records them.

        Args:
            replay_trace_path: The recording (for the message).
            sources: The replay's sources (``is_reseeded``).

        """
        if not sources.is_reseeded:
            return
        self.log.error(
            'Cannot audit %s under --random-seed %d: it was recorded under seed %d, and an '
            "audit checks a replay under its recording's seed. To play its inputs out under "
            'a new seed, replay it without --audit; to record them under it: --replay-trace '
            'OLD --rebaseline NEW --random-seed N',
            replay_trace_path,
            sources.random_seed,
            sources.recorded_seed,
        )
        exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _refuse_a_replay_display_of_another_size(self: Self, *, options: dict[str, Any]) -> None:
        """Exit with ExitCode.UNUSABLE_INPUT if the replay's window has another size than recorded.

        The replay asked for the recorded ``screen_size`` (``start_replay``); a window manager
        that gave the window another size would set the game up on it, and the replay would
        diverge from its first frame.

        Args:
            options: The parsed options (``replay_trace`` names the recording).

        """
        if self.replay_sources is None:
            return
        refusal = display_size_refusal(
            header=self.replay_sources.header, display_size=self.screen.get_size()
        )
        if refusal is None:
            return
        self.log.error('Cannot replay %s: %s', options['replay_trace'], refusal)
        exit_with(exit_code=ExitCode.UNUSABLE_INPUT)

    def _check_replay_options_without_a_recording(self: Self, *, options: dict[str, Any]) -> None:
        """Refuse --audit and --rebaseline without --replay-trace; warn about ignored options.

        Exits (``exit_with``) with ``ExitCode.OPTIONS_REFUSED`` for --audit or --rebaseline;
        --replay-fps, --replay-digest, --replay-pause-at-frame, the processing comparison's
        options and --replay-frame-stream are only warned about, and --compare-alpha without
        --compare-trace (--compare-trace OLD alone plays live against OLD:
        ``_prepare_the_live_comparison_with_old``).

        Args:
            options: The parsed options (no ``replay_trace``).

        """
        if options.get('audit'):
            self.log.error('--audit needs --replay-trace PATH: the recording to audit')
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)
        if options.get('rebaseline') is not None:
            self.log.error('--rebaseline needs --replay-trace OLD: the recording to rebaseline')
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)
        for option_name, flag in (
            ('replay_fps', '--replay-fps'),
            ('replay_digest', '--replay-digest'),
            ('replay_pause_at_frame', '--replay-pause-at-frame'),
            ('compare_processing', '--compare-processing'),
            ('max_processing_slowdown', '--max-processing-slowdown'),
            ('replay_frame_stream', '--replay-frame-stream'),
        ):
            if options.get(option_name) is not None:
                self.log.warning('%s is ignored without --replay-trace', flag)
        if options.get('compare_trace') is None and options.get('compare_alpha') is not None:
            self.log.warning('--compare-alpha is ignored without --compare-trace')

    def _prepare_the_live_comparison_with_old(self: Self, *, options: dict[str, Any]) -> None:
        """Give live play its onion skin when --compare-trace OLD is given without a replay.

        Rule 9 of glitchygames/replay/tools/compare.py. Refused before anything runs, the run
        exiting (``exit_with``): with --headless (``ExitCode.OPTIONS_REFUSED``), an OLD that
        is missing (``ExitCode.MISSING_INPUT``) or not a readable recording
        (``ExitCode.UNUSABLE_INPUT``). OLD's size is checked once the window opens
        (``_refuse_a_live_display_of_another_size_than_old``). The child starts on the first
        presented frame, inside the run, so the teardown always stops it.

        Args:
            options: The parsed options (no ``replay_trace``).

        """
        compare_trace_path = options.get('compare_trace')
        if compare_trace_path is None:
            return
        old_path = Path(compare_trace_path)
        refusal_reason = compare_trace_refusal(options=options)
        if refusal_reason is not None:
            self.log.error('Cannot play live against %s: %s', old_path, refusal_reason)
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)
        old = read_old_recording(old_path=old_path)
        if isinstance(old, CompareRefusal):
            self.log.error('Cannot play live against %s: %s', old_path, old.reason)
            exit_with(exit_code=old.exit_code)
        self.live_old_recording = old
        compare_alpha = options.get('compare_alpha')
        self.onion_skin = OnionSkin(
            old_path=old_path,
            alpha_percent=DEFAULT_COMPARE_ALPHA_PERCENT if compare_alpha is None else compare_alpha,
            game_command=old_game_command(old_path=old_path),
            # Live play has no step back
            pause_at_frame=None,
        )

    def _refuse_a_live_display_of_another_size_than_old(self: Self) -> None:
        """Exit with ExitCode.UNUSABLE_INPUT if live play's window is not OLD's recorded size.

        Before the first frame (rule 9 of glitchygames/replay/tools/compare.py): OLD's frames
        are drawn over the live ones pixel for pixel. Nothing to check without live play
        against OLD.
        """
        old = self.live_old_recording
        if old is None:
            return
        refusal = screen_size_refusal(old=old, new_size=self.screen.get_size())
        if refusal is None:
            return
        self.log.error('Cannot play live against %s: %s', old.path, refusal.reason)
        exit_with(exit_code=refusal.exit_code)

    def _refuse_unwritable_outputs(self: Self, *, options: dict[str, Any]) -> None:
        """Exit with ExitCode.CANNOT_WRITE_OUTPUT if an output file of the run cannot be written.

        Checked before any game code runs (``glitchygames.output_files.output_refusal``):
        ``--record-trace``'s recording, ``--rebaseline``'s partial file (NEW itself is only
        moved into place at the end: glitchygames/replay/rebaseline.py, rule 4) and
        ``--replay-digest``'s digest file. The refusal is logged on one line, without a
        traceback.

        Args:
            options: The parsed options (a recording over a replay already refused).

        """
        outputs: list[tuple[str, Path]] = []
        record_trace_path = options.get('record_trace')
        if record_trace_path is not None:
            outputs.append(('--record-trace', Path(record_trace_path)))
        rebaseline_path = options.get('rebaseline')
        if rebaseline_path is not None:
            outputs.append(('--rebaseline', partial_path(destination=Path(rebaseline_path))))
        replay_digest_path = options.get('replay_digest')
        if replay_digest_path is not None:
            outputs.append(('--replay-digest', Path(replay_digest_path)))
        for flag, path in outputs:
            refusal_reason = output_refusal(path=path)
            if refusal_reason is not None:
                self.log.error('Cannot write %s: %s', flag, refusal_reason)
                exit_with(exit_code=ExitCode.CANNOT_WRITE_OUTPUT)

    def _refuse_a_forced_power_on_during_a_run(self: Self, *, options: dict[str, Any]) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED for --crt-power-on on with a replay or recording.

        Nothing may happen before frame 0 of a recorded or replayed run: events pumped then would
        be input the game never saw (glitchygames/crt_power_on.py).

        Args:
            options: The parsed options.

        """
        if options.get('crt_power_on') != CrtPowerOnMode.ON.value:
            return
        for flag, option_name in (
            ('--replay-trace', 'replay_trace'),
            ('--record-trace', 'record_trace'),
        ):
            if options.get(option_name) is not None:
                self.log.error('Cannot play the CRT power-on sequence with %s', flag)
                exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def reserved_channel_partition(self: Self) -> ChannelPartition:
        """Partition the mixer's channels once per run, and return the partition (impl 7.1).

        The live voices' pool (``--live-voice-pool``), the sound library's channels
        (``--sound-channels``), then the legacy rest for ``Sound.play()`` callers. Reserved as
        the event managers are made, or earlier, when the game's construction asks for audio
        (``SceneManager.audio``), so the audio engine always plays on this run's partition.

        Only a partition made on a running mixer is kept (ruling R35): without a mixer the
        empty partition is returned, and a later call (once the mixer runs) reserves.

        Returns:
            The partition (empty without a mixer).

        """
        if self.channel_partition is not None:
            return self.channel_partition
        from glitchygames.audio.engine import DEFAULT_LIBRARY_CHANNELS, LEGACY_CHANNELS
        from glitchygames.audio.voices import reserve_channels

        partition = reserve_channels(
            live_pool=int(self.options.get('live_voice_pool', DEFAULT_LIVE_VOICE_POOL)),
            library_channels=int(self.options.get('sound_channels', DEFAULT_LIBRARY_CHANNELS)),
            legacy_channels=LEGACY_CHANNELS,
        )
        self.live_voice_channels = partition.live
        if pygame.mixer.get_init() is not None:
            self.channel_partition = partition
        return partition

    def _refuse_the_disk_sound_cache(self: Self, *, options: dict[str, Any]) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED for ``--sound-cache disk``, which arrives in M3.

        Args:
            options: The parsed options.

        """
        from glitchygames.audio.library import DISK_CACHE_MESSAGE, CacheMode

        if options.get('sound_cache') == CacheMode.DISK.value:
            self.log.error('Cannot use --sound-cache disk: %s', DISK_CACHE_MESSAGE)
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _refuse_listing_input_devices_during_a_run(self: Self, *, options: dict[str, Any]) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED for --list-input-devices with a replay or recording.

        The listing replaces the game's run (glitchygames/input/device_listing.py): there is no
        run to replay, audit, rebaseline or record.

        Args:
            options: The parsed options.

        """
        if not options.get('list_input_devices'):
            return
        for flag, option_name in (
            ('--replay-trace', 'replay_trace'),
            ('--record-trace', 'record_trace'),
        ):
            if options.get(option_name) is not None:
                self.log.error(
                    'Cannot list input devices with %s: the listing replaces the run', flag
                )
                exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _refuse_an_unsound_comparison_with_old(
        self: Self, *, replay_trace_path: str, options: dict[str, Any]
    ) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED for --compare-trace or a frame stream that can't run.

        ``--compare-trace`` with ``--headless``, ``--audit`` or ``--rebaseline``, and
        ``--replay-frame-stream`` without ``--headless`` (rule 6 of
        glitchygames/replay/tools/compare.py), before anything runs.

        Args:
            replay_trace_path: The recording (for the message).
            options: The parsed options.

        """
        refusal_reason = compare_trace_refusal(options=options)
        if refusal_reason is not None:
            self.log.error(
                'Cannot compare %s with %s: %s',
                replay_trace_path,
                options['compare_trace'],
                refusal_reason,
            )
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)
        refusal_reason = frame_stream_refusal(options=options)
        if refusal_reason is not None:
            self.log.error('Cannot replay %s: %s', replay_trace_path, refusal_reason)
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _prepare_the_comparison_with_old(
        self: Self, *, replay_trace_path: str, sources: ReplaySources, options: dict[str, Any]
    ) -> None:
        """Give a watched replay its onion skin when --compare-trace OLD is given.

        OLD must be a readable recording made at NEW's screen size (rule 6 of
        glitchygames/replay/tools/compare.py): otherwise the run exits (``exit_with``) with
        ``ExitCode.MISSING_INPUT`` or ``ExitCode.UNUSABLE_INPUT`` before anything runs. Its child
        starts on the first presented frame, inside the run, so the teardown always stops it.
        ``--compare-alpha`` without ``--compare-trace`` is warned about (it draws nothing).

        Args:
            replay_trace_path: NEW (for the message).
            sources: NEW's replay sources.
            options: The parsed options.

        """
        compare_trace_path = options.get('compare_trace')
        compare_alpha = options.get('compare_alpha')
        if compare_trace_path is None:
            if compare_alpha is not None:
                self.log.warning('--compare-alpha is ignored without --compare-trace')
            return
        old_path = Path(compare_trace_path)
        refusal = old_recording_refusal(old_path=old_path, new_header=sources.header)
        if refusal is not None:
            self.log.error(
                'Cannot compare %s with %s: %s', replay_trace_path, old_path, refusal.reason
            )
            exit_with(exit_code=refusal.exit_code)
        self.onion_skin = OnionSkin(
            old_path=old_path,
            alpha_percent=DEFAULT_COMPARE_ALPHA_PERCENT if compare_alpha is None else compare_alpha,
            game_command=old_game_command(old_path=old_path),
            pause_at_frame=self._olds_pause_at_frame(options=options),
        )
        sources.onion_skin = self.onion_skin

    @staticmethod
    def _olds_pause_at_frame(*, options: dict[str, Any]) -> int | None:
        """Return the ``--replay-pause-at-frame`` OLD's child gets: a game frame, not a frame.

        A restart (a step back) names the game frame it shows paused in its viewer state
        (``ViewerState.compare_first_game_frame``); the child's stream then writes from that
        game frame on (``first_streamed_frame`` of one past it). Without it (no restart, or a
        pause frame given by hand), the child streams from OLD's first frame.

        Args:
            options: The parsed options.

        Returns:
            The child's pause frame, or None.

        """
        viewer_state: ViewerState | None = options.get('replay_viewer_state')
        if viewer_state is None or viewer_state.compare_first_game_frame is None:
            return None
        return viewer_state.compare_first_game_frame + 1

    def _connect_the_frame_stream(
        self: Self, *, sources: ReplaySources, options: dict[str, Any]
    ) -> None:
        """Connect a headless replay's frame stream to its parent (--replay-frame-stream).

        Nothing listening on the port exits (``exit_with``) with
        ``ExitCode.SERVICE_UNAVAILABLE`` before anything runs. The stream writes nothing before
        the frame a restart at ``--replay-pause-at-frame`` shows (``first_streamed_frame``; rule
        8 of glitchygames/replay/tools/compare.py).

        Args:
            sources: The replay's sources.
            options: The parsed options.

        """
        address_text = options.get('replay_frame_stream')
        if address_text is None:
            return
        address = FrameStreamAddress.parse(text=address_text)
        # Refused before the replay started when it does not read (frame_stream_refusal)
        assert address is not None
        try:
            self.frame_stream = FrameStream.connect(
                address=address,
                first_frame=first_streamed_frame(
                    pause_at_frame=options.get('replay_pause_at_frame')
                ),
            )
        except OSError as error:
            refusal = error
        else:
            sources.frame_sink = self.frame_stream
            # The sink takes each frame as presented, in draw_overlay (rule 20 of
            # glitchygames/replay/driver.py)
            sources.draws_overlay = True
            return
        # Logged without a traceback: the message says what is wrong
        self.log.error('Cannot stream frames to port %s: %s', address.port, refusal)
        exit_with(exit_code=ExitCode.SERVICE_UNAVAILABLE, cause=refusal)

    def _refuse_an_unsound_recording_over_the_replay(
        self: Self, *, replay_trace_path: str, options: dict[str, Any]
    ) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED for a recording over the replay that cannot run.

        That is --rebaseline with unsound options (``rebaseline_refusal``), or --record-trace:
        a recording over a replay takes the replay's event origins and recorded fields, which
        only --rebaseline (headless, never stopping at a divergence) wires.

        Args:
            replay_trace_path: The recording to replay.
            options: The parsed options.

        """
        if options.get('rebaseline') is not None:
            refusal_reason = rebaseline_refusal(options=options)
            if refusal_reason is not None:
                self.log.error('Cannot rebaseline %s: %s', replay_trace_path, refusal_reason)
                exit_with(exit_code=ExitCode.OPTIONS_REFUSED)
        elif options.get('record_trace') is not None:
            self.log.error(
                'Cannot replay %s with --record-trace: record over a replay '
                'with --rebaseline NEW --headless',
                replay_trace_path,
            )
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _refuse_an_unsound_processing_comparison(
        self: Self, *, replay_trace_path: str, options: dict[str, Any]
    ) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED if processing times could not be compared.

        A comparison (``--compare-processing``, or ``--max-processing-slowdown``, which implies
        it) needs a headless replay (a watched one presents, steps and rebuilds frames as its
        viewer asks), and is refused with --audit (its children's exit codes are the audit's
        verdict) and --rebaseline (which exits on what it wrote; its NEW records this run's
        processing times anyway). glitchygames/replay/processing.py.

        Args:
            replay_trace_path: The recording to replay.
            options: The parsed options.

        """
        if (
            options.get('compare_processing') is None
            and options.get('max_processing_slowdown') is None
        ):
            return
        if not options.get('headless'):
            reason = '--compare-processing needs --headless'
        elif options.get('audit'):
            reason = 'not with --audit'
        elif options.get('rebaseline') is not None:
            reason = 'not with --rebaseline'
        else:
            return
        self.log.error('Cannot compare the processing times of %s: %s', replay_trace_path, reason)
        exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _refuse_an_unsound_audit(
        self: Self, *, replay_trace_path: str, options: dict[str, Any]
    ) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED if an audit's two runs could not be compared.

        That is under --replay-fps real (FPS events from measured frame times differ between the
        runs), or when Python was started with -E or -I (the children run this interpreter's
        options again, so they would ignore PYTHONHASHSEED).

        Args:
            replay_trace_path: The recording to audit.
            options: The parsed options.

        """
        if options.get('replay_fps') == REAL_REPLAY_FPS:
            self.log.error(
                'Cannot audit %s with --replay-fps %s: --audit compares recorded FPS events',
                replay_trace_path,
                REAL_REPLAY_FPS,
            )
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)
        if not environment_reaches_children():
            self.log.error(
                'Cannot audit %s: Python was started with -E or -I, so the '
                'audit replays would ignore their PYTHONHASHSEED; run without those options',
                replay_trace_path,
            )
            exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _refuse_auditing_a_truncated_recording(
        self: Self, *, replay_trace_path: str, sources: ReplaySources
    ) -> None:
        """Exit with ExitCode.UNUSABLE_INPUT if the recording to audit is truncated.

        An audit needs the whole recording: its child replays would end at the cut-off (exit
        ``ExitCode.UNUSABLE_INPUT``), which the audit could only report as a run that did not
        finish.

        Args:
            replay_trace_path: The recording to audit.
            sources: Its replay sources (read, not installed).

        """
        if sources.recording.is_truncated:
            self.log.error(
                'Cannot audit %s: the recording is truncated after '
                '%s complete frames, and an audit needs the whole '
                'recording',
                replay_trace_path,
                sources.recording.frame_count,
            )
            exit_with(exit_code=ExitCode.UNUSABLE_INPUT)

    def _audit_replay(self: Self, *, path: Path) -> NoReturn:
        """Audit the recording in two child replays and exit with the outcome (--audit).

        It exits (``exit_with``) with ``ExitCode.SUCCESS`` when the audit passes,
        ``ExitCode.AUDIT_NONDETERMINISTIC`` when it fails and ``ExitCode.INTERNAL_ERROR`` when
        it could not run (``AuditRunError``: a child that could not start, hung, crashed or
        wrote no digests).

        Args:
            path: The recording.

        """
        self.log.info('Auditing %s: two replays in fresh processes', path)
        try:
            with self._waiting_for_child_processes():
                result = audit_recording(
                    command=audit_command(original_argv=sys.orig_argv), path=path
                )
        except AuditRunError as error:
            run_error = error
        else:
            if result.is_deterministic():
                self.log.info(result.summary())
                exit_with(exit_code=ExitCode.SUCCESS)
            self.log.error(result.summary())
            exit_with(exit_code=ExitCode.AUDIT_NONDETERMINISTIC)
        # Logged without a traceback: the message says which run failed and how
        self.log.error('Audit could not run: %s', run_error)
        exit_with(exit_code=ExitCode.INTERNAL_ERROR, cause=run_error)

    def _report_replay_result(self: Self, *, run_ended_by: str | None) -> None:
        """Settle the replay's result and report it, if replaying (rule 11).

        The report (``settle_replay_report``) is printed to stdout under ``--headless``, where it
        is the run's output, and logged otherwise (as an error when the replay diverged).

        Args:
            run_ended_by: What ended the run early (an exit status as
                ``ExitCode.describe_status`` gives it), or None when the run ended normally.

        """
        if self.replay_sources is None:
            return
        report = self.settle_replay_report(
            replay_sources=self.replay_sources, run_ended_by=run_ended_by
        )
        if self.replay_sources.options.headless:
            sys.stdout.write(f'{report.text}\n')
            sys.stdout.flush()
        elif report.is_failure:
            self.log.error(report.text)
        else:
            self.log.info(report.text)

    def settle_replay_report(
        self: Self, *, replay_sources: ReplaySources, run_ended_by: str | None
    ) -> ReplayReport:
        """Settle the replay's result (``ReplaySources.finish_run``) and return its report.

        The report is ``ReplayResult.report``; ``_report_replay_result`` prints or logs it, and
        an inner game (glitchygames/inner_game.py), which writes nothing to stdout, keeps it in
        its outcome.

        Any early end of the run (a crash, Ctrl-C, a signal, or any SystemExit, a game's own
        ``sys.exit(0)`` included) is reported by what ended it: before the replay reached its
        result, only where the replay stopped (``Replay stopped at frame N: the run ended with
        ...``), since its result would call that a length divergence; after the replay reached
        its result (a late crash or signal, during the teardown of the last scene), that result
        and then ``then the run ended with ...`` on the next line.

        A rebaseline (glitchygames/replay/rebaseline.py) that ended normally writes its new
        recording and reports its summary instead; one that ended early writes nothing and
        says so after the report.

        Args:
            replay_sources: The run's replay doors (``self.replay_sources``).
            run_ended_by: What ended the run early (an exit status as
                ``ExitCode.describe_status`` gives it, or an inner game's error), or None when
                the run ended normally.

        Returns:
            The report and whether it reports a failure.

        """
        result = replay_sources.result
        # Read before finish_run, which turns a replay still running into a length divergence
        replay_had_ended = result.end_reason != RUNNING_END_REASON
        replay_sources.finish_run()
        if run_ended_by is not None and replay_had_ended:
            report = f'{result.report()}\nthen the run ended with {run_ended_by}'
            is_failure = True
        elif run_ended_by is not None:
            report = (
                f'Replay stopped at frame {result.frames_replayed}: the run ended with '
                f'{run_ended_by}'
            )
            is_failure = True
        else:
            report = result.report()
            is_failure = result.divergence is not None
        if self.rebaseline is not None:
            if run_ended_by is None:
                # The divergences are what the rebaseline reports, not a failure
                report = self.rebaseline.write(result=result)
                is_failure = False
            else:
                self.rebaseline.discard()
                report = f'{report}\n{self.rebaseline.destination} was not written'
        elif replay_sources.is_reseeded and run_ended_by is None:
            # Under another seed than recorded (rule 19 of glitchygames/replay/driver.py) the
            # differences are what the replay reports, never a failure, and nothing is written
            report = RebaselineSummary.from_result(
                result=result, path=None
            ).describe_reseeded_replay(
                random_seed=replay_sources.random_seed,
                recorded_seed=replay_sources.recorded_seed,
            )
            is_failure = False
        if result.processing is not None:
            # After the replay's own report (glitchygames/replay/processing.py)
            report = f'{report}\n{result.processing.describe()}'
        return ReplayReport(text=report, is_failure=is_failure)

    def _enter_headless_mode(self: Self) -> None:
        """--headless: run on SDL's dummy video and audio drivers (no window, no sound).

        Called right after the options are read, before ``pygame.init()`` and the display. If
        pygame was started before the engine (at import, by a game's own code), its display and
        mixer already run on the drivers chosen then, and each that is not on the dummy driver is
        restarted on it, with one warning naming what was restarted:

        - The display is stopped; ``pygame.init()`` starts it again and the engine opens its
          window on it, as it always does.
        - The mixer is stopped and started again at once with the same frequency, sample size
          and output channels (``pygame.mixer.get_init()``) and the same number of mixing
          channels. Anything playing stops; sounds loaded before keep the format they were
          converted to, which still matches. The buffer size cannot be read back, so it is
          pygame's default. If the dummy mixer cannot start, the run goes on without audio
          (logged).

        The variables' earlier values are kept and put back when the run ends
        (``_restore_sdl_driver_variables``), so a process that goes on after a headless run
        starts pygame on its own drivers again.
        """
        self._remember_sdl_driver_variables()
        for name in SDL_DRIVER_VARIABLES:
            os.environ[name] = HEADLESS_SDL_DRIVER
        restarted: list[str] = []
        if pygame.display.get_init() and pygame.display.get_driver() != HEADLESS_SDL_DRIVER:
            restarted.append(f'the display (video driver {pygame.display.get_driver()!r})')
            pygame.display.quit()
        mixer_format = pygame.mixer.get_init()
        if mixer_format is not None and pygame.mixer.get_driver() != HEADLESS_SDL_DRIVER:
            frequency, size, output_channels = mixer_format
            mixing_channel_count = pygame.mixer.get_num_channels()
            restarted.append(
                f'the mixer (audio driver {pygame.mixer.get_driver()!r}; kept: {frequency} Hz, '
                f'size {size}, {output_channels} output channels, {mixing_channel_count} '
                'mixing channels)'
            )
            pygame.mixer.quit()
            try:
                # The environment now names the dummy driver, so this opens the dummy device
                pygame.mixer.init(frequency=frequency, size=size, channels=output_channels)
            except pygame.error as error:
                # The run goes on without a mixer: sounds and live voices are silent no-ops
                self.log.warning(
                    '--headless: the mixer could not start on the dummy audio driver (%s); '
                    'running without audio',
                    error,
                )
            else:
                pygame.mixer.set_num_channels(mixing_channel_count)
        if restarted:
            self.log.warning(
                '--headless: pygame was started before the engine; restarting '
                '%s on the dummy driver, so there is no window and '
                'audio is muted',
                ' and '.join(restarted),
            )

    def _choose_sdl_drivers(self: Self, *, options: dict[str, Any]) -> None:
        """Choose the drivers before anything starts the display or the mixer.

        --headless wins: its dummy driver is the point of the run, so --video-driver is ignored
        (with a warning). With neither, a Linux Wayland session runs on Wayland, unless
        SDL_VIDEODRIVER already says otherwise.

        Args:
            options: The engine's options.

        """
        video_driver = options.get('video_driver')
        if options.get('headless'):
            if video_driver:
                self.log.warning(
                    '--headless runs on the %r video driver; --video-driver %s is ignored',
                    HEADLESS_SDL_DRIVER,
                    video_driver,
                )
            self._enter_headless_mode()
        elif video_driver:
            self._enter_video_driver(video_driver=video_driver)
        elif self._is_on_a_wayland_session_with_no_driver_chosen():
            self._enter_video_driver(video_driver=WAYLAND_FIRST_VIDEO_DRIVERS)

    @staticmethod
    def _is_on_a_wayland_session_with_no_driver_chosen() -> bool:
        """Return whether this is a Linux Wayland session whose SDL_VIDEODRIVER chooses nothing.

        Returns:
            True when the engine should choose Wayland.

        """
        return (
            platform.system() == 'Linux'
            and bool(os.environ.get('WAYLAND_DISPLAY'))
            and not os.environ.get('SDL_VIDEODRIVER')
        )

    def _enter_video_driver(self: Self, *, video_driver: str) -> None:
        """Start the display on the named SDL video driver, or the first of a list that starts.

        Called right after the options are read, before ``pygame.init()`` and the display, as
        ``_enter_headless_mode`` is. A display pygame started before the engine on another driver
        is stopped (with a warning), so ``pygame.init()`` starts it again on this one. The
        variable's earlier value is put back when the run ends
        (``_restore_sdl_driver_variables``).

        Args:
            video_driver: What SDL_VIDEODRIVER is set to: a driver's name, or a comma-separated
                list of them in the order to try.

        """
        self._remember_sdl_driver_variables()
        os.environ['SDL_VIDEODRIVER'] = video_driver
        wanted_driver = video_driver.split(',', maxsplit=1)[0]
        if pygame.display.get_init() and pygame.display.get_driver() != wanted_driver:
            self.log.warning(
                'pygame was started before the engine; restarting the display '
                '(video driver %r) on %r',
                pygame.display.get_driver(),
                video_driver,
            )
            pygame.display.quit()

    def _remember_sdl_driver_variables(self: Self) -> None:
        """Keep the SDL driver variables' values, for _restore_sdl_driver_variables."""
        self._sdl_driver_variables_before_run = {
            name: os.environ.get(name) for name in SDL_DRIVER_VARIABLES
        }

    def _restore_sdl_driver_variables(self: Self) -> None:
        """Put back the SDL driver variables --headless or --video-driver set (idempotent).

        SDL reads them only when the display or mixer starts, so this changes nothing that is
        running: it is called after ``_shutdown`` quit pygame, so a process that goes on (runs a
        headless replay, then opens a window) starts pygame on its own drivers, not the dummy
        ones. A variable that was not set before is removed.
        """
        variables_before, self._sdl_driver_variables_before_run = (
            self._sdl_driver_variables_before_run,
            None,
        )
        if variables_before is None:
            return
        for name, value in variables_before.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value

    def _shutdown(self: Self, *, run_ended_by: str | None = None) -> None:
        """Stop the comparison, then close any recording, report any replay, shut down pygame.

        OLD's child and a frame stream end first (``_end_the_comparison``); if that fails, the
        rest of the teardown still runs (``_shut_down_the_run``), and the failure propagates
        after it (the teardown failed).

        Args:
            run_ended_by: What ended the run early (``_report_replay_result``), or None.

        """
        # First, so every teardown path (a replay restart's early return included) leaves no
        # finished engine current: its views then read None, and it is not kept alive
        _stop_being_the_current_engine(engine=self)
        try:
            self._end_the_comparison()
        finally:
            self._shut_down_the_run(run_ended_by=run_ended_by)

    def _end_the_comparison(self: Self) -> None:
        """Stop --compare-trace's child and close a frame stream (each runs if the other fails)."""
        try:
            if self.onion_skin is not None:
                self.onion_skin.stop()
        finally:
            if self.frame_stream is not None:
                self.frame_stream.close()

    def _shut_down_the_run(self: Self, *, run_ended_by: str | None) -> None:
        """Close any recording, report any replay, print performance reports, shut down pygame.

        Args:
            run_ended_by: What ended the run early (``_report_replay_result``), or None.

        """
        try:
            # First, so the recording is complete even if a report below fails
            self.stop_trace_recording()
        finally:
            # After closing: until then a repeated signal must stay ignored (exit_on_signal).
            # Even when closing failed, the replay is settled (its blocked input restored) and
            # reported; the closing error then propagates (the teardown failed)
            self._restore_signal_handlers()
            self._report_replay_result(run_ended_by=run_ended_by)
        # The run is over, a restart included (its process makes its own timer): give back what
        # the timer holds here, not in its finaliser, which must not log (BUGS.md #188)
        if self.timer is not None:
            self.timer.close()
        # Closes this game's session; the service stops the models once the last one has gone
        if self.ai_console is not None:
            self.ai_console.stop()
        if self.ai_link is not None:
            self.ai_link.stop()
        # Before pygame quits: the sound library's voices fade over 50 ms, waited for at most
        # 100 ms (sound engine impl spec 10.3), then the channel reservation is given back (SDL
        # would keep it for a mixer started again in this process). Even when closing the audio
        # engine fails, the reservation is given back and the rest of the teardown runs; the
        # failure then propagates (the teardown failed: logged with its traceback, exit
        # INTERNAL_ERROR)
        from glitchygames.audio.engine import discard_audio_engine
        from glitchygames.audio.voices import release_channels

        try:
            discard_audio_engine()
        finally:
            try:
                release_channels()
            finally:
                self._finish_the_teardown()

    def _finish_the_teardown(self: Self) -> None:
        """Print the end-of-run reports (unless the replay restarts) and shut down pygame."""
        # A step back restarts the replay (glitchygames/replay/rebuild.py): not the end of the
        # run, so the end-of-run reports wait for the last replay
        if self.replay_sources is not None and self.replay_sources.result.restart_frame is not None:
            pygame.display.quit()
            pygame.quit()
            return

        # Print performance report before shutdown
        try:
            from glitchygames.performance import AdaptiveClamping
        except ImportError:
            pass  # Performance module not available
        else:
            adaptive_clamping = AdaptiveClamping()
            # Configure performance manager with the same log interval as FPS
            if self.fps_log_interval_ms is not None:
                adaptive_clamping.set_fps_log_interval(self.fps_log_interval_ms)
            # Configure performance manager with target FPS for grading
            adaptive_clamping.set_target_fps(self.fps)
            adaptive_clamping.print_shutdown_report()
            adaptive_clamping.print_per_scene_shutdown_report()

        self._log_sprite_count_report()
        self._log_unhandled_event_report()

        pygame.display.quit()
        pygame.quit()

    def _configure_timer_and_performance(self: Self, *, paced_by_timer: bool) -> None:
        """Create the frame-pacing timer and configure the performance manager from the options.

        Each part is guarded on its own: a bad option falls back (the pygame clock, the
        performance defaults) and is logged at debug level, never ending the run.

        Args:
            paced_by_timer: Whether the run's frames wait on this timer (``start()``); False for
                ``start_async()``, whose outer tick is the wait. Only a timer that paces is
                calibrated; the timer is made either way (a recording names it).

        """
        # Initialize timer backend for draw-loop pacing (after options exist)
        try:
            self.timer = create_timer(
                self.options.get('timer_backend'),
                self.options,
            )
            self.log.info('Timer backend: %s', self.options.get('timer_backend'))
            # auto measures this machine's sleep model now for a paced live game, so no frame
            # pays for it (and logs what it chose); a replay and an async run never pace with
            # the timer, and an uncapped run calibrates only if it starts pacing (at its first
            # paced frame)
            if (
                paced_by_timer
                and self.options.get('target_fps', 0) > 0
                and self.replay_sources is None
            ):
                self.timer.calibrate()
        except (ValueError, TypeError, OSError) as timer_error:
            self.timer = None
            self.log.debug(
                'Timer backend failed to initialize; using pygame clock only: %s',
                timer_error,
            )
        # Configure performance trim percent and histogram mode, each guarded on its own so
        # a bad value for one cannot silently skip the other.
        try:
            from glitchygames.performance import AdaptiveClamping

            trim = float(self.options.get('perf_trim_percent', 5.0))
            AdaptiveClamping().set_trim_percent(trim)
        except (ImportError, ValueError, TypeError, AttributeError) as perf_error:
            LOG.debug('Performance trim percent configuration failed: %s', perf_error)
        try:
            from glitchygames.performance import AdaptiveClamping

            AdaptiveClamping().set_histogram_mode(self.options.get('fps_histogram', 'equal-range'))
        except (ImportError, ValueError, TypeError, AttributeError) as perf_error:
            LOG.debug('Performance FPS histogram mode configuration failed: %s', perf_error)

    def _tear_down_run(
        self: Self, *, profiler: cProfile.Profile | None, run_ended_by: str | None
    ) -> Exception | None:
        """Run the teardown after a run, whatever ended it, and report how it went.

        Args:
            profiler: The run's profiler (--profile), stopped and printed here, or None.
            run_ended_by: What ended the run early (an exit status described), or None when it
                ended normally.

        Returns:
            The exception ``_shutdown`` raised (logged with its traceback), or None.

        """
        teardown_error: Exception | None = None
        try:
            self._shutdown(run_ended_by=run_ended_by)
        except Exception as error:
            self.log.exception('The teardown failed')
            # Its own line after the traceback (logged above), where a player reads last
            self.log.error(BUG_REPORT_HINT)  # ruff: ignore[error-instead-of-exception]
            teardown_error = error
        finally:
            # Again (it is idempotent): _shutdown restores them, but not if it failed first
            self._restore_signal_handlers()
            # After _shutdown quit pygame: whatever starts it next does so on these drivers
            self._restore_sdl_driver_variables()
        if self.options['profile'] and profiler is not None:
            profiler.disable()
            profiler.print_stats()
        return teardown_error

    def start(self: Self) -> None:
        """Start the game engine.

        However the run ends, the teardown (``_shutdown``: recordings closed) runs first; if the
        teardown itself raises, the run exits ``ExitCode.INTERNAL_ERROR`` (both errors logged).
        An exception raised before start(), in ``__init__``, is not mapped: it exits with
        Python's default 1 (each game has its own entry point, so there is no one place to wrap;
        see glitchygames/exit_codes.py). A replay (``--replay-trace``) that ends normally exits
        with its own code (``ReplayResult.exit_code`` under its exit policy), watched or
        headless.

        How it ends (``_begin_start`` and ``_crash_boundary`` raise these): RuntimeError if the
        game is not initialized; SystemExit with ``ExitCode.INTERNAL_ERROR`` after an uncaught
        exception (logged with its traceback), ``ExitCode.INTERRUPTED`` after Ctrl-C
        (KeyboardInterrupt), or whatever status a SystemExit raised during the run carries (a
        signal handler's, a game's own), except a game's own successful exit that cuts a replay
        short (``ExitCode.REPLAY_DIVERGED``; a rebaseline ends normally then, with what the game
        ran); at the normal end of a replay, with the replay's exit code (``ExitCode.SUCCESS``,
        ``ExitCode.REPLAY_DIVERGED`` or ``ExitCode.UNUSABLE_INPUT`` for a truncated recording).

        A hosted start (``render_target.hosted_start_requested()``: an inner context, or one
        that called ``request_hosted_start()``) builds the game up to its first frame and
        returns, keeping the engine for the host (``render_target.take_started_engine()``),
        which runs the frames and their end itself; none of the above applies to it.
        """
        # A hosted start (an inner context, or one that asked: glitchygames/render_target.py):
        # build the game up to its first frame and hand the engine to the host, which steps its
        # frames. No signal handlers, no blocking loop and no crash boundary, whose teardown
        # would quit pygame for every context
        if hosted_start_requested():
            self._build_game(paced_by_timer=False)
            note_started_engine(engine=self)
            return
        profiler = self._begin_start()
        with self._crash_boundary(profiler=profiler):
            self._run_game()

    async def start_async(self: Self, *, wait_for_tick: Callable[[], Awaitable[float]]) -> None:
        """Start the game engine, giving control back to the caller between frames.

        For a host that must not block (a browser: glitchygames/host.py). The run is
        ``start()``'s, inside the same crash boundary (the same teardown and exit codes), but
        its frames are driven by one awaited ``wait_for_tick()`` per outer tick: a live game's
        by ``GameHost.run_async`` (an inner frame on the ticks ``TickPacer`` picks for the
        target FPS), a watched replay's by its viewer (``run_watched_replay_async``: the tick's
        inner frames, then the viewer's outer frame).

        Args:
            wait_for_tick: Waits for the next outer tick (a browser animation frame) and
                returns its timestamp in seconds.

        It ends as ``start()`` does (see there).

        Raises:
            RuntimeError: If the run is a headless replay (it never holds between frames, so
                it would never give control back), or (from ``_begin_start``) the game is not
                initialized.

        ``--compare-trace`` is refused before anything starts, exiting (``exit_with``) with
        ``ExitCode.OPTIONS_REFUSED``: OLD is replayed by a child process, which a browser page
        (the host start_async is for) cannot start (``_refuse_a_comparison_in_a_browser``).

        """
        self._refuse_a_comparison_in_a_browser()
        # Chosen first (a run start_async cannot drive is refused before anything starts), but
        # called inside the boundary
        run_frames: Callable[[], Awaitable[None]]
        if self.host is not None:
            run_frames = functools.partial(
                self.host.run_async, scene_manager=self.scene_manager, wait_for_tick=wait_for_tick
            )
        elif self.replay_sources is not None and not self.replay_sources.options.headless:
            run_frames = functools.partial(
                run_watched_replay_async,
                scene_manager=self.scene_manager,
                viewer=self.replay_sources.viewer,
                wait_for_tick=wait_for_tick,
            )
        else:
            raise RuntimeError(ASYNC_RUN_NEEDS_HOST_MSG)
        profiler = self._begin_start()
        with self._crash_boundary(profiler=profiler):
            if self._begin_run():
                if self._power_on_plays():
                    sound_cues = self._power_on_sound_cues()
                    self._hand_back_power_on(
                        outcome=await play_power_on_async(
                            screen=self.screen,
                            sources=active_sources(),
                            wait_for_tick=wait_for_tick,
                            sound_cues=sound_cues,
                        ),
                        sound_cues=sound_cues,
                    )
                self._build_game(paced_by_timer=False)
                await run_frames()

    def _refuse_a_comparison_in_a_browser(self: Self) -> None:
        """Exit with ExitCode.OPTIONS_REFUSED for --compare-trace driven by ``start_async``.

        OLD is replayed by a child process (glitchygames/replay/tools/compare.py, rule 2),
        which a browser page cannot start, as a watched replay's restarts cannot
        (``RESTARTS_AVAILABLE``). Live play and a watched replay alike; the child was never
        started (it starts on the first presented frame).
        """
        if self.onion_skin is None:
            return
        self.log.error(
            'Cannot compare with %s here: --compare-trace replays OLD in a child process, '
            'which start_async (a browser page) cannot start; run it with start() on a desktop',
            self.onion_skin.old_path,
        )
        exit_with(exit_code=ExitCode.OPTIONS_REFUSED)

    def _log_the_startup_options(self: Self) -> None:
        """Log the run's options at CRITICAL, once per engine start (``startup_options_block``).

        CRITICAL "for now" (the owner, 2026-10-28: "Log that at critical" ... "Do it for now"),
        so the options show at every level, the default WARNING included; it prints on every
        launch and in every engine the test suite starts (plans/future-work.md). The options are
        a replay's as recorded, which ``start_replay`` put in place before the start.

        ``random_seed`` is the seed the run uses (``self.random_seed``: rolled, given, OLD's or
        the recording's), not the option as given, which is None when the seed was rolled (the
        owner, 2026-10-28: "The seed should definitely be in the options"); rolled or given is
        on the INFO line (``_log_the_runs_seed``), hidden at the default WARNING.
        """
        shown_options = {**self.options, 'random_seed': self.random_seed}
        self.log.critical(
            '%s', startup_options_block(game_name=self._game_name(), options=shown_options)
        )

    def _game_name(self: Self) -> str:
        """Return the game's NAME, which the start line and the options block name.

        The engine's own NAME names no game ("Boilerplate Adventures", D18's report); it is
        used only when no game was given, which ``_begin_start`` refuses.

        Returns:
            The name.

        """
        return str(getattr(self.game, 'NAME', type(self).NAME))

    def _begin_start(self: Self) -> cProfile.Profile | None:
        """Log the start and the options, check there is a game, start the profiler (``--profile``).

        Returns:
            The running profiler, or None.

        Raises:
            RuntimeError: If the game is not initialized.

        """
        # This ensures that logging is enabled as soon as the game object is created.
        logging.getLogger('game')

        self.log.info('Starting game engine for game: %s', self._game_name())
        self._log_the_startup_options()
        if self.game is None:
            raise RuntimeError(GAME_NOT_INITIALIZED_MSG)

        profiler = None
        if self.options['profile']:
            # Enabled before the crash boundary, so the teardown prints only a profiler that ran
            profiler = cProfile.Profile()
            profiler.enable()
        return profiler

    @contextlib.contextmanager
    def _crash_boundary(self: Self, *, profiler: cProfile.Profile | None) -> Generator[None]:
        """Turn however the run in the ``with`` block ends into an exit code, after the teardown.

        Shared by ``start()`` and ``start_async()`` (a synchronous ``with`` holds an ``await``
        too). An exception it handles ends the run with its exit code; a SystemExit it does not
        turn into one propagates, after the teardown. See ``start()``.

        Args:
            profiler: The run's profiler (``--profile``), printed by the teardown; or None.

        Yields:
            Nothing: the run goes in the ``with`` block.

        Raises:
            SystemExit: A SystemExit raised in the block that does not cut a replay short,
                again after the teardown (``start()`` lists the endings).

        """
        # Set when the run ends in a way that start() turns into an exit code
        exit_code: ExitCode | None = None
        run_error: Exception | None = None
        # What ended the run early, described for the replay report (None: a normal end)
        run_ended_by: str | None = None
        try:
            # The crash boundary: anything the run raises is turned into an exit code below
            yield
        except KeyboardInterrupt:
            # Ctrl-C: never an internal error; exits INTERRUPTED once the teardown has run
            exit_code = ExitCode.INTERRUPTED
            run_ended_by = exit_code.describe()
        except SystemExit as exit_request:
            # A deliberate exit (a signal handler's, a game's) keeps its status
            run_ended_by = self._describe_exit_request(exit_status=exit_request.code)
            if not self._exit_cuts_a_replay_short(exit_status=exit_request.code):
                raise
            exit_code, run_ended_by = self._outcome_of_a_replay_cut_short(run_ended_by=run_ended_by)
        except RecordingWriteError as error:
            # The disk filled part way: logged on one line by the recorder (BUGS.md #82)
            exit_code = ExitCode.CANNOT_WRITE_OUTPUT
            run_ended_by = exit_code.describe()
            run_error = error
        except Exception as error:
            scene_name = self._resolve_scene_name_for_error()
            self.log.exception("Runtime error during game execution @ scene '%s'", scene_name)
            # Its own line after the traceback (logged above), where a player reads last
            self.log.error(BUG_REPORT_HINT)  # ruff: ignore[error-instead-of-exception]
            exit_code = ExitCode.INTERNAL_ERROR
            run_ended_by = exit_code.describe()
            run_error = error
        finally:
            teardown_error = self._tear_down_run(profiler=profiler, run_ended_by=run_ended_by)
            if teardown_error is not None:
                # Replaces whatever was ending the run: a failed teardown is an internal error
                exit_with(exit_code=ExitCode.INTERNAL_ERROR, cause=teardown_error)
        self._end_run(exit_code=exit_code, run_error=run_error)

    def _run_game(self: Self) -> None:
        """Construct the game and run its scenes: the whole run inside start()'s crash boundary."""
        if not self._begin_run():
            return
        if self._power_on_plays():
            sound_cues = self._power_on_sound_cues()
            self._hand_back_power_on(
                outcome=play_power_on(
                    screen=self.screen, sources=active_sources(), sound_cues=sound_cues
                ),
                sound_cues=sound_cues,
            )
        self._build_game(paced_by_timer=True)
        if self.host is not None:
            self.host.run(scene_manager=self.scene_manager)
        else:
            # A replay: its doors (and watched, its viewer) drive the blocking loop
            self.scene_manager.start()

    def _begin_run(self: Self) -> bool:
        """Start the run in the crash boundary: signal handlers, then the game or what runs instead.

        With --list-input-devices the listing runs in place of the game (it is printed):
        nothing is built, so no frame runs. (A tool given as a game flag that runs in place of
        the game already ran, in ``__init__``: ``_run_game_flag_tool``.)

        Returns:
            Whether the game is to be built and run (False after the listing).

        """
        # For the whole run, so a signal always ends it through start()'s teardown
        self._install_signal_handlers()

        if self.options.get('list_input_devices'):
            # In place of the game: its scene is never built, nothing is recorded
            lines = list_input_devices(
                sources=active_sources(),
                input_mode=InputMode(self.options.get('input_mode', InputMode.AUTO)).value,
                prompt=input_device_prompt(),
            )
            sys.stdout.write('\n'.join(lines) + '\n')
            return False
        return True

    def _power_on_plays(self: Self) -> bool:
        """Return whether the CRT power-on sequence plays before the game (``--crt-power-on``).

        Returns:
            True to play it (glitchygames/crt_power_on.py ``should_play``).

        """
        return should_play(
            mode=resolve_mode(option=self.options.get('crt_power_on'), environment=os.environ),
            video_driver=pygame.display.get_driver(),
            options=self.options,
        )

    def _power_on_sound_cues(self: Self) -> CrtPowerOnSound | None:
        """Make the power-on's sound, compiling it, unless ``--crt-power-on-sound off``.

        Called only when the picture plays (``_power_on_plays``), so the sound keeps the
        picture's rules: never under ``--headless`` (auto), before a replay, an audit, a
        rebaseline or a recording (feature spec 12.1, AUD-CRT-002). The audio engine is made
        here, before the game is built and so before ``SceneManager.game_engine`` is set, from
        this engine's options and channel partition (``SceneManager.audio_for``): the game's
        ``scene_manager.audio`` is then this same engine (rulings R34, R35).

        Returns:
            The cues (glitchygames/crt_power_on_sound.py), or None to play the picture silently.

        """
        sound_choice = self.options.get('crt_power_on_sound', DEFAULT_CRT_POWER_ON_SOUND)
        if sound_choice == CRT_POWER_ON_SOUND_OFF:
            return None
        from glitchygames.crt_power_on_sound import CrtPowerOnSound

        return CrtPowerOnSound(
            audio=self.scene_manager.audio_for(game_engine=self),
            background=active_default_background_pattern(),
        )

    def _hand_back_power_on(
        self: Self, *, outcome: PowerOnOutcome, sound_cues: CrtPowerOnSound | None
    ) -> None:
        """Give the game what the power-on sequence ended with: a window closed during it quits.

        Its sound's tail (the bars tone or the hiss) is carried into the game, fading from
        frame 0 (impl spec 10.1); after a skip everything is already fading.

        Args:
            outcome: How the sequence ended.
            sound_cues: The sequence's sound, or None when it played silently.

        """
        self.log.debug('CRT power-on sequence: %s', outcome)
        if sound_cues is not None:
            sound_cues.carry_tail_into_the_game()
        if outcome is PowerOnOutcome.QUIT:
            post_input_event(event=pygame.event.Event(pygame.QUIT))

    def build_live_sources(
        self: Self, *, random_seed: int, captures_scene_starts: bool
    ) -> LiveSources:
        """Build the live doors a live run reads through, beneath its host's.

        Called once, as the engine is constructed, for every run that is not a replay. A
        subclass may build other live doors: the golden-trace harness's engine builds stand-in
        devices' (``GoldenTraceEngine(stand_in_devices=...)``,
        glitchygames/replay/tools/golden_traces.py).

        Args:
            random_seed: The run's master seed (glitchygames/randomness.py).
            captures_scene_starts: True when the run will be recorded (``--record-trace``), so
                scene starts are captured from its first scene on (``LiveSources``).

        Returns:
            The live doors.

        """
        return LiveSources(
            random_seed=random_seed,
            use_fastevents=GameEngine.USE_FASTEVENTS,
            captures_scene_starts=captures_scene_starts,
        )

    def _host_sources(self: Self, *, inner: LiveSources, overlay: OnionSkin | None) -> HostSources:
        """Build the host's doors: the AI's subclass only for a run that has a link.

        Args:
            inner: The live doors.
            overlay: Drawn over each presented frame, or None.

        Returns:
            The doors.

        """
        if self.ai_link is None:
            return HostSources(inner=inner, overlay=overlay)
        # Imported here: a run without AI never loads it
        from glitchygames.ai_host import AiHostSources

        ai_sources = AiHostSources(inner=inner, link=self.ai_link, overlay=overlay)
        self.ai_console = ai_sources.console
        return ai_sources

    def _build_game(self: Self, *, paced_by_timer: bool) -> None:
        """Construct the game and its first scene, up to the first frame (inside the boundary).

        Args:
            paced_by_timer: Whether the frames wait on the engine's timer (``start()``), which
                is then calibrated; False for ``start_async()``.

        """
        # As the game loads: this returns at once, and the models load on the link's thread
        if self.ai_link is not None:
            self.ai_link.start()

        # Build the game's scene: engine.game stays its class, the scene is running_game.instance
        scene = self.game(options=self.options)
        self.running_game = RunningGame(game_class=self.game, instance=scene)

        # The setter gives the scene manager this engine's options (manager.engine_options)
        self.scene_manager.game_engine = self

        self._initialize_event_managers()

        self.scene_manager.switch_to_scene(scene)
        self._configure_timer_and_performance(paced_by_timer=paced_by_timer)
        self._start_requested_trace_recording()

    def _describe_exit_request(self: Self, *, exit_status: object) -> str:
        """Describe a SystemExit that ended the run, for the log and the replay report.

        Args:
            exit_status: The SystemExit's code.

        Returns:
            ``ExitCode.describe_status`` of an integer status (logged as ``Exiting with ...``),
            else ``SystemExit(<code>)``.

        """
        if isinstance(exit_status, int):
            description = ExitCode.describe_status(exit_status)
            self.log.info('Exiting with %s', description)
            return description
        return f'SystemExit({exit_status!r})'

    def _end_run(self: Self, *, exit_code: ExitCode | None, run_error: Exception | None) -> None:
        """Exit as the run ended, once its teardown has run (the recording is closed).

        Args:
            exit_code: The code the run ends with (None: it ended normally).
            run_error: The exception that ended it, chained as the exit's cause, or None.

        """
        exit_code = self._exit_code_after_recording(exit_code=exit_code)
        if exit_code is not None:
            exit_with(exit_code=exit_code, cause=run_error)
        if self.replay_sources is not None:
            self._end_replay_run(replay_sources=self.replay_sources)

    def _exit_code_after_recording(self: Self, *, exit_code: ExitCode | None) -> ExitCode | None:
        """Return the run's exit code, made ``CANNOT_WRITE_OUTPUT`` if its recording failed.

        A recording whose last write failed as it was closed in the teardown (the gzip trailer)
        turns a run that otherwise ended normally into ``CANNOT_WRITE_OUTPUT``; a run already
        ending with a code (a crash, a signal) keeps it.

        Args:
            exit_code: The code the run ends with so far (None: it ended normally).

        Returns:
            The exit code (None: the run ends normally).

        """
        if exit_code is None and self.recording_write_failed:
            return ExitCode.CANNOT_WRITE_OUTPUT
        return exit_code

    def _outcome_of_a_replay_cut_short(
        self: Self, *, run_ended_by: str
    ) -> tuple[ExitCode | None, str | None]:
        """Return how a run ends when a game's own successful exit cut its replay short.

        A plain replay ends as diverged: ``SUCCESS`` would say it matched (the report says
        where it stopped). A reseeded replay (another seed than recorded) ends normally: it
        compares nothing, so an early end is no failure. A rebaseline takes it as the game
        ending early, as ``quit_game()`` would: the run ends normally, NEW is written with the
        frames that ran and the run exits ``REBASELINE_INPUT_LOST``
        (glitchygames/replay/rebaseline.py, rule 4).

        Args:
            run_ended_by: The exit, described (``_describe_exit_request``).

        Returns:
            The exit code ``start`` exits with (None: the normal end of a replay) and what
            ended the run early (None: it ended normally).

        """
        if self.rebaseline is not None:
            return None, None
        if self.replay_sources is not None and self.replay_sources.is_reseeded:
            # Under another seed than recorded the game may well end otherwise (rule 19 of
            # glitchygames/replay/driver.py): its own exit ends the run normally, as quit_game()
            # would, and the replay reports what differed, never a failure
            return None, None
        return ExitCode.REPLAY_DIVERGED, run_ended_by

    def _exit_cuts_a_replay_short(self: Self, *, exit_status: object) -> bool:
        """Report whether a successful SystemExit ended a replay before it reached its result.

        A game's own ``sys.exit(0)`` (or ``sys.exit()``) during a replay that is still running
        would end the run ``SUCCESS``, which says the replay matched: ``start`` exits
        ``REPLAY_DIVERGED`` instead. Any other status (a signal's, a game's failure) is kept, as
        it already says the run did not succeed.

        Args:
            exit_status: The SystemExit's code.

        Returns:
            True while replaying, the replay still running and the status 0 or None.

        """
        return (
            self.replay_sources is not None
            and self.replay_sources.result.end_reason == RUNNING_END_REASON
            and (
                exit_status is None
                or (isinstance(exit_status, int) and exit_status == ExitCode.SUCCESS)
            )
        )

    def _end_replay_run(self: Self, *, replay_sources: ReplaySources) -> NoReturn:
        """Exit a replay's run that ended normally, after the teardown.

        A replay exits with its own code (a divergence is ``REPLAY_DIVERGED``; never the
        ``INTERNAL_ERROR`` or ``INTERRUPTED`` of an early end), unless the viewer stepped back:
        then the replay restarts (``_restart_replay``), its window already closed. A rebaseline
        whose new recording could not be moved into place (glitchygames/replay/rebaseline.py,
        rule 4), and a replay whose digest file could not be written (rule 12 of
        glitchygames/replay/driver.py), exit ``CANNOT_WRITE_OUTPUT``.

        Args:
            replay_sources: The replay's sources.

        """
        restart_frame = replay_sources.result.restart_frame
        if restart_frame is not None:
            self._restart_replay(replay_sources=replay_sources, restart_frame=restart_frame)
        rebaseline_write_failed = self.rebaseline is not None and self.rebaseline.write_failed
        if rebaseline_write_failed or replay_sources.digest_write_failed:
            exit_with(exit_code=ExitCode.CANNOT_WRITE_OUTPUT)
        exit_with(
            exit_code=replay_sources.result.exit_code(policy=replay_sources.options.exit_policy)
        )

    def _restart_replay(
        self: Self, *, replay_sources: ReplaySources, restart_frame: int
    ) -> NoReturn:
        """Restart the torn-down watched replay at ``restart_frame`` and exit with the outcome.

        The restart (glitchygames/replay/rebuild.py) runs this process's own command line with
        the pause frame, keeping whether the debug overlay was shown; this process either hands
        it to the supervising replay process or supervises the restarted replays itself. With
        bookmarks, the bookmarked copy is saved first and the restart replays it, so the
        bookmarks survive (rule 16 of glitchygames/replay/driver.py); if it cannot be saved,
        the restart replays this run's recording without them, with a warning naming them.

        Args:
            replay_sources: The torn-down replay's sources.
            restart_frame: The frame the restarted replay pauses at.

        Raises:
            SystemExit: Always, with the status ``relaunch_replay`` returns.

        """
        self.log.info('Restarting the replay at frame %s', restart_frame)
        debug_overlay = self.scene_manager.debug_overlay
        controls = replay_sources.controls
        recording_path = Path(self.options['replay_trace'])
        if controls.bookmarks:
            bookmarked_copy = replay_sources.bookmarks.save()
            if bookmarked_copy is None:
                self.log.warning(
                    'Restarting without the bookmarks %s: the bookmarked copy '
                    'of %s could not be saved',
                    controls.bookmarks,
                    recording_path,
                )
            else:
                recording_path = bookmarked_copy
        command = restart_command(
            original=sys.orig_argv,
            recording_path=recording_path,
            pause_at_frame=restart_frame,
            debug_overlay_visible=debug_overlay.is_visible,
            viewer_state=ViewerState(
                speed=controls.speed,
                debug_panel=debug_overlay.panel,
                divergence_frame=controls.divergence_frame,
                # The game frame the restart shows paused, for OLD's child (rule 8 of
                # glitchygames/replay/tools/compare.py)
                compare_first_game_frame=(
                    None
                    if self.onion_skin is None
                    else replay_sources.result.shown_game_frames.get(
                        first_streamed_frame(pause_at_frame=restart_frame)
                    )
                ),
            ),
        )
        # _shutdown put the default handling back: while supervising, SIGTERM and SIGHUP end the
        # run with SystemExit again, so subprocess.run kills and reaps the child
        with self._waiting_for_child_processes():
            status = relaunch_replay(
                command=command,
                handoff_path=replay_sources.options.restart_handoff_path,
                result_exit_code=replay_sources.result.exit_code(
                    policy=replay_sources.options.exit_policy
                ),
            )
        try:
            exit_code = ExitCode(status)
        except ValueError:
            # A status no member names (a game's own exit status, a signal without a member)
            self.log.info('Exiting with %s', ExitCode.describe_status(status))
            raise SystemExit(status) from None
        exit_with(exit_code=exit_code)

    @classmethod
    def quit_game(cls) -> None:
        """Quit the game.

        Emits a events.HashableEvent(pygame.QUIT, {}) event.

        """
        # put a quit event in the event queue.
        post_event(pygame.event.Event(pygame.QUIT, {}))

    def handle_event(self, event: events.HashableEvent) -> None:
        """Handle pygame events.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        # First check for system-level QUIT event (window close button)
        if event.type == pygame.QUIT:
            self.log.info('Window close requested')
            self.scene_manager.quit_requested = True
            return

        # Check if there are any focused sprites in the current scene
        scene = self.scene_manager.active_scene
        if scene and scene.all_sprites:
            focused_sprites = [
                sprite
                for sprite in scene.all_sprites
                if hasattr(sprite, 'is_active') and sprite.is_active
            ]

            # If we have focused sprites, ALL key events go to the scene
            if focused_sprites and event.type == pygame.KEYDOWN:
                self.scene_manager.handle_event(event)
                return

        # Only handle engine-level key events if no focused sprites
        if event.type == pygame.KEYDOWN and getattr(event, 'key', None) == pygame.K_q:
            self.log.info('Quit key pressed with no focused sprites')
            self.scene_manager.quit_requested = True
            return

        # Pass other events to the scene manager
        self.scene_manager.handle_event(event)

    def process_events(
        self: Self, *, should_discard: Callable[[pygame.event.Event], bool] | None = None
    ) -> bool:
        """Process every event queued this frame.

        ``pygame.event.get()`` removes the whole batch from SDL's queue at once, so every event
        of the batch is handled here: none may be dropped. Each event is judged on its own; an
        event whose type has no entry in ``event_handlers``, or whose handler did not handle
        it, goes to ``process_unimplemented_event``.

        Args:
            should_discard: Returns True for an event to remove from the batch without
                processing it (not counted as unhandled). SceneManager passes
                ``is_discarded_during_transition`` during a transition.

        Returns:
            bool: True if at least one event was dispatched and every dispatched event was
            handled (a raw-event scene's ``process_event`` counts as handled). False if any
            dispatched event was unhandled, or if nothing was dispatched: an empty batch, or
            one whose events were all discarded.

        """
        raw_events = self._pump_events()
        # Polled input is read once per frame, right after the pump, so it agrees with this
        # frame's events; it stays fixed until the next frame's pump, so dt_tick (which runs
        # before this) reads the previous frame's snapshot (glitchygames/input/state.py)
        set_current_input(snapshot=active_sources().input_snapshot())
        dispatched_event_count = 0
        every_event_was_handled = True
        for pygame_event in raw_events:
            if should_discard is not None and should_discard(pygame_event):
                continue
            dispatched_event_count += 1

            # Support scenes processing pygame raw events, bypassing
            # the glitchygames.engine event processing altogether
            if hasattr(self._active_scene, 'process_event'):
                self._active_scene.process_event(pygame_event)  # type: ignore[union-attr] # ty: ignore[call-non-callable]
                continue

            event = events.HashableEvent.from_pygame(pygame_event)

            # Decided per event: a type missing from the map is unhandled
            event_was_handled = False
            if event.type in self.event_handlers:
                event_was_handled = bool(self.event_handlers[event.type](event))

            # If an event is not in the event handler map, or the function
            # called didn't handle the event in question, we'll process it
            # as an unimplemented event
            if not event_was_handled:
                self.process_unimplemented_event(event)
                every_event_was_handled = False

        return dispatched_event_count > 0 and every_event_was_handled

    def _pump_events(self: Self) -> list[pygame.event.Event]:
        """Take the next batch from the active sources' event pump: the one place it is read.

        Live sources read SDL's queue; a replay's sources hand back a recorded batch instead;
        ``--record-trace``'s ``RecordingSources`` record the batch exactly as the pump returned
        it, before any dispatch or discarding (glitchygames/sources.py). Events a playback scope
        held for the live game come first (``take_redelivered_events``, taken after the doors'
        pump so a recording can write them into this frame's ``redelivered_events``). The
        scene manager's instant-replay journal gets the batch too, classified as a recorder
        classifies it (glitchygames/instant_replay.py, rule 4): by a replay's merge when the
        doors are a replay's (``ReplaySources.last_batch_origins``), else by the code-posted
        events pending before the pump. Then the posts the pump did not return are forgotten
        (the engine owns the internal-post tracker for the whole run).

        Returns:
            The batch, in queue order.

        """
        posts_before_pump = list(pending_internal_posts())
        doors = active_sources()
        batch = doors.pump_events()
        redelivered_events = take_redelivered_events()
        self.scene_manager.journal_pumped_events(
            raw_events=batch,
            posts_before_pump=posts_before_pump,
            origins=replayed_batch_origins(doors=doors),
            redelivered_events=redelivered_events,
        )
        # Matched or not returned, the posts made before this pump are done with (a recorder
        # or a replay pumping underneath has already consumed them)
        forget_pending_posts()
        return [*(event for event, _origin in redelivered_events), *batch]

    def process_audio_event(self: Self, event: events.HashableEvent) -> bool:
        """Process an audio event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if event.type == pygame.AUDIODEVICEADDED:
            # AUDIODEVICEADDED which, iscapture
            self.audio_manager.on_audio_device_added_event(event)
            return True

        if event.type == pygame.AUDIODEVICEREMOVED:
            # AUDIODEVICEREMOVED which, iscapture
            self.audio_manager.on_audio_device_removed_event(event)
            return True

        return False

    def process_app_event(self: Self, event: events.HashableEvent) -> bool:  # ruff: ignore[too-many-return-statements]
        """Process an app event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if event.type == pygame.APP_DIDENTERBACKGROUND:
            self.app_manager.on_app_did_enter_background_event(event)
            return True

        if event.type == pygame.APP_DIDENTERFOREGROUND:
            self.app_manager.on_app_did_enter_foreground_event(event)
            return True

        if event.type == pygame.APP_WILLENTERBACKGROUND:
            self.app_manager.on_app_will_enter_background_event(event)
            return True

        if event.type == pygame.APP_WILLENTERFOREGROUND:
            self.app_manager.on_app_will_enter_foreground_event(event)
            return True

        if event.type == pygame.APP_LOWMEMORY:
            self.app_manager.on_app_low_memory_event(event)
            return True

        if event.type == pygame.APP_TERMINATING:
            self.app_manager.on_app_terminating_event(event)
            return True

        return False

    def process_controller_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a controller event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if self.controller_manager is None:
            return False

        # Each device's input events come from one layer only: a controller event of a device
        # the game does not see on its controller layer is dropped (handled: deliberately not
        # dispatched; glitchygames/input/input_devices.py, rules 1 and 2)
        if not self.input_devices.dispatches(
            event_type=event.type, instance_id=self._device_event_instance_id(event=event)
        ):
            return True

        # Matched by class (the type's class from events.EVENT_CLASSES, which every event of
        # the type is, however it was built) and then by type where a class covers several
        manager = self.controller_manager
        match event:
            case events.ControllerAxisEvent():
                manager.on_controller_axis_motion_event(event)
            case events.ControllerTouchpadEvent(type=pygame.CONTROLLERTOUCHPADMOTION):
                manager.on_controller_touchpad_motion_event(event)
            case events.ControllerButtonEvent(type=pygame.CONTROLLERBUTTONDOWN):
                manager.on_controller_button_down_event(event)
            case events.ControllerButtonEvent(type=pygame.CONTROLLERBUTTONUP):
                manager.on_controller_button_up_event(event)
            case events.ControllerTouchpadEvent(type=pygame.CONTROLLERTOUCHPADDOWN):
                manager.on_controller_touchpad_down_event(event)
            case events.ControllerTouchpadEvent(type=pygame.CONTROLLERTOUCHPADUP):
                manager.on_controller_touchpad_up_event(event)
            case events.HashableEvent(type=pygame.CONTROLLERSENSORUPDATE):
                manager.on_controller_sensor_update_event(event)
            case _:
                return self._process_controller_device_event(manager=manager, event=event)
        return True

    def _process_controller_device_event(
        self: Self, *, manager: ControllerEventManager, event: events.HashableEvent
    ) -> bool:
        """Process a controller's added, removed or remapped event (``process_controller_event``).

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        match event:
            case events.ControllerDeviceEvent(type=pygame.CONTROLLERDEVICEREMOVED):
                manager.on_controller_device_removed_event(event)
                self._synchronize_input_devices()
            case events.ControllerDeviceAddedEvent():
                manager.on_controller_device_added_event(event)
                self._synchronize_input_devices()
            case events.ControllerDeviceEvent(type=pygame.CONTROLLERDEVICEREMAPPED):
                manager.on_controller_device_remapped_event(event)
            case _:
                # We haven't handled this event, so let's see if it's a controller init event
                return False
        return True

    def process_drop_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a drop event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if event.type == pygame.DROPBEGIN:
            self.drop_manager.on_drop_begin_event(event)
            return True

        if event.type == pygame.DROPCOMPLETE:
            self.drop_manager.on_drop_complete_event(event)
            return True

        if event.type == pygame.DROPFILE:
            self.drop_manager.on_drop_file_event(event)
            return True

        if event.type == pygame.DROPTEXT:
            self.drop_manager.on_drop_text_event(event)
            return True

        return False

    def process_touch_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a touch event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if event.type == pygame.FINGERDOWN:
            self.touch_manager.on_touch_down_event(event)
            return True

        if event.type == pygame.FINGERUP:
            self.touch_manager.on_touch_up_event(event)
            return True

        if event.type == pygame.FINGERMOTION:
            self.touch_manager.on_touch_motion_event(event)
            return True

        return False

    def process_midi_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a midi event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if event.type == pygame.MIDIIN:
            # MIDIIN device_id, status, data1, data2
            self.scene_manager.handle_event(event)
            return True

        if event.type == pygame.MIDIOUT:
            # MIDIOUT device_id, status, data1, data2
            self.scene_manager.handle_event(event)
            return True

        return False

    def process_mouse_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a mouse event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if event.type == pygame.MOUSEMOTION:
            # MOUSEMOTION      pos, rel, buttons
            self.mouse_manager.on_mouse_motion_event(event)
            return True

        if event.type == pygame.MOUSEBUTTONUP:
            # MOUSEBUTTONUP    pos, button
            self.mouse_manager.on_mouse_button_up_event(event)
            return True

        if event.type == pygame.MOUSEBUTTONDOWN:
            # MOUSEBUTTONDOWN  pos, button
            self.log.debug(
                'ENGINE: MOUSEBUTTONDOWN received: button=%s, pos=%s',
                getattr(event, 'button', None),
                getattr(event, 'pos', None),
            )
            self.mouse_manager.on_mouse_button_down_event(event)
            return True

        if event.type == pygame.MOUSEWHEEL:
            self.mouse_manager.on_mouse_wheel_event(event)
            return True

        return False

    def process_keyboard_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a keyboard event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        if event.type == pygame.KEYDOWN:
            # KEYDOWN          unicode, key, mod
            self.keyboard_manager.on_key_down_event(event)
            return True

        if event.type == pygame.KEYUP:
            # KEYUP            key, mod
            self.keyboard_manager.on_key_up_event(event)
            return True

        return False

    def process_joystick_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a joystick event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        # Each device's input events come from one layer only: a mapped pad's joystick-layer
        # events are dropped (handled: deliberately not dispatched), as are the events of a
        # device the game does not see (glitchygames/input/input_devices.py, rules 1 and 2)
        if not self.input_devices.dispatches(
            event_type=event.type, instance_id=self._device_event_instance_id(event=event)
        ):
            return True

        # Matched by class (the type's class from events.EVENT_CLASSES), then by type for
        # the button class's two types
        match event:
            case events.JoyAxisEvent():
                # JOYAXISMOTION    instance_id, axis, value
                self.joystick_manager.on_joy_axis_motion_event(event)
            case events.JoyBallEvent():
                # JOYBALLMOTION    instance_id, ball, rel
                self.joystick_manager.on_joy_ball_motion_event(event)
            case events.JoyHatEvent():
                # JOYHATMOTION     instance_id, hat, value
                self.joystick_manager.on_joy_hat_motion_event(event)
            case events.JoyButtonEvent(type=pygame.JOYBUTTONUP):
                # JOYBUTTONUP      instance_id, button
                self.joystick_manager.on_joy_button_up_event(event)
            case events.JoyButtonEvent(type=pygame.JOYBUTTONDOWN):
                # JOYBUTTONDOWN    instance_id, button
                self.joystick_manager.on_joy_button_down_event(event)
            case events.JoyDeviceAddedEvent():
                self.joystick_manager.on_joy_device_added_event(event)
                self._synchronize_input_devices()
            case events.JoyDeviceRemovedEvent():
                self.joystick_manager.on_joy_device_removed_event(event)
                self._synchronize_input_devices()
            case _:
                return False
        return True

    @staticmethod
    def _device_event_instance_id(*, event: events.HashableEvent) -> int | None:
        """Return the instance id of a joystick or controller event, None when it has none.

        An added event names a device index instead (``device_index``): it is a device
        event, which always passes (``InputDevices.dispatches``).

        Returns:
            The instance id, or None.

        """
        instance_id = event.dict.get('instance_id')
        return None if instance_id is None else int(instance_id)

    def process_text_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a text event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        # To the active scene's on_text_*_event (BUGS.md #200 item 1: both went to
        # process_unimplemented_event, so Scene's text handlers were never called)
        if event.type == pygame.TEXTEDITING:
            self.scene_manager.on_text_editing_event(event)
            return True

        if event.type == pygame.TEXTINPUT:
            self.scene_manager.on_text_input_event(event)
            return True

        return False

    def _build_window_event_dispatch(self: Self) -> dict[int, Callable[..., Any]]:
        """Build dispatch table mapping window event types to handler methods.

        Returns:
            Dictionary mapping pygame window event types to handler callables.

        """
        return {
            pygame.WINDOWSIZECHANGED: self.window_manager.on_window_size_changed_event,
            pygame.WINDOWRESTORED: self.window_manager.on_window_restored_event,
            pygame.WINDOWHITTEST: self.window_manager.on_window_hit_test_event,
            pygame.WINDOWHIDDEN: self.window_manager.on_window_hidden_event,
            pygame.WINDOWMINIMIZED: self.window_manager.on_window_minimized_event,
            pygame.WINDOWMAXIMIZED: self.window_manager.on_window_maximized_event,
            pygame.WINDOWMOVED: self.window_manager.on_window_moved_event,
            pygame.WINDOWCLOSE: self.window_manager.on_window_close_event,
            pygame.WINDOWEXPOSED: self.window_manager.on_window_exposed_event,
            pygame.WINDOWFOCUSLOST: self.window_manager.on_window_focus_lost_event,
            pygame.WINDOWFOCUSGAINED: self.window_manager.on_window_focus_gained_event,
            pygame.WINDOWRESIZED: self.window_manager.on_window_resized_event,
            pygame.WINDOWLEAVE: self.window_manager.on_window_leave_event,
            pygame.WINDOWENTER: self.window_manager.on_window_enter_event,
            pygame.WINDOWSHOWN: self.window_manager.on_window_shown_event,
            # BUGS.md #200 item 1: it had a handler but no entry, so it was never routed
            pygame.WINDOWTAKEFOCUS: self.window_manager.on_window_take_focus_event,
        }

    def process_window_event(self: Self, event: events.HashableEvent) -> bool:
        """Process a window event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        dispatch: dict[int, Callable[..., Any]] = self._build_window_event_dispatch()
        handler = dispatch.get(event.type)
        if handler:
            handler(event)
            return True

        return False

    def process_game_event(self: Self, event: events.HashableEvent) -> bool:  # ruff: ignore[too-many-return-statements]
        """Process a game event.

        Args:
            event (events.HashableEvent): The event.

        Returns:
            bool: True if the event was handled, False otherwise.

        """
        # Game events are listed in the order they're most
        # likely to occur in; matched by class (the type's class from events.EVENT_CLASSES),
        # or by type for the types without a class of their own
        match event:
            case events.FpsEvent():
                # FPSEVENT is pygame.USEREVENT + 1
                self.game_manager.on_fps_event(event)
                return True

            case events.GameEvent():
                # GAMEEVENT is pygame.USEREVENT + 2
                self.game_manager.on_game_event(event)
                return True

            case events.HashableEvent(type=events.MENUEVENT):
                # MENUEVENT is pygame.USEREVENT + 3
                self.game_manager.on_menu_item_event(event)
                return True

            case events.ActiveEvent():
                # ACTIVEEVENT      gain, state
                self.game_manager.on_active_event(event)
                return True

            case events.HashableEvent(type=pygame.USEREVENT):
                # USEREVENT        code
                self.game_manager.on_user_event(event)
                return True

            case events.VideoResizeEvent():
                # VIDEORESIZE      size, w, h
                self.game_manager.on_video_resize_event(event)
                return True

            case events.HashableEvent(type=pygame.VIDEOEXPOSE):
                # VIDEOEXPOSE      none
                self.game_manager.on_video_expose_event(event)
                return True

            case events.HashableEvent(type=pygame.SYSWMEVENT):
                # SYSWMEVENT
                self.game_manager.on_sys_wm_event(event)
                return True

            case events.HashableEvent(type=pygame.QUIT):
                # QUIT             none
                self.game_manager.on_quit_event(event)
                return True

            case _:
                pass

        return False

    def process_unimplemented_event(self: Self, event: events.HashableEvent) -> None:
        """Process an unimplemented event.

        Args:
            event (events.HashableEvent): The event.

        """
        self._record_unhandled_event(event)

        # Debug: Special handling for event type 1543
        if event.type == UNKNOWN_SDL2_EVENT_TYPE_1543:
            event_name = pygame.event.event_name(event.type)
            LOG.debug(
                'process_unimplemented_event received event type %s (%s): %s',
                event.type,
                event_name,
                event,
            )
            LOG.debug('Event dict contents: %s', dict(event))
            LOG.debug(
                'Event attributes: %s',
                [attr for attr in dir(event) if not attr.startswith('_')],
            )

            # Check if this might be a controller event by looking at controller count
            # (through the devices door, glitchygames/input/devices.py)
            try:
                current_controller_count: int = active_sources().devices().controller_count()
                LOG.debug(
                    'Current controller count when event 1543 received: %s',
                    current_controller_count,
                )
            except pygame.error:
                LOG.debug('Controller system not initialized — skipping controller count check')

            # Check if this event has any controller-related attributes
            LOG.debug('Event has device_index: %s', hasattr(event, 'device_index'))
            LOG.debug('Event has guid: %s', hasattr(event, 'guid'))
            LOG.debug('Event has instance_id: %s', hasattr(event, 'instance_id'))

            # Try to get the raw event object if possible
            LOG.debug('Event type: %s', type(event))
            LOG.debug('Event repr: %r', event)
            LOG.debug(
                'pygame.event.event_name(event.type): %s',
                pygame.event.event_name(event.type),
            )

        if event.type not in self.unimplemented_events:
            self.log.debug(
                '(UNIMPLEMENTED) %s: %s',
                pygame.event.event_name(event.type).upper(),
                event,
            )
            self.unimplemented_events.append(event.type)

    def _record_unhandled_event(self: Self, event: events.HashableEvent) -> None:
        """Count an unhandled event under its type, keeping the first one's time and names.

        Args:
            event (events.HashableEvent): The event.

        """
        record = self.unhandled_events.get(event.type)
        if record is not None:
            record.count += 1
            return
        # Names only: values can be large or private. 'type' is the key itself, and names
        # starting with '_' are internals (HashableEvent's cached hash)
        attribute_names = tuple(
            sorted(
                name
                for name in getattr(event, '__dict__', {})
                if name != 'type' and not name.startswith('_')
            )
        )
        self.unhandled_events[event.type] = UnhandledEventRecord(
            count=1,
            # The frame clock, which reset_sources() restarted in __init__
            first_seen_seconds=clock.elapsed_seconds(),
            attribute_names=attribute_names,
        )

    def unhandled_event_report(self: Self) -> list[str]:
        """Describe every unhandled event type, most frequent first.

        Each line names the type (pygame's event name and its number, so custom and unknown
        types still show), its count, when it was first seen and the first event's attribute
        names, e.g. ``JOYDEVICEADDED (1541) x1, first at 0.3 s, attributes: device_index, guid``.

        Returns:
            One line per type; empty when every event was handled.

        """
        records = sorted(
            self.unhandled_events.items(),
            key=lambda item: item[1].count,
            reverse=True,
        )
        return [
            f'{pygame.event.event_name(event_type).upper()} ({event_type}) x{record.count}, '
            f'first at {record.first_seen_seconds:.1f} s, '
            f'attributes: {", ".join(record.attribute_names) or "none"}'
            for event_type, record in records
        ]

    def _log_sprite_count_report(self: Self) -> None:
        """Log the sprite counts at teardown: the total, then each sprite type's counters.

        Logged here, not from a finaliser: a ``__del__`` runs whenever the garbage collector
        does, possibly in the middle of a write to the stream the log goes to, where a second
        write raises ``RuntimeError: reentrant call`` (BUGS.md #188).
        """
        counters_of_this_context = sprite_counters()
        self.log.info('Sprite Count: %s', counters_of_this_context.count)
        for sprite_type, counters in counters_of_this_context.counters.items():
            for counter_name, counter_value in counters.items():
                self.log.info('%s Sprite %s: %s', sprite_type, counter_name, counter_value)

    def _log_unhandled_event_report(self: Self) -> None:
        """Log the unhandled event table at teardown; log nothing if there were none."""
        report_lines = self.unhandled_event_report()
        if not report_lines:
            return
        # Framed like the performance shutdown reports logged just before it
        self.log.info('\n%s', '=' * 80)
        self.log.info('Unhandled events:')
        for report_line in report_lines:
            self.log.info('  %s', report_line)
        self.log.info('=' * 80)

    def post_game_event(self: Self, event_subtype: int, event_data: dict[str, Any]) -> None:
        """Post a game event.

        Args:
            event_subtype (int): The event subtype.
            event_data (dict[str, Any]): The event data.

        """
        event: dict[str, Any] = event_data.copy()
        event['subtype'] = event_subtype
        post_event(pygame.event.Event(events.GAMEEVENT, event))
        self.log.debug('Posted Event: %s', event)

    def suppress_event(self: Self, *args: Any, attr: str, **kwargs: Any) -> None:
        """Suppress an event.

        Args:
            *args: The args.
            attr (str): The attribute.
            **kwargs: The kwargs.

        """
        self.log.debug('Suppressing event: %s(%s, %s)', attr, args, kwargs)

    def register_game_event(self: Self, event_type: int, callback: Callable[..., Any]) -> None:
        """Register a game event.

        Args:
            event_type (int): The event type.
            callback (Callable[..., Any]): The callback.

        """
        # This registers a subtype of type GAMEEVENT to call a callback.
        self.log.info('Registering event type "%s" for %s', event_type, callback)
        self.registered_events[event_type] = callback

    def missing_event(self: Self, *args: Any, **kwargs: Any) -> None:
        """Suppress unhandled on_*_event methods.

        We only want to log this once per event type.

        Args:
            *args: The args.
            **kwargs: The kwargs.

        """
        # NOTE: Consider adding an engine option to raise an exception
        #       when an unimplemented event is called.
        if self.last_event_miss not in self.missing_events:
            self.missing_events.append(self.last_event_miss)

            self.log.info(
                'Unimplemented method called: %s%s, %s', self.last_event_miss, args, kwargs
            )
            self.suppress_event(*args, attr=self.last_event_miss, **kwargs)

        # Ensures we can always ctrl-c in cases where event spam occurs.
        clock.raw_sleep(0)

    # If the game hasn't hooked a call, we should check if the scene manager has.
    #
    # This will allow scenes to get pygame events directly, but we can still
    # hook those events in this engine, or in the subclassed game object, too.
    #
    # This allows maximum flexibility of event processing, with low overhead
    # at the expense of a slight layer violation.
    @override
    def __getattr__(self: Self, attr: str) -> Callable[..., Any]:
        """Suppress unhandled on_*_event methods.

        If the attribute being looked up is not an on_*_event
        attribute, raise AttributeError as usual.

        Args:
            attr (str): The attribute to proxy.

        Returns:
            Callable: The callable object.

        Raises:
            AttributeError: If the attribute is not an on_*_event method.

        """
        if attr.startswith('on_') and attr.endswith('_event'):
            # An instance attribute's write never re-enters __getattr__
            self.last_event_miss = attr

            return self.missing_event

        raise AttributeError(MISSING_ATTRIBUTE_MSG.format(cls=type(self), attr=attr))
