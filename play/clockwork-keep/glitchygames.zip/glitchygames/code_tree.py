"""The code a replay measurement measured: a git tree of only what can change the replays.

A measured row (the project's ledger directory, plans/2026-10-25-measured-rows-in-the-repository.md)
names the code it measured by tree, not by commit: the measuring pre-commit hook runs before its
commit exists, an amend or a squash merge gives the same code another commit, but the tree of
the code stays the same. The tree holds only the project's measured paths (``CodeTreePaths``:
``[tool.glitchygames]`` ``measured-paths``; ours are ``src/``, the engine, games, demos and apps;
the recordings, the locked dependencies and the project configuration), less its unmeasured paths
(``unmeasured-paths``; ours are the workspace members' tests, ``src/<layer>/<member>/tests/``, but
for their recordings, ``tests/fixtures/replays/`` there, as at the root): a later docs, plans or
tests commit leaves it unchanged, so the last measured tree is still the one that lands on main,
and the ledger's own rows never change the tree they name.

Both are git pathspecs, read by git itself (``git rm``, ``git ls-files``), so their magic
(``:(glob)``, ``:(exclude)``) means what git says it means.

The tree functions work on a temporary index (``GIT_INDEX_FILE``), so the real one, and with it
whatever is staged, is never touched. A failing git command raises ``RuntimeError`` naming it.
Which commits count as landed is the project's ``landed-ref`` (ours: ``origin/main``).
"""

from __future__ import annotations

import os
import shutil
import tempfile
import tomllib
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING, cast

from pydantic import BaseModel, ConfigDict

from glitchygames.process import OutputCapture, run_command

if TYPE_CHECKING:
    import subprocess

GIT_TIMEOUT_SECONDS = 60.0


class CodeTreePaths(BaseModel):
    """What a code tree holds: git pathspecs, relative to the repository.

    Attributes:
        measured: The paths a code tree holds (``[tool.glitchygames]`` ``measured-paths``).
        unmeasured: The paths left out of them (``unmeasured-paths``; none by default).

    """

    model_config = ConfigDict(frozen=True, extra='forbid')

    measured: tuple[str, ...]
    unmeasured: tuple[str, ...] = ()


def _completed_git(
    *, repository: Path, arguments: list[str], index_file: Path | None = None
) -> subprocess.CompletedProcess[str]:
    """Run git in ``repository``, on ``index_file`` when given, whatever its exit code.

    Returns:
        The finished process (stdout and stderr together in ``stdout``).

    """
    environment = dict(os.environ)
    if index_file is not None:
        environment['GIT_INDEX_FILE'] = str(index_file)
    return run_command(
        command=['git', *arguments],
        environment=environment,
        timeout_seconds=GIT_TIMEOUT_SECONDS,
        capture_output=OutputCapture.TOGETHER,
        working_directory=repository,
    )


def run_git(*, repository: Path, arguments: list[str], index_file: Path | None = None) -> str:
    """Run git in ``repository``, on ``index_file`` when given, and return its output.

    Returns:
        Standard output, stripped.

    Raises:
        RuntimeError: If git fails (the command and its output in the message).

    """
    command = ['git', *arguments]
    completed = _completed_git(repository=repository, arguments=arguments, index_file=index_file)
    if completed.returncode != 0:
        message = f'{" ".join(command)} failed in {repository}: {completed.stdout.strip()}'
        raise RuntimeError(message)
    return completed.stdout.strip()


def untracked_measured_files(*, repository: Path, paths: CodeTreePaths) -> list[str]:
    """Return the untracked (not ignored) files a code tree of the working tree would hold.

    git lists the untracked files under the measured paths, and those under the unmeasured ones
    are left out, so the pathspecs mean exactly what they mean to the tree functions.

    Args:
        repository: The repository's working directory.
        paths: What a code tree holds.

    Returns:
        Their repository-relative paths, ``/``-separated, in git's order.

    """
    untracked = ['ls-files', '--others', '--exclude-standard', '--']
    measured = run_git(repository=repository, arguments=[*untracked, *paths.measured])
    unmeasured: set[str] = (
        set(run_git(repository=repository, arguments=[*untracked, *paths.unmeasured]).splitlines())
        if paths.unmeasured
        else set()
    )
    return [line for line in measured.splitlines() if line and line not in unmeasured]


def _measured_tree(*, repository: Path, index_file: Path, paths: CodeTreePaths) -> str:
    """Drop all but the measured paths from a temporary index and return the index's tree.

    The measured paths are kept, then the unmeasured ones dropped (ours: the members' tests,
    but for their recordings).

    Returns:
        The tree hash.

    """
    kept = [f':(exclude){path}' for path in paths.measured]
    # --force: git rm refuses a file whose staged content differs from both the working tree
    # and HEAD (a partly staged edit); only this temporary index is changed, never a file
    run_git(
        repository=repository,
        arguments=[
            'rm',
            '-r',
            '--cached',
            '--force',
            '--ignore-unmatch',
            '--quiet',
            '--',
            '.',
            *kept,
        ],
        index_file=index_file,
    )
    # git rm with no pathspec is refused ("No pathspec was given"): nothing to drop then
    if paths.unmeasured:
        run_git(
            repository=repository,
            arguments=[
                'rm',
                '-r',
                '--cached',
                '--force',
                '--ignore-unmatch',
                '--quiet',
                '--',
                *paths.unmeasured,
            ],
            index_file=index_file,
        )
    return run_git(repository=repository, arguments=['write-tree'], index_file=index_file)


def staged_code_tree(*, repository: Path, paths: CodeTreePaths) -> str:
    """Return the code tree of what is staged (the measured paths the next commit will hold).

    Args:
        repository: The repository's working directory.
        paths: What a code tree holds.

    Returns:
        The tree hash.

    """
    real_index = Path(
        run_git(
            repository=repository,
            arguments=['rev-parse', '--path-format=absolute', '--git-path', 'index'],
        )
    )
    with tempfile.TemporaryDirectory(prefix='code-tree-') as directory_name:
        index_file = Path(directory_name) / 'index'
        if real_index.exists():
            shutil.copyfile(real_index, index_file)
        return _measured_tree(repository=repository, index_file=index_file, paths=paths)


def commit_code_tree(*, repository: Path, commit: str, paths: CodeTreePaths) -> str:
    """Return the code tree of a commit (its measured paths).

    Args:
        repository: The repository's working directory.
        commit: Any commit-ish (``HEAD``, a hash, ``origin/main``).
        paths: What a code tree holds.

    Returns:
        The tree hash.

    """
    with tempfile.TemporaryDirectory(prefix='code-tree-') as directory_name:
        index_file = Path(directory_name) / 'index'
        run_git(repository=repository, arguments=['read-tree', commit], index_file=index_file)
        return _measured_tree(repository=repository, index_file=index_file, paths=paths)


# A commit's code tree never changes, so landed_row_files looks each up once per process:
# (repository, full commit hash, paths) -> tree. A docs build asks for every row-adding commit
# in the history, and `mkdocs serve` asks again on each rebuild
_LANDED_COMMIT_CODE_TREES: dict[tuple[Path, str, CodeTreePaths], str] = {}
# Marks a commit's line in landed_row_files' log (a file name never holds a NUL)
_LOG_COMMIT_MARKER = '\x00'
# The project's settings file and its keys for a code tree's paths, as
# glitchygames/replay/tools/settings.py reads them (not imported from there: it imports this
# module)
PYPROJECT_FILE_NAME = 'pyproject.toml'
MEASURED_PATHS_KEY = 'measured-paths'
UNMEASURED_PATHS_KEY = 'unmeasured-paths'


class LandedRowFile(BaseModel):
    """The commit a row file landed in (the first that added it), and that commit's code tree.

    Attributes:
        commit: The full commit hash.
        committed_at: Its commit date (ISO 8601 with its offset).
        code_tree: Its code tree, by its own measured paths (``commit_code_tree_paths``): the
            file's rows landed only if they measured this tree.

    """

    model_config = ConfigDict(frozen=True, extra='forbid')

    commit: str
    committed_at: str
    code_tree: str


def commit_code_tree_paths(
    *, repository: Path, commit: str, fallback: CodeTreePaths
) -> CodeTreePaths:
    """Return what a commit's code tree held: the measured paths its own pyproject.toml names.

    A row's code tree was taken with the paths of its day, so its landing commit's tree is
    taken with that commit's (BUGS.md #220.5): adding a measured path later changes only the
    trees measured after it, and every earlier row still lands.

    Args:
        repository: The repository's working directory (the project root).
        commit: The commit.
        fallback: The paths when the commit's pyproject.toml names none (or is missing or not
            valid TOML): the project's current ones.

    Returns:
        The paths.

    """
    completed = _completed_git(
        repository=repository, arguments=['show', f'{commit}:./{PYPROJECT_FILE_NAME}']
    )
    if completed.returncode != 0:
        return fallback
    try:
        document = tomllib.loads(completed.stdout)
    except tomllib.TOMLDecodeError:
        return fallback
    tool: object = document.get('tool', {})
    if not isinstance(tool, dict):
        return fallback
    settings: object = cast('dict[str, object]', tool).get('glitchygames', {})
    if not isinstance(settings, dict):
        return fallback
    table = cast('dict[str, object]', settings)
    measured = table.get(MEASURED_PATHS_KEY)
    unmeasured = table.get(UNMEASURED_PATHS_KEY, [])
    if not _is_string_list(measured) or not _is_string_list(unmeasured):
        return fallback
    return CodeTreePaths(
        measured=tuple(cast('list[str]', measured)), unmeasured=tuple(cast('list[str]', unmeasured))
    )


def _is_string_list(value: object) -> bool:
    """Return whether a TOML value is a list of strings.

    Returns:
        True for a list whose every item is a string.

    """
    return isinstance(value, list) and all(
        isinstance(item, str) for item in cast('list[object]', value)
    )


def landed_row_files(
    *, repository: Path, ledger_directory: str, paths: CodeTreePaths, revision: str = 'HEAD'
) -> dict[str, LandedRowFile]:
    """Return each row file that landed: the first commit that added it, and its code tree.

    A row lands with the commit that adds its file (on main: the squash merge); the code it
    measured landed only if that commit's code tree is the row's (``recording_metrics
    .landed_rows`` compares them). Each row is dated by its own file's commit, so code that
    returns to an earlier tree dates its new rows by the commit that brought them, not by the
    tree's first landing (BUGS.md #220.3). A row of an intermediate commit or of a branch that
    was behind main names another tree than its file's commit: it does not land.

    Args:
        repository: The repository's working directory.
        ledger_directory: Where the row files are, relative to the repository
            (``[tool.glitchygames]`` ``ledger-directory``).
        paths: What a code tree holds now: a commit whose pyproject.toml names no measured
            paths uses them (``commit_code_tree_paths``).
        revision: Whose history (``HEAD``: the checkout's).

    Returns:
        Row file name (in the ledger directory) -> where it landed.

    Raises:
        RuntimeError: If the repository is a shallow clone: its log stops at the clone's depth,
            so rows of older commits would silently not land (BUGS.md #220.8).

    Each commit's tree is cached for the process (``_LANDED_COMMIT_CODE_TREES``): the log is read
    every call, the trees only of commits not seen before.

    """
    if run_git(repository=repository, arguments=['rev-parse', '--is-shallow-repository']) == 'true':
        message = (
            f'{repository} is a shallow clone: its history stops short, so measured rows of older '
            f'commits would be left out. Fetch the full history first: git fetch --unshallow'
        )
        raise RuntimeError(message)
    resolved_repository = repository.resolve()
    output = run_git(
        repository=repository,
        arguments=[
            'log',
            # %x00: git writes the marker (a NUL cannot be in an argument itself)
            '--format=%x00%H %cI',
            '--name-only',
            '--diff-filter=A',
            revision,
            '--',
            ledger_directory,
        ],
    )
    # Each commit's line, then the row files it added (newest commit first)
    commits_with_files: list[tuple[str, str, list[str]]] = []
    for line in output.splitlines():
        if line.startswith(_LOG_COMMIT_MARKER):
            commit, committed_at = line.removeprefix(_LOG_COMMIT_MARKER).split(' ', maxsplit=1)
            commits_with_files.append((commit, committed_at, []))
        elif line and commits_with_files:
            commits_with_files[-1][2].append(PurePosixPath(line).name)
    landed: dict[str, LandedRowFile] = {}
    for commit, committed_at, file_names in reversed(commits_with_files):
        commit_paths = commit_code_tree_paths(repository=repository, commit=commit, fallback=paths)
        cache_key = (resolved_repository, commit, commit_paths)
        tree = _LANDED_COMMIT_CODE_TREES.get(cache_key)
        if tree is None:
            tree = commit_code_tree(repository=repository, commit=commit, paths=commit_paths)
            _LANDED_COMMIT_CODE_TREES[cache_key] = tree
        for file_name in file_names:
            # The first commit that added it (a file deleted and added again keeps its first)
            landed.setdefault(
                file_name, LandedRowFile(commit=commit, committed_at=committed_at, code_tree=tree)
            )
    return landed


def _git_succeeds(*, repository: Path, arguments: list[str]) -> bool:
    """Return whether a git command exits 0 (any failure, an unknown commit included, is False).

    Returns:
        True when git exited 0.

    """
    return _completed_git(repository=repository, arguments=arguments).returncode == 0


def landed_ref_exists(*, repository: Path, landed_ref: str) -> bool:
    """Return whether the repository has the landed ref (a fresh clone may lack ``origin/main``).

    Args:
        repository: The repository's working directory.
        landed_ref: The ref whose commits count as landed (``[tool.glitchygames]`` ``landed-ref``).

    Returns:
        True when the ref resolves to a commit.

    """
    return _git_succeeds(
        repository=repository,
        arguments=['rev-parse', '--verify', '--quiet', f'{landed_ref}^{{commit}}'],
    )


def commit_has_landed(*, repository: Path, commit: str, landed_ref: str) -> bool:
    """Return whether a commit is the landed ref or one of its ancestors.

    ``git merge-base --is-ancestor`` exits 1 for "not an ancestor" and 128 for a commit or ref
    this repository does not have; neither has landed here, so both answer False.

    Args:
        repository: The repository's working directory.
        commit: The full commit hash.
        landed_ref: The ref whose commits count as landed (``[tool.glitchygames]`` ``landed-ref``).

    Returns:
        True when the commit is on the landed ref.

    """
    return _git_succeeds(
        repository=repository, arguments=['merge-base', '--is-ancestor', commit, landed_ref]
    )
