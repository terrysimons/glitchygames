"""General-purpose Sprite class for Glitchy Games Engine.

This module contains the Sprite class which extends RootSprite with coordinates,
event handling, delta time tracking, and debugging support.
"""

from __future__ import annotations

import collections
import dataclasses
import logging
from typing import TYPE_CHECKING, Any, ClassVar, Self, override

if TYPE_CHECKING:
    from glitchygames.events.base import (
        ActiveEvent,
        HashableEvent,
        JoyAxisEvent,
        JoyBallEvent,
        JoyButtonEvent,
        JoyHatEvent,
        MouseButtonEvent,
        VideoResizeEvent,
    )

import pygame

from glitchygames.engine_context import ContextSlot, current_context
from glitchygames.read_only_views import ReadOnlyView, ReadOnlyViewsABC
from glitchygames.render_target import display_surface

from .root_sprite import RootSprite

LOG = logging.getLogger('game.sprites')

# Error message constants for TRY003 compliance
_ERR_CANNOT_CREATE_SURFACE = "Can't create Surface(({width}, {height}))."


@dataclasses.dataclass
class SpriteCounters:
    """One engine context's sprite counters and breakpoints, which its teardown report logs.

    Attributes:
        counters: Each sprite type's counters (``'count'`` and ``'pixels'``), keyed by
            ``str(type(sprite))``, in the order the types were first made.
        breakpoints: The sprite types to stop in the debugger for: None means no breakpoints,
            an empty list every sprite.
        count: How many sprites were made.

    """

    counters: collections.OrderedDict[str, dict[str, int | float]] = dataclasses.field(
        default_factory=collections.OrderedDict
    )
    breakpoints: list[str] | None = None
    count: int = 0


# Each engine context's sprite counters (glitchygames.engine_context; audit C18): a game in
# another context never counts this context's sprites in its report, nor stops at its breakpoints
SPRITE_COUNTERS_SLOT: ContextSlot[SpriteCounters] = ContextSlot(
    name='glitchygames.sprites.sprite.counters', factory=SpriteCounters
)


def sprite_counters() -> SpriteCounters:
    """Return the current engine context's sprite counters.

    Returns:
        SpriteCounters: The current context's counters, breakpoints and count.

    """
    return current_context().value(slot=SPRITE_COUNTERS_SLOT)


# ReadOnlyViewsABC: RootSprite's metaclass is abc.ABCMeta (read_only_views.py). pygame-ce's stubs
# derive pygame.sprite.Sprite from a Protocol (_HasImageAndRect), so ty takes typing._ProtocolMeta
# for the metaclass; at run time it is ABCMeta, which ReadOnlyViewsABC derives from
class Sprite(RootSprite, metaclass=ReadOnlyViewsABC):  # ruff: ignore[too-many-public-methods]  # ty: ignore[conflicting-metaclass]
    """A convenience class for handling all of the common sprite behaviors."""

    log = LOG
    USE_GFXDRAW: ClassVar = False
    PROXIES: ClassVar = [pygame.sprite]
    # The current context's sprite counters (audit C18), read on the class or on a sprite;
    # read-only views of sprite_counters(), which the engine reads instead
    SPRITE_COUNTERS = ReadOnlyView[
        collections.OrderedDict[str, dict[str, int | float]],
        collections.OrderedDict[str, dict[str, int | float]],
    ](
        read_current=lambda _owner: sprite_counters().counters,
        read_own=lambda _sprite: sprite_counters().counters,
        write_instead='glitchygames.sprites.sprite.sprite_counters().counters',
    )
    # None means no breakpoints.  Empty list means all.
    SPRITE_BREAKPOINTS = ReadOnlyView[list[str] | None, list[str] | None](
        read_current=lambda _owner: sprite_counters().breakpoints,
        read_own=lambda _sprite: sprite_counters().breakpoints,
        write_instead='a breakpoint with Sprite.break_when(...)',
    )
    SPRITE_COUNT = ReadOnlyView[int, int](
        read_current=lambda _owner: sprite_counters().count,
        read_own=lambda _sprite: sprite_counters().count,
        write_instead='glitchygames.sprites.sprite.sprite_counters().count',
    )

    @classmethod
    def break_when(cls: type[Sprite], sprite_type: object | None = None) -> None:
        """Register a breakpoint for a sprite type.

        Args:
            sprite_type (object | None): The sprite type to break on.
                None means break on any sprite.

        """
        # The current context's breakpoints: None means disabled, [] means any
        counters = sprite_counters()
        if counters.breakpoints is None:
            counters.breakpoints = []

        # If none, break always.
        if sprite_type is not None:
            # Register the type asked for (not cls): __init__ compares str(type(self)) with it
            LOG.info('Register break when sprite_type==%s', sprite_type)
            counters.breakpoints.append(str(sprite_type))
        else:
            LOG.info('Register break when sprite_type==<any>')

    def __init__(  # ruff: ignore[too-many-arguments]
        self: Self,
        x: float,
        y: float,
        width: float,
        height: float,
        *,
        name: str | None = None,
        parent: object | None = None,
        groups: pygame.sprite.LayeredDirty[Any] | None = None,
    ) -> None:
        """Initialize a Sprite.

        Args:
            x (int | float): The x coordinate of the sprite.
            y (int | float): The y coordinate of the sprite.
            width (int | float): The width of the sprite.
            height (int | float): The height of the sprite.
            name (str | None): The name of the sprite.
            parent (object | None): The parent of the sprite.
            groups (pygame.sprite.LayeredDirty | None): The sprite groups to add the sprite to.

        """
        if groups is None:
            groups = pygame.sprite.LayeredDirty()

        super().__init__(groups)
        # This is the stuff pygame really cares about.
        self.image = pygame.Surface((width, height))
        self.rect = self.image.get_rect()

        self.dt = 0
        self.dt_timer = 0

        self.rect.x = x
        self.rect.y = y
        self.rect.width = int(width)
        self.rect.height = int(height)

        self.name = name
        # Typed as Any so widget subclasses can access parent-specific attributes
        # without needing casts. The actual parent type is enforced by each widget's
        # __init__ parameter (using Protocol types like _SliderParent, _HasRect, etc.)
        self.parent: Any = parent
        self.proxies = [self]

        # For debugging sanity: an unnamed sprite is named after its class, as a string (the
        # class object itself made name not always a str: BUGS.md #178 item 18)
        if not name:
            self.name = type(self).__name__

        if not self.width:
            self.log.error('%s has 0 Width', type(self))

        if not self.height:
            self.log.error('%s has 0 Height', type(self))

        # Sprites can register callbacks for any event type.
        self.callbacks: dict[str, Any] = {}

        # Each sprite maintains a reference to the screen: an inner context's render target,
        # else the display (glitchygames/render_target.py)
        self.screen = display_surface()
        assert self.screen is not None, (
            'Display surface must be initialized before creating sprites'
        )
        self.screen_width = self.screen.get_width()
        self.screen_height = self.screen.get_height()

        groups.add(self)

        # Add ourselves to the current context's sprite counters.
        counters = sprite_counters()
        my_type = str(type(self))

        if my_type in counters.counters:
            counters.counters[my_type]['count'] += 1
            counters.counters[my_type]['pixels'] = (
                self.width * self.height + counters.counters[my_type]['pixels']
            )
        else:
            counters.counters[my_type] = collections.OrderedDict()
            counters.counters[my_type]['count'] = 1
            # The first sprite's pixels count too (BUGS.md #201: it was recorded as 0)
            counters.counters[my_type]['pixels'] = self.width * self.height
        # The context's count, never the sprite's (BUGS.md #201: self.SPRITE_COUNT += 1 set an
        # attribute on this sprite, so the count the teardown report logs stayed 0)
        counters.count += 1

        # None means disabled.
        if counters.breakpoints is not None:
            # Empty list means all.
            if len(counters.breakpoints) == 0:
                self.log.info('Break when sprite_type==%s', type(self))
                # This breakpoint is intentional
                breakpoint()  # ruff: ignore[debugger]
            else:
                for sprite_type in counters.breakpoints:
                    if str(type(self)) == sprite_type:
                        self.log.info('Break when sprite_type==%s', sprite_type)

                        # This breakpoint is intentional
                        breakpoint()  # ruff: ignore[debugger]

    @property
    def width(self: Self) -> int | float:
        """The width of the sprite.

        Returns:
            int | float: The width of the sprite.

        """
        return self.rect.width

    @width.setter
    def width(self: Self, new_width: float) -> None:
        """Set the width of the sprite.

        Args:
            new_width (int | float): The new width of the sprite.

        """
        self.rect.width = new_width
        self.dirty = 1 if not self.dirty else self.dirty

    @property
    def height(self: Self) -> int | float:
        """The height of the sprite.

        Returns:
            int | float: The height of the sprite.

        """
        return self.rect.height

    @height.setter
    def height(self: Self, new_height: float) -> None:
        """Set the height of the sprite.

        Args:
            new_height (int | float): The new height of the sprite.

        """
        self.rect.height = new_height
        self.dirty = 1 if not self.dirty else self.dirty

    def dt_tick(self: Self, dt: float) -> None:
        """Update the sprite's delta time.

        Args:
            dt (float): The new delta time.

        """
        self.dt = dt
        self.dt_timer += self.dt

    @override
    def update(self: Self) -> None:
        """Update the sprite."""

    def on_joy_axis_motion_event(self: Self, event: JoyAxisEvent) -> None:
        """Handle a joystick axis motion event.

        Args:
            event (JoyAxisEvent): The event to handle.

        """
        # JOYAXISMOTION    joy, axis, value
        # Not logged: axis motion streams every frame while a stick moves.

    def on_joy_button_down_event(self: Self, event: JoyButtonEvent) -> None:
        """Handle a joystick button down event.

        Args:
            event (JoyButtonEvent): The event to handle.

        """
        # JOYBUTTONDOWN    joy, button
        self.log.debug('%s: %s', type(self), event)

    def on_joy_button_up_event(self: Self, event: JoyButtonEvent) -> None:
        """Handle a joystick button up event.

        Args:
            event (JoyButtonEvent): The event to handle.

        """
        # JOYBUTTONUP      joy, button
        self.log.debug('%s: %s', type(self), event)

    def on_joy_hat_motion_event(self: Self, event: JoyHatEvent) -> None:
        """Handle a joystick hat motion event.

        Args:
            event (JoyHatEvent): The event to handle.

        """
        # JOYHATMOTION     joy, hat, value
        self.log.debug('%s: %s', type(self), event)

    def on_joy_ball_motion_event(self: Self, event: JoyBallEvent) -> None:
        """Handle a joystick ball motion event.

        Args:
            event (JoyBallEvent): The event to handle.

        """
        # JOYBALLMOTION    joy, ball, rel
        # Not logged: ball motion streams every frame while the ball moves.
        # MOUSEMOTION      pos, rel, buttons
        # Not logged: motion streams every frame while the mouse moves, to every
        # sprite under it, so a log line here would drown out useful debug output.

    def on_mouse_enter_event(self: Self, event: HashableEvent) -> None:
        """Handle a mouse enter event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        # Custom Event
        self.log.debug('Mouse Enter Event: %s: %s', type(self), event)

    def on_mouse_exit_event(self: Self, event: HashableEvent) -> None:
        """Handle a mouse exit event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        # Custom Event
        self.log.debug('Mouse Exit Event: %s: %s', type(self), event)

    @override
    def on_left_mouse_button_up_event(self: Self, event: MouseButtonEvent) -> None:
        """Handle a left mouse button up event.

        Args:
            event (MouseButtonEvent): The event to handle.

        """
        # MOUSEBUTTONUP    pos, button

        if self.callbacks:
            callback = self.callbacks.get('on_left_mouse_button_up_event', None)
            if callback:
                callback(event=event, trigger=self)
        else:
            super().on_left_mouse_button_up_event(event)

    @override
    def on_right_mouse_button_up_event(self: Self, event: MouseButtonEvent) -> None:
        """Handle a right mouse button up event.

        Args:
            event (MouseButtonEvent): The event to handle.

        """
        # MOUSEBUTTONUP    pos, button
        if self.callbacks:
            callback = self.callbacks.get('on_right_mouse_button_up_event', None)
            if callback:
                callback(event=event, trigger=self)
        else:
            super().on_right_mouse_button_up_event(event)

    @override
    def on_left_mouse_button_down_event(self: Self, event: MouseButtonEvent) -> None:
        """Handle a left mouse button down event.

        Args:
            event (MouseButtonEvent): The event to handle.

        """
        # MOUSEBUTTONDOWN  pos, button
        callback = 'on_left_mouse_button_down_event'

        if self.callbacks:
            callback = self.callbacks.get('on_left_mouse_button_down_event', None)
            if callback:
                callback(event=event, trigger=self)
        else:
            super().on_left_mouse_button_down_event(event)

    @override
    def on_right_mouse_button_down_event(self: Self, event: MouseButtonEvent) -> None:
        """Handle a right mouse button down event.

        Args:
            event (MouseButtonEvent): The event to handle.

        """
        # MOUSEBUTTONDOWN  pos, button
        if self.callbacks:
            callback = self.callbacks.get('on_right_mouse_button_down_event', None)
            if callback:
                callback(event=event, trigger=self)
        else:
            super().on_right_mouse_button_down_event(event)

    def on_mouse_chord_up_event(self: Self, event: HashableEvent) -> None:
        """Handle a mouse chord up event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        self.log.debug('%s: Mouse Chord Up Event: %s', type(self), event)

    def on_mouse_chord_down_event(self: Self, event: HashableEvent) -> None:
        """Handle a mouse chord down event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        self.log.debug('%s: Mouse Chord Down Event: %s', type(self), event)

    def on_quit_event(self: Self, event: HashableEvent) -> None:
        """Handle a quit event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        # QUIT             none
        self.log.debug('%s: %s', type(self), event)
        # terminate() exists on scenes (SceneInterface), not on Sprite: a sprite that also
        # mixes in a scene's interface ends it here. Cast to Any to allow dynamic dispatch.
        game: Any = self
        game.terminate()

    def on_active_event(self: Self, event: ActiveEvent) -> None:
        """Handle an active event.

        Args:
            event (ActiveEvent): The event to handle.

        """
        # ACTIVEEVENT      gain, state
        self.log.debug('%s: %s', type(self), event)

    def on_video_resize_event(self: Self, event: VideoResizeEvent) -> None:
        """Handle a video resize event.

        Args:
            event (VideoResizeEvent): The event to handle.

        """
        # VIDEORESIZE      size, w, h
        self.log.debug('%s: %s', type(self), event)

    def on_video_expose_event(self: Self, event: HashableEvent) -> None:
        """Handle a video expose event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        # VIDEOEXPOSE      none
        self.log.debug('%s: %s', type(self), event)

    def on_sys_wm_event(self: Self, event: HashableEvent) -> None:
        """Handle a sys wm event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        # SYSWMEVENT
        self.log.debug('%s: %s', type(self), event)

    def on_user_event(self: Self, event: HashableEvent) -> None:
        """Handle a user event.

        Args:
            event (pygame.event.Event): The event to handle.

        """
        # USEREVENT        code
        self.log.debug('%s: %s', type(self), event)
        # Not logged: a drag arrives with every mouse motion while a button is held, so a log
        # line here would run every frame of a drag and drown out useful debug output.
        # Not logged: a drag arrives with every mouse motion while a button is held, so a log
        # line here would run every frame of a drag and drown out useful debug output.
        # Not logged: a drag arrives with every mouse motion while a button is held, so a log
        # line here would run every frame of a drag and drown out useful debug output.
        # Not logged: a drag arrives with every mouse motion while a button is held, so a log
        # line here would run every frame of a drag and drown out useful debug output.

    @override
    def __str__(self: Self) -> str:
        """Return a string representation of the sprite.

        Returns:
            str: The string representation.

        """
        return f'{type(self)} "{self.name}" ({self!r})'
