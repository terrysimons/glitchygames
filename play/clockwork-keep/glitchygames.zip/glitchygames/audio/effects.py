"""Effects: synthetic sound effects, tones mixed straight, rendered with the synth toolkit.

One of the two kinds of sound (plans/2026-11-14-sound-migration.md, decision 2): effects are
exact and cheap (blips, sweeps, crunches, jingles); instruments (``audio/instrument.py``) are
the layered renderer, for music and live voices. Both are played through ``audio.sound(...)``.

Effects are data (to_dict/from_dict and TOML files: ``[effects.<name>]`` in a sound file, or
``[recipes.<name>]`` in an older one), so a sound can live next to sprites and be edited without
code. Processing order per tone: oscillator, distortion, filters, tremolo, envelope, volume.
Tones are mixed at their offsets; the mix is then normalized to ``peak``, or, with
``normalize=False``, left exactly as summed.
"""

from __future__ import annotations

import dataclasses
import logging
import tomllib
from typing import TYPE_CHECKING, Any

import numpy as np

from glitchygames.audio.exceptions import EffectError
from glitchygames.audio.synth import (
    Envelope,
    FloatArray,
    Waveform,
    apply_envelope,
    distort,
    frequency_curve,
    high_pass,
    low_pass,
    mix,
    mixed_frame_count,
    mixer_sample_rate,
    normalize,
    oscillator,
    sample_count,
    to_sound,
    tremolo,
)

if TYPE_CHECKING:
    from pathlib import Path

    import pygame

log: logging.Logger = logging.getLogger('game.audio.effects')

RECIPE_NOISE_SEED = 0  # Fixed so a recipe sounds identical every time it renders


@dataclasses.dataclass(frozen=True)
class Tremolo:
    """Amplitude modulation settings."""

    rate_hz: float
    depth: float


@dataclasses.dataclass(frozen=True)
class Tone:
    """One layer of a sound."""

    waveform: Waveform
    start_frequency: float
    duration: float
    envelope: Envelope
    end_frequency: float | None = None  # None: constant pitch
    easing: str = 'linear'
    volume: float = 1.0
    offset: float = 0.0
    low_pass_cutoff: float | None = None
    high_pass_cutoff: float | None = None
    distortion: float | None = None
    tremolo: Tremolo | None = None

    def __post_init__(self) -> None:
        """Validate the settings.

        Raises:
            ValueError: If duration is not positive or offset/volume are negative.

        """
        if self.duration <= 0.0:
            message = f'duration must be > 0, got {self.duration}'
            raise ValueError(message)
        if self.offset < 0.0:
            message = f'offset must be >= 0, got {self.offset}'
            raise ValueError(message)
        if self.volume < 0.0:
            message = f'volume must be >= 0, got {self.volume}'
            raise ValueError(message)

    def frame_count(self, *, sample_rate: int) -> int:
        """How many frames ``render`` gives, without rendering.

        The oscillator makes ``sample_count(duration)`` frames, and every later stage
        (distortion, filters, tremolo, envelope, volume) keeps the count.

        Returns:
            The frame count.
        """
        return sample_count(self.duration, sample_rate)

    def render(self, *, sample_rate: int) -> FloatArray:
        """Render this tone (without its offset).

        Returns:
            The tone's samples.

        """
        if self.waveform is Waveform.NOISE or self.end_frequency is None:
            frequency: float | FloatArray = self.start_frequency
        else:
            frequency = frequency_curve(
                self.start_frequency,
                self.end_frequency,
                self.duration,
                easing=self.easing,
                sample_rate=sample_rate,
            )
        samples, _ = oscillator(
            self.waveform,
            frequency,
            self.duration,
            sample_rate=sample_rate,
            random_source=np.random.default_rng(RECIPE_NOISE_SEED),
        )
        if self.distortion is not None:
            samples = distort(samples, self.distortion)
        if self.low_pass_cutoff is not None:
            samples = low_pass(samples, self.low_pass_cutoff, sample_rate=sample_rate)
        if self.high_pass_cutoff is not None:
            samples = high_pass(samples, self.high_pass_cutoff, sample_rate=sample_rate)
        if self.tremolo is not None:
            samples, _ = tremolo(
                samples,
                self.tremolo.rate_hz,
                self.tremolo.depth,
                sample_rate=sample_rate,
            )
        return apply_envelope(samples, self.envelope, sample_rate=sample_rate) * self.volume


@dataclasses.dataclass(frozen=True)
class Effect:
    """A named sound made of tones."""

    name: str
    tones: tuple[Tone, ...]
    volume: float = 0.5
    peak: float = 0.9
    # False mixes the tones straight: their sum, not scaled (peak is then unused)
    normalize: bool = True

    def frame_count(self, *, sample_rate: int) -> int:
        """How many frames ``render`` gives at a rate, without rendering (cache ``none``'s length).

        ``mix`` sizes its result with ``mixed_frame_count`` from each tone's start
        (``sample_count(offset)``) and length (``Tone.frame_count``); normalizing keeps it.

        Returns:
            The frame count.
        """
        return mixed_frame_count(
            (sample_count(tone.offset, sample_rate), tone.frame_count(sample_rate=sample_rate))
            for tone in self.tones
        )

    def render(self, *, sample_rate: int | None = None) -> FloatArray:
        """Mix every tone at its offset and normalize to peak.

        Returns:
            The sound's samples.

        """
        rate = mixer_sample_rate() if sample_rate is None else sample_rate
        layers = [(tone.render(sample_rate=rate), tone.offset) for tone in self.tones]
        mixed = mix(*layers, sample_rate=rate)
        return normalize(mixed, peak=self.peak) if self.normalize else mixed

    def to_sound(self) -> pygame.mixer.Sound:
        """Render at the mixer's rate and wrap as a pygame Sound.

        Returns:
            The sound.

        """
        return to_sound(self.render(), volume=self.volume)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to plain data (TOML/JSON friendly).

        Returns:
            The recipe as a dict (without its name, which is the key it is stored under).

        """
        data: dict[str, Any] = {
            'volume': self.volume,
            'peak': self.peak,
            'tones': [_tone_to_dict(tone) for tone in self.tones],
        }
        # Written only when false, so every normalizing effect's data, and so its identity key
        # and its disk cache file, stay as they were
        if not self.normalize:
            data['normalize'] = False
        return data

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> Effect:
        """Build a recipe from to_dict() output.

        Returns:
            The recipe.

        Raises:
            EffectError: Naming the recipe and field that is invalid.

        """
        tones: list[Tone] = []
        for index, tone_data in enumerate(data.get('tones', [])):
            tones.append(_tone_from_dict(name=name, index=index, data=tone_data))
        try:
            return cls(
                name=name,
                tones=tuple(tones),
                volume=float(data.get('volume', 0.5)),
                peak=float(data.get('peak', 0.9)),
                normalize=_boolean(name=name, field='normalize', value=data.get('normalize', True)),
            )
        except (TypeError, ValueError) as error:
            message = f'{name}: {error}'
            raise EffectError(message) from error


def _boolean(*, name: str, field: str, value: object) -> bool:
    """Read a true/false field, refusing anything else (TOML has booleans; 1 is not one).

    Returns:
        The value.

    Raises:
        EffectError: Naming the effect and field.
    """
    if not isinstance(value, bool):
        message = f'{name}: {field} must be true or false, got {value!r}'
        raise EffectError(message)
    return value


def _tone_to_dict(tone: Tone) -> dict[str, Any]:
    data: dict[str, Any] = {
        'waveform': tone.waveform.value,
        'start_frequency': tone.start_frequency,
        'duration': tone.duration,
        'envelope': dataclasses.asdict(tone.envelope),
        'easing': tone.easing,
        'volume': tone.volume,
        'offset': tone.offset,
    }
    for optional in ('end_frequency', 'low_pass_cutoff', 'high_pass_cutoff', 'distortion'):
        value = getattr(tone, optional)
        if value is not None:
            data[optional] = value
    if tone.tremolo is not None:
        data['tremolo'] = dataclasses.asdict(tone.tremolo)
    return data


def _tone_from_dict(*, name: str, index: int, data: dict[str, Any]) -> Tone:
    location = f'{name}.tones[{index}]'
    try:
        waveform = Waveform(data['waveform'])
    except (KeyError, ValueError) as error:
        message = f'{location}.waveform: {data.get("waveform")!r} is not a waveform'
        raise EffectError(message) from error
    try:
        envelope = Envelope(**data['envelope'])
    except (KeyError, TypeError) as error:
        message = f'{location}.envelope: {error}'
        raise EffectError(message) from error
    tremolo_data = data.get('tremolo')
    try:
        return Tone(
            waveform=waveform,
            start_frequency=float(data['start_frequency']),
            duration=float(data['duration']),
            envelope=envelope,
            end_frequency=data.get('end_frequency'),
            easing=data.get('easing', 'linear'),
            volume=float(data.get('volume', 1.0)),
            offset=float(data.get('offset', 0.0)),
            low_pass_cutoff=data.get('low_pass_cutoff'),
            high_pass_cutoff=data.get('high_pass_cutoff'),
            distortion=data.get('distortion'),
            tremolo=Tremolo(**tremolo_data) if tremolo_data is not None else None,
        )
    except (KeyError, TypeError, ValueError) as error:
        message = f'{location}: {error}'
        raise EffectError(message) from error


def load_effects(path: Path) -> dict[str, Effect]:
    """Load every [recipes.<name>] table from a TOML file.

    Returns:
        Recipes by name.

    """
    with path.open('rb') as recipe_file:
        document = tomllib.load(recipe_file)
    return {
        name: Effect.from_dict(name, data) for name, data in document.get('recipes', {}).items()
    }
