"""Papyrus Edition enemy sprites using TOML animation system."""

from __future__ import annotations

from typing import Any, Self, override

import pygame

from brave_adventurer_papyrus.constants import (
    GRAVITY,
    GROUND_Y,
    LAYER_ENEMIES,
    MAX_FALL_SPEED,
    PAPYRUS_COBRA_HEIGHT,
    PAPYRUS_SCARAB_HEIGHT,
    PAPYRUS_SCORPION_HEIGHT,
    SPRITES_DIR,
)
from brave_adventurer_papyrus.sprite_utils import (
    prepare_papyrus_sprite,
    refresh_drawn_image,
)
from glitchygames.sprites import AnimatedSprite
from glitchygames.world import CoordinateSpace


class PapyrusCobra(AnimatedSprite):
    """Cobra enemy using TOML sprite animations.

    Stationary cobra that bobs gently and periodically strikes. A world sprite: the
    engine places it from the camera.
    """

    COORDINATE_SPACE = CoordinateSpace.WORLD

    def __init__(
        self,
        world_x: float,
        groups: pygame.sprite.LayeredDirty[Any],
    ) -> None:
        """Initialize the cobra.

        Args:
            world_x: X position in world coordinates.
            groups: The sprite group to add this sprite to.

        """
        self._layer = LAYER_ENEMIES

        super().__init__(
            filename=str(SPRITES_DIR / 'cobra.toml'),
            groups=groups,
        )
        prepare_papyrus_sprite(self)

        self.world_x: float = world_x
        # Cobra TOML sprite has 2 empty rows at the bottom (4px at 2x scale).
        # Offset Y so the visible coiled body sits on the ground.
        cobra_visual_padding = 4
        self.world_y: float = GROUND_Y - PAPYRUS_COBRA_HEIGHT + cobra_visual_padding

        self.play('idle')
        self.is_looping = True
        self.dirty = 2

        # State machine auto-loaded from cobra.toml [[transition]] sections.
        # Timer-based idle → strike → idle cycle defined entirely in TOML.
        assert self.state_machine is not None, 'cobra.toml declares the [[transition]]s'
        self.state_machine.set_state('idle')

    def dt_tick(self: Self, dt: float) -> None:
        """Advance state machine and animation frames.

        Args:
            dt: Delta time in seconds since the last frame.

        """
        self.dt = dt

        # State machine handles idle/strike transitions via timer
        assert self.state_machine is not None, 'cobra.toml declares the [[transition]]s'
        self.state_machine.evaluate({}, dt)

        AnimatedSprite.update(self, dt)
        refresh_drawn_image(self)

    @override
    def update(self: Self, dt: float = 0.016) -> None:
        """No-op. Animation is advanced in dt_tick() instead."""


class PapyrusScarab(AnimatedSprite):
    """Scarab beetle enemy using TOML sprite animations.

    Rolls across the ground at a constant speed. A world sprite: the engine places it
    from the camera.
    """

    COORDINATE_SPACE = CoordinateSpace.WORLD

    def __init__(
        self,
        world_x: float,
        groups: pygame.sprite.LayeredDirty[Any],
        speed: float = -120.0,
    ) -> None:
        """Initialize the scarab.

        Args:
            world_x: Starting X position in world coordinates.
            groups: The sprite group to add this sprite to.
            speed: Horizontal speed in pixels/second (negative = moving left).

        """
        self._layer = LAYER_ENEMIES

        super().__init__(
            filename=str(SPRITES_DIR / 'scarab.toml'),
            groups=groups,
        )
        prepare_papyrus_sprite(self)

        self.world_x: float = world_x
        self.world_y: float = GROUND_Y - PAPYRUS_SCARAB_HEIGHT

        self.roll_speed: float = speed
        self.velocity_y: float = 0.0
        self.on_ground: bool = True

        self.play('roll')
        self.is_looping = True
        self.dirty = 2

    def dt_tick(self: Self, dt: float) -> None:
        """Move the scarab with gravity and advance the roll animation.

        Args:
            dt: Delta time in seconds since the last frame.

        """
        self.dt = dt

        # Gravity
        self.velocity_y = min(self.velocity_y + GRAVITY * dt, MAX_FALL_SPEED)
        self.world_y += self.velocity_y * dt

        # Horizontal movement
        self.world_x += self.roll_speed * dt
        AnimatedSprite.update(self, dt)
        refresh_drawn_image(self)

    @override
    def update(self: Self, dt: float = 0.016) -> None:
        """No-op. Animation is advanced in dt_tick() instead."""


class PapyrusScorpion(AnimatedSprite):
    """Scorpion enemy using TOML sprite animations.

    Patrols back and forth within a range, flipping direction at boundaries. A world
    sprite: the engine places it from the camera.
    """

    COORDINATE_SPACE = CoordinateSpace.WORLD

    DEFAULT_PATROL_SPEED = 60.0

    def __init__(
        self,
        world_x: float,
        groups: pygame.sprite.LayeredDirty[Any],
        patrol_range: float = 200.0,
    ) -> None:
        """Initialize the scorpion.

        Args:
            world_x: Starting X position in world coordinates (also patrol origin).
            groups: The sprite group to add this sprite to.
            patrol_range: How far the scorpion patrols from its origin.

        """
        self._layer = LAYER_ENEMIES

        super().__init__(
            filename=str(SPRITES_DIR / 'scorpion.toml'),
            groups=groups,
        )
        prepare_papyrus_sprite(self)

        self.world_x: float = world_x
        self.world_y: float = GROUND_Y - PAPYRUS_SCORPION_HEIGHT

        self.origin_x: float = world_x
        self.patrol_range: float = patrol_range
        self.patrol_speed: float = self.DEFAULT_PATROL_SPEED
        self.facing_right: bool = True

        self.play('walk')
        self.is_looping = True
        self.dirty = 2

    def dt_tick(self: Self, dt: float) -> None:
        """Move along patrol path and advance the walk animation.

        Args:
            dt: Delta time in seconds since the last frame.

        """
        self.dt = dt

        direction = 1.0 if self.facing_right else -1.0
        self.world_x += self.patrol_speed * direction * dt

        # Reverse at patrol boundaries
        if self.world_x > self.origin_x + self.patrol_range:
            self.world_x = self.origin_x + self.patrol_range
            self.facing_right = False
        elif self.world_x < self.origin_x:
            self.world_x = self.origin_x
            self.facing_right = True

        AnimatedSprite.update(self, dt)
        refresh_drawn_image(self)

        # Flip image when facing left, and mirror the hitbox with it
        self.hitbox_flip_x = not self.facing_right
        if not self.facing_right:
            self.image = pygame.transform.flip(self.image, flip_x=True, flip_y=False)

    @override
    def update(self: Self, dt: float = 0.016) -> None:
        """No-op. Animation is advanced in dt_tick() instead."""
