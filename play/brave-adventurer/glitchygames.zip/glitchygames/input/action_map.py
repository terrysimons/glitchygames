"""Input action mapping with optional state tracking.

Maps physical inputs (keyboard keys, controller buttons, analog axes)
to named game actions. Supports two complementary usage modes:

- **Event-driven lookup**: ``get_action(event)`` returns the action name
  for one-shot actions like jump or pause.
- **Frame-based state**: ``is_held(action)``, ``just_pressed(action)``
  for continuous actions like movement.

Usage:
    actions = ActionMap()
    actions.bind('jump', keyboard=pygame.K_SPACE,
                 controller_button=pygame.CONTROLLER_BUTTON_A)
    actions.bind('move_right', keyboard=pygame.K_RIGHT,
                 controller_axis=(pygame.CONTROLLER_AXIS_LEFTX, 0.3))
    # A physical key position: the same place on every keyboard layout
    actions.bind('move_left', scancode=pygame.KSCAN_A)

    # In event handlers:
    actions.handle_event(event)
    action = actions.get_action(event)

    # In dt_tick: read first, then begin_frame() (the frame's events come after dt_tick)
    if actions.just_pressed('jump'):
        player.jump()
    if actions.is_held('move_right'):
        player.move_right()
    actions.begin_frame()

Keyboard bindings come in two kinds. ``keyboard=`` binds a key code (``pygame.K_*``), which
the keyboard layout decides: right for mnemonic keys (P for pause, I for inventory), wrong for
positional controls, which land elsewhere on another layout (WASD is ZQSD's place on AZERTY).
``scancode=`` binds a physical key position (``pygame.KSCAN_*``, the event's ``scancode``),
which is the same on every layout: use it for movement and other positional controls.
Recordings hold every key event with its scancode, so a scancode binding also replays exactly
on any layout.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

import pygame

from glitchygames.input.input_devices import InputMode

if TYPE_CHECKING:
    from collections.abc import Mapping

    from glitchygames.events.base import HashableEvent

log: logging.Logger = logging.getLogger('game.input.action_map')

# SDL2 axis range for normalization
_SDL_AXIS_MAX: float = 32767.0

# Default deadzone for analog sticks (industry standard)
DEFAULT_DEADZONE: float = 0.15

# The to_dict key holding the map's settings, not bindings (BUGS.md #184.6, #184.7): a dict, never
# a list, so a loader that predates it skips it as it skips any non-list value; an action cannot
# be named this
SETTINGS_KEY: str = '__settings__'
# The settings it holds: the input mode the map was made in and its stick deadzone
INPUT_MODE_SETTING: str = 'input_mode'
DEADZONE_SETTING: str = 'deadzone'


def normalized_axis_value(*, event_type: int, value: float) -> float:
    """Return an axis motion's position as a float from -1.0 to 1.0.

    Controller axis values are raw SDL ints (-32767 to 32767).
    Joystick axis values are already normalized floats (-1.0 to 1.0).

    Args:
        event_type: CONTROLLERAXISMOTION or JOYAXISMOTION.
        value: The event's value.

    Returns:
        The normalized position (before any deadzone).

    """
    if event_type == pygame.CONTROLLERAXISMOTION:
        return float(value) / _SDL_AXIS_MAX
    return float(value)


@dataclass(frozen=True)
class Binding:
    """A single physical input mapped to a named action.

    Attributes:
        action: The game action name (e.g. 'jump', 'move_right').
        event_type: The pygame event type (KEYDOWN, CONTROLLERBUTTONDOWN, etc.).
        input_code: The key or button constant (a scancode when ``is_scancode``).
        instance_id: Controller instance filter (None accepts any controller).
        is_scancode: True for a physical key position (``bind(scancode=...)``), matched
            against the event's ``scancode``; False for a key code, matched against ``key``.
        controller_layer_only: True for a ``bind(controller_layer_button=...)`` binding (the
            controller layer only, in every input mode; saved with its flag so it loads so).

    """

    action: str
    event_type: int
    input_code: int
    instance_id: int | None = None
    is_scancode: bool = False
    controller_layer_only: bool = False


@dataclass(frozen=True)
class AxisBinding:
    """An analog axis mapped to a named action via threshold.

    The threshold sign encodes direction:
    - Positive threshold (e.g. +0.3): fires when axis >= threshold
    - Negative threshold (e.g. -0.3): fires when axis <= threshold

    Attributes:
        action: The game action name.
        axis: The pygame axis constant (e.g. CONTROLLER_AXIS_LEFTX).
        threshold: The activation threshold (sign encodes direction).
        instance_id: Controller instance filter (None accepts any controller).

    """

    action: str
    axis: int
    threshold: float
    instance_id: int | None = None


class ActionMap:
    """Maps physical inputs to named game actions.

    Provides both stateless event-to-action lookup and optional
    frame-based state tracking for held/pressed/released queries.

    Args:
        deadzone: Analog stick deadzone. Values below this are
            treated as zero. Default 0.15.

    """

    def __init__(
        self,
        deadzone: float = DEFAULT_DEADZONE,
        input_mode: str = InputMode.AUTO,
    ) -> None:
        """Initialize the action map.

        Args:
            deadzone: Analog stick deadzone (default 0.15).
            input_mode: Which gamepad event family to bind (the engine's ``--input-mode``,
                glitchygames/input/input_devices.py).
                'joystick' binds JOYBUTTONDOWN/UP and JOYAXISMOTION.
                'controller' binds CONTROLLERBUTTONDOWN/UP and
                CONTROLLERAXISMOTION.
                'auto' (the default) binds both: the engine dispatches a mapped pad's
                controller events and any other device's joystick events, each press once.
                Any other value is refused (InputMode raises ValueError).

        """
        self._deadzone = deadzone
        self._input_mode = InputMode(input_mode)
        # The event families a controller_button / controller_axis binding answers to
        self._button_event_types: tuple[tuple[int, int], ...] = ()
        self._axis_event_types: frozenset[int] = frozenset()
        if self._input_mode is not InputMode.JOYSTICK:
            self._button_event_types += ((pygame.CONTROLLERBUTTONDOWN, pygame.CONTROLLERBUTTONUP),)
            self._axis_event_types |= {pygame.CONTROLLERAXISMOTION}
        if self._input_mode is not InputMode.CONTROLLER:
            self._button_event_types += ((pygame.JOYBUTTONDOWN, pygame.JOYBUTTONUP),)
            self._axis_event_types |= {pygame.JOYAXISMOTION}

        # Digital bindings: (event_type, input_code) → list of Binding
        self._bindings: dict[tuple[int, int], list[Binding]] = {}
        # Key position bindings: (KEYDOWN or KEYUP, scancode) → list of Binding, apart from
        # the key codes (a scancode and a key code can have the same number)
        self._scancode_bindings: dict[tuple[int, int], list[Binding]] = {}

        # Analog axis bindings (small list, iterated on axis events)
        self._axis_bindings: list[AxisBinding] = []

        # Frame-based state tracking
        self._held: set[str] = set()
        self._just_pressed: set[str] = set()
        self._just_released: set[str] = set()
        self._axis_values: dict[str, float] = {}

    @property
    def input_mode(self) -> InputMode:
        """Which gamepad event families the map binds (the constructor's ``input_mode``)."""
        return self._input_mode

    @property
    def deadzone(self) -> float:
        """The analog stick deadzone (the constructor's ``deadzone``)."""
        return self._deadzone

    @classmethod
    def from_engine_options(cls, options: Mapping[str, Any]) -> ActionMap:
        """Make an empty map in the engine's input settings, as every game's map should be.

        Reads ``input_mode`` (``--input-mode``, default 'auto') and ``axis_deadzone``
        (``--axis-deadzone``, default ``DEFAULT_DEADZONE``), so a game that builds its map here
        follows both, and any input setting added later.

        Args:
            options: The engine's options (``GameEngine.OPTIONS``, a scene's ``options``).

        Returns:
            The map, with no bindings.

        """
        return cls(
            deadzone=options.get('axis_deadzone', DEFAULT_DEADZONE),
            input_mode=options.get('input_mode', InputMode.AUTO),
        )

    # --- Binding API ---

    def bind(  # ruff: ignore[too-many-arguments]
        self,
        action: str,
        *,
        keyboard: int | None = None,
        scancode: int | None = None,
        controller_button: int | None = None,
        controller_axis: tuple[int, float] | None = None,
        joystick_button: int | None = None,
        controller_layer_button: int | None = None,
        instance_id: int | None = None,
    ) -> None:
        """Bind physical inputs to a named action.

        Multiple inputs can be bound to the same action by calling
        bind() multiple times or by passing multiple keyword arguments.

        Args:
            action: The game action name.
            keyboard: A pygame key constant (e.g. pygame.K_SPACE): the key the layout
                calls that, wherever it is.
            scancode: A physical key position (e.g. pygame.KSCAN_A): the key in that place
                on every layout, whatever the layout calls it.
            controller_button: A gamepad button constant. Automatically
                uses the event types of the input_mode (both families in 'auto').
            controller_axis: Tuple of (axis_constant, threshold).
                Threshold sign encodes direction.
            joystick_button: A raw joystick button index. Always binds
                JOYBUTTONDOWN/UP regardless of input_mode. Use for
                non-standard buttons (e.g. DualSense mic mute) on the raw
                joystick API. In 'auto' mode the engine dispatches a mapped
                pad's controller events only, so bind the button's controller-layer
                number too, with controller_layer_button (as Brave Adventurer's mic does:
                15 there, 16 raw).
            controller_layer_button: A gamepad button constant bound on the controller layer
                only (CONTROLLERBUTTONDOWN/UP), in every input_mode: the counterpart of
                joystick_button, for a button whose raw index differs from its
                controller-layer number. controller_button would bind the raw button with the
                same number too in 'joystick' and 'auto' mode (BUGS.md #178.26). Never fires
                in 'joystick' mode, which dispatches no controller-layer events.
            instance_id: Controller instance filter for button/axis
                bindings. None accepts any controller.

        Raises:
            ValueError: If the action is named ``SETTINGS_KEY`` (a saved map's settings).

        """
        if action == SETTINGS_KEY:
            message = f"{SETTINGS_KEY!r} names a saved map's settings, not an action"
            raise ValueError(message)
        if keyboard is not None:
            self._add_binding(
                Binding(
                    action=action,
                    event_type=pygame.KEYDOWN,
                    input_code=keyboard,
                )
            )
            self._add_binding(
                Binding(
                    action=action,
                    event_type=pygame.KEYUP,
                    input_code=keyboard,
                )
            )

        if scancode is not None:
            for event_type in (pygame.KEYDOWN, pygame.KEYUP):
                self._add_binding(
                    Binding(
                        action=action,
                        event_type=event_type,
                        input_code=scancode,
                        is_scancode=True,
                    )
                )

        if controller_axis is not None:
            axis_constant, threshold = controller_axis
            axis_binding = AxisBinding(
                action=action,
                axis=axis_constant,
                threshold=threshold,
                instance_id=instance_id,
            )
            self._axis_bindings.append(axis_binding)

        # Gamepad buttons: each keyword's button, the (down, up) event types it binds, and
        # whether it is a controller-layer-only binding
        button_bindings: list[tuple[int | None, tuple[tuple[int, int], ...], bool]] = [
            # The input mode's families: 'joystick' → JOYBUTTONDOWN/UP, 'controller' →
            # CONTROLLERBUTTONDOWN/UP (SDL Game Controller API), 'auto' → both (each device
            # dispatches one of them)
            (controller_button, self._button_event_types, False),
            # The controller layer only, whatever the input mode's families (BUGS.md #178.26)
            (
                controller_layer_button,
                ((pygame.CONTROLLERBUTTONDOWN, pygame.CONTROLLERBUTTONUP),),
                True,
            ),
            # The raw joystick layer only, whatever the input mode: for non-standard buttons
            # (mic mute, etc.) that only arrive through the raw joystick API
            (joystick_button, ((pygame.JOYBUTTONDOWN, pygame.JOYBUTTONUP),), False),
        ]
        for button, event_type_pairs, controller_layer_only in button_bindings:
            if button is None:
                continue
            for event_type_pair in event_type_pairs:
                for event_type in event_type_pair:
                    self._add_binding(
                        Binding(
                            action=action,
                            event_type=event_type,
                            input_code=button,
                            instance_id=instance_id,
                            controller_layer_only=controller_layer_only,
                        )
                    )

    def unbind(self, action: str) -> None:
        """Remove all bindings for an action.

        Args:
            action: The action name to unbind.

        """
        # Remove digital bindings (key codes and buttons, then key positions)
        for table in (self._bindings, self._scancode_bindings):
            keys_to_remove = [
                key
                for key, bindings in table.items()
                if all(binding.action == action for binding in bindings)
            ]
            for key in keys_to_remove:
                del table[key]
            for key in table:
                table[key] = [binding for binding in table[key] if binding.action != action]

        # Remove axis bindings
        self._axis_bindings = [
            axis_binding for axis_binding in self._axis_bindings if axis_binding.action != action
        ]

        # Clear state
        self._held.discard(action)
        self._just_pressed.discard(action)
        self._just_released.discard(action)
        self._axis_values.pop(action, None)

    def clear(self) -> None:
        """Remove all bindings and reset all state."""
        self._bindings.clear()
        self._scancode_bindings.clear()
        self._axis_bindings.clear()
        self._held.clear()
        self._just_pressed.clear()
        self._just_released.clear()
        self._axis_values.clear()

    # --- Event-driven lookup ---

    def get_action(self, event: HashableEvent) -> str | None:
        """Get the action name for a raw input event.

        Pure lookup — does not modify state. Returns the first
        matching action, or None if the event has no binding.

        Args:
            event: A HashableEvent from the event system.

        Returns:
            The action name, or None.

        """
        actions = self.get_actions(event)
        return actions[0] if actions else None

    def get_actions(self, event: HashableEvent) -> list[str]:
        """Get all action names matching a raw input event.

        Args:
            event: A HashableEvent from the event system.

        Returns:
            List of matching action names (may be empty).

        """
        return [
            binding.action
            for binding in self._bindings_for_event(event)
            if self._instance_matches(binding.instance_id, event)
        ]

    # --- State tracking ---

    def handle_event(self, event: HashableEvent) -> None:
        """Feed a raw event into the state tracker.

        Call this in every on_*_event handler to keep held/pressed/
        released state accurate.

        Args:
            event: A HashableEvent from the event system.

        """
        # Handle digital inputs (keyboard + controller/joystick buttons)
        for binding in self._bindings_for_event(event):
            if not self._instance_matches(binding.instance_id, event):
                continue

            is_down = event.type in {
                pygame.KEYDOWN,
                pygame.CONTROLLERBUTTONDOWN,
                pygame.JOYBUTTONDOWN,
            }
            if is_down:
                if binding.action not in self._held:
                    self._just_pressed.add(binding.action)
                self._held.add(binding.action)
            else:
                if binding.action in self._held:
                    self._just_released.add(binding.action)
                self._held.discard(binding.action)

        # Handle analog axis inputs (only the input mode's event families)
        if event.type in self._axis_event_types:
            self._handle_axis_event(event)

    def begin_frame(self) -> None:
        """Forget the presses and releases seen so far: start collecting the next frame's.

        Call it once per frame in dt_tick(), after reading just_pressed() and
        just_released(). The scene manager runs dt_tick() before it processes the frame's
        events, so the presses dt_tick() can see arrived in the previous frame's event phase;
        calling begin_frame() before reading them clears them first, and just_pressed() is
        then never True in dt_tick() (BUGS.md #209 item 11). is_held() and axis_value() are
        not reset.
        """
        self._just_pressed.clear()
        self._just_released.clear()

    def is_held(self, action: str) -> bool:
        """Check if an action is currently held down.

        Args:
            action: The action name.

        Returns:
            True if any binding for this action is active.

        """
        return action in self._held

    def just_pressed(self, action: str) -> bool:
        """Check if an action was pressed this frame.

        Only True for one frame after the press event. Requires
        begin_frame() to be called each frame.

        Args:
            action: The action name.

        Returns:
            True if the action was pressed since the last begin_frame().

        """
        return action in self._just_pressed

    def just_released(self, action: str) -> bool:
        """Check if an action was released this frame.

        Only True for one frame after the release event.

        Args:
            action: The action name.

        Returns:
            True if the action was released since the last begin_frame().

        """
        return action in self._just_released

    def axis_value(self, action: str) -> float:
        """Get the current analog axis value for an action.

        Returns the deadzone-filtered normalized value (-1.0 to 1.0).
        Returns 0.0 if the action has no axis binding or no data.

        Args:
            action: The action name.

        Returns:
            The analog value after deadzone filtering.

        """
        return self._axis_values.get(action, 0.0)

    # --- Persistence ---

    def to_dict(self) -> dict[str, Any]:
        """Serialize bindings to a dict for SaveManager.

        Only serializes bindings, not runtime state. The dict is
        suitable for JSON or TOML serialization.

        Returns:
            A dict mapping action names to lists of binding dicts, and ``SETTINGS_KEY`` to the
            map's settings: its input mode and deadzone (BUGS.md #184.6, #184.7).

        """
        result: dict[str, Any] = {
            SETTINGS_KEY: {
                INPUT_MODE_SETTING: self._input_mode.value,
                DEADZONE_SETTING: self._deadzone,
            }
        }

        # Digital bindings (only DOWN events, UP is derived); a key position is stored as
        # 'scancode', a key code or button as 'code'. A joystick button (JOYBUTTONDOWN: a
        # controller_button bound in joystick mode, or a joystick_button) is kept too, or a
        # save would drop every gamepad button of a joystick-mode map
        for bindings in [*self._bindings.values(), *self._scancode_bindings.values()]:
            for binding in bindings:
                if binding.event_type not in {
                    pygame.KEYDOWN,
                    pygame.CONTROLLERBUTTONDOWN,
                    pygame.JOYBUTTONDOWN,
                }:
                    continue
                if binding.action not in result:
                    result[binding.action] = []
                entry: dict[str, Any] = {
                    'type': pygame.event.event_name(binding.event_type),
                    ('scancode' if binding.is_scancode else 'code'): binding.input_code,
                }
                if binding.instance_id is not None:
                    entry['instance_id'] = binding.instance_id
                if binding.controller_layer_only:
                    entry['controller_layer_only'] = True
                result[binding.action].append(entry)

        # Axis bindings
        for axis_binding in self._axis_bindings:
            if axis_binding.action not in result:
                result[axis_binding.action] = []
            entry = {
                'type': 'AxisMotion',
                'axis': axis_binding.axis,
                'threshold': axis_binding.threshold,
            }
            if axis_binding.instance_id is not None:
                entry['instance_id'] = axis_binding.instance_id
            result[axis_binding.action].append(entry)

        return result

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        defaults: ActionMap | None = None,
        input_mode: str | None = None,
        deadzone: float | None = None,
    ) -> ActionMap:
        """Deserialize bindings from a dict.

        If defaults is provided, actions not in data use the default
        bindings. Actions in data override defaults completely.

        The two settings (``SETTINGS_KEY``) come from different places first (BUGS.md #184.6,
        #184.7), since the input mode is how the game runs now and the deadzone is the
        player's:

        - input mode: ``input_mode`` when given (a game passes the mode it runs in), else the
          defaults', else the saved one, else 'auto';
        - deadzone: ``deadzone`` when given, else the saved one (a player's setting), else the
          defaults', else ``DEFAULT_DEADZONE``.

        A saved mode this engine does not know, or a saved deadzone that is not a number of 0
        or more, is logged and skipped.

        Args:
            data: Binding data from SaveManager/serializer.
            defaults: Optional ActionMap with default bindings.
            input_mode: The input mode to build the map in, or None (above).
            deadzone: The deadzone to build the map with, or None (above).

        Returns:
            A new ActionMap with the loaded bindings.

        """
        settings = data.get(SETTINGS_KEY)
        saved: dict[str, Any] = (
            cast('dict[str, Any]', settings) if isinstance(settings, dict) else {}
        )
        if input_mode is None:
            input_mode = (
                defaults.input_mode
                if defaults is not None
                else cls._saved_input_mode(saved=saved.get(INPUT_MODE_SETTING))
            )
        if deadzone is None:
            saved_deadzone = cls._saved_deadzone(saved=saved.get(DEADZONE_SETTING))
            if saved_deadzone is not None:
                deadzone = saved_deadzone
            elif defaults is not None:
                deadzone = defaults.deadzone
            else:
                deadzone = DEFAULT_DEADZONE
        action_map = cls(deadzone=deadzone, input_mode=input_mode)
        loaded_actions: set[str] = set()

        for action_name, binding_list in data.items():
            if action_name == SETTINGS_KEY or not isinstance(binding_list, list):
                continue
            loaded_actions.add(action_name)
            for entry in cast('list[Any]', binding_list):
                if isinstance(entry, dict):
                    cls._load_binding_entry(
                        action_map,
                        action_name,
                        cast('dict[str, Any]', entry),
                    )

        # Merge defaults for actions not in the loaded data
        if defaults is not None:
            cls._merge_defaults(action_map, defaults, loaded_actions)

        return action_map

    @staticmethod
    def _saved_input_mode(*, saved: object) -> InputMode:
        """Return the input mode a saved map names, or 'auto' for none or an unknown one.

        Returns:
            The mode.

        """
        if saved is None:
            return InputMode.AUTO
        try:
            return InputMode(saved)
        except ValueError:
            log.warning('The saved action map names an unknown input mode %r; using auto', saved)
            return InputMode.AUTO

    @staticmethod
    def _saved_deadzone(*, saved: object) -> float | None:
        """Return the deadzone a saved map names, or None for none or an unusable one.

        Returns:
            The deadzone, or None.

        """
        if saved is None:
            return None
        # bool is an int: True is no deadzone
        if isinstance(saved, bool) or not isinstance(saved, int | float) or saved < 0:
            log.warning('The saved action map names an unusable deadzone %r; skipping it', saved)
            return None
        return float(saved)

    @staticmethod
    def _load_binding_entry(
        action_map: ActionMap,
        action_name: str,
        entry: dict[str, Any],
    ) -> None:
        """Load a single binding entry from serialized data.

        Args:
            action_map: The ActionMap to add the binding to.
            action_name: The action this binding belongs to.
            entry: A serialized binding dict.

        """
        event_name_to_type = {
            'KeyDown': pygame.KEYDOWN,
            'ControllerButtonDown': pygame.CONTROLLERBUTTONDOWN,
            'JoyButtonDown': pygame.JOYBUTTONDOWN,
        }

        binding_type = entry.get('type', '')
        instance_id = entry.get('instance_id')

        if binding_type == 'AxisMotion':
            axis = entry.get('axis')
            threshold = entry.get('threshold')
            if axis is not None and threshold is not None:
                action_map.bind(
                    action_name,
                    controller_axis=(int(axis), float(threshold)),
                    instance_id=instance_id,
                )
            return

        event_type = event_name_to_type.get(binding_type)
        scancode = entry.get('scancode')
        if event_type == pygame.KEYDOWN and scancode is not None:
            action_map.bind(action_name, scancode=int(scancode))
            return
        code = entry.get('code')
        if event_type is None or code is None:
            return

        if event_type == pygame.KEYDOWN:
            action_map.bind(action_name, keyboard=int(code))
        elif (
            event_type == pygame.CONTROLLERBUTTONDOWN and entry.get('controller_layer_only') is True
        ):
            action_map.bind(
                action_name,
                controller_layer_button=int(code),
                instance_id=instance_id,
            )
        elif event_type == pygame.CONTROLLERBUTTONDOWN:
            action_map.bind(
                action_name,
                controller_button=int(code),
                instance_id=instance_id,
            )
        else:
            # JOYBUTTONDOWN: restored as the raw joystick button it was, in any input mode
            action_map.bind(
                action_name,
                joystick_button=int(code),
                instance_id=instance_id,
            )

    @staticmethod
    def _merge_defaults(
        action_map: ActionMap,
        defaults: ActionMap,
        loaded_actions: set[str],
    ) -> None:
        """Merge default bindings for actions not present in loaded data.

        Args:
            action_map: The ActionMap to merge into.
            defaults: The ActionMap with default bindings.
            loaded_actions: Set of action names already loaded from data.

        """
        for bindings in [*defaults._bindings.values(), *defaults._scancode_bindings.values()]:
            for binding in bindings:
                if binding.action not in loaded_actions:
                    action_map._add_binding(binding)
        for axis_binding in defaults._axis_bindings:
            if axis_binding.action not in loaded_actions:
                action_map._axis_bindings.append(axis_binding)

    # --- Private helpers ---

    def _add_binding(self, binding: Binding) -> None:
        """Add a binding to the internal lookup table.

        Args:
            binding: The binding to add.

        """
        key = (binding.event_type, binding.input_code)
        table = self._scancode_bindings if binding.is_scancode else self._bindings
        bindings = table.setdefault(key, [])
        # Once each: in 'auto' mode a saved controller_button holds a JOYBUTTONDOWN entry too,
        # which loading binds again as a joystick_button
        if binding not in bindings:
            bindings.append(binding)

    def _bindings_for_event(self, event: HashableEvent) -> list[Binding]:
        """Return the digital bindings an event matches: by key code or button, and by position.

        Args:
            event: The event to look up.

        Returns:
            The bindings, key code and button ones first.

        """
        bindings: list[Binding] = []
        input_code = self._extract_input_code(event)
        if input_code is not None:
            bindings.extend(self._bindings.get((event.type, input_code), []))
        if self._scancode_bindings and event.type in {pygame.KEYDOWN, pygame.KEYUP}:
            # Only an int is a position: a key event made without one (a game's own post, a
            # stand-in) matches no position
            scancode = getattr(event, 'scancode', None)
            if isinstance(scancode, int):
                bindings.extend(self._scancode_bindings.get((event.type, scancode), []))
        return bindings

    def _extract_input_code(self, event: HashableEvent) -> int | None:
        """Extract the input code from a HashableEvent.

        Args:
            event: The event to extract from.

        Returns:
            The key or button code, or None for unsupported event types.

        """
        if event.type in {pygame.KEYDOWN, pygame.KEYUP}:
            return int(event.key)
        if event.type in {
            pygame.CONTROLLERBUTTONDOWN,
            pygame.CONTROLLERBUTTONUP,
            pygame.JOYBUTTONDOWN,
            pygame.JOYBUTTONUP,
        }:
            return int(event.button)
        return None

    def _instance_matches(self, binding_instance_id: int | None, event: HashableEvent) -> bool:
        """Check if a binding's instance_id filter matches an event.

        Controller events use ``instance_id``, joystick events use
        ``joy``. Both are checked.

        Args:
            binding_instance_id: The binding's filter (None = any).
            event: The event to check.

        Returns:
            True if the instance_id matches or the binding accepts any.

        """
        if binding_instance_id is None:
            return True
        # Controller events use instance_id, joystick events use joy
        event_instance_id = getattr(event, 'instance_id', None)
        if event_instance_id is None:
            event_instance_id = getattr(event, 'joy', None)
        return event_instance_id == binding_instance_id

    def _handle_axis_event(self, event: HashableEvent) -> None:
        """Process a controller axis motion event.

        Normalizes the raw SDL value, applies deadzone, and updates
        held/pressed/released state based on axis thresholds.

        Args:
            event: A CONTROLLERAXISMOTION or JOYAXISMOTION HashableEvent.

        """
        raw_value = normalized_axis_value(event_type=event.type, value=event.value)

        # Apply deadzone
        if abs(raw_value) < self._deadzone:
            raw_value = 0.0

        for axis_binding in self._axis_bindings:
            if axis_binding.axis != event.axis:
                continue
            if not self._instance_matches(axis_binding.instance_id, event):
                continue

            # Store filtered value
            self._axis_values[axis_binding.action] = raw_value

            # Digital threshold check
            was_active = axis_binding.action in self._held
            if axis_binding.threshold > 0:
                is_active = raw_value >= axis_binding.threshold
            else:
                is_active = raw_value <= axis_binding.threshold

            if is_active and not was_active:
                self._held.add(axis_binding.action)
                self._just_pressed.add(axis_binding.action)
            elif not is_active and was_active:
                self._held.discard(axis_binding.action)
                self._just_released.add(axis_binding.action)
