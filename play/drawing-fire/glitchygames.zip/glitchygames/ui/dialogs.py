#!/usr/bin/env python3
"""Dialog scene classes for GlitchyGames UI.

This module contains dialog scene classes that provide input dialogs
for various operations like saving, loading, and creating new files.
"""

from __future__ import annotations

import logging
import string
import sys
from pathlib import Path, PureWindowsPath
from typing import TYPE_CHECKING, Any, Self, override

if TYPE_CHECKING:
    from collections.abc import Callable

    from glitchygames.events.base import HashableEvent, KeyEvent, MouseButtonEvent

import pygame

from glitchygames.color import BLACK
from glitchygames.scenes import Scene
from glitchygames.ui import InputDialog
from glitchygames.user_files import installed_user_files

LOG = logging.getLogger('game.ui.dialogs')
LOG.addHandler(logging.NullHandler())

# The platforms (sys.platform values) where a ':' in a file name is refused, and why
WINDOWS_PLATFORMS = frozenset({'win32', 'cygwin'})
MACOS_PLATFORM = 'darwin'

# A letter drive is the letter and its ':'; the extended and device forms put a prefix before it
LETTER_DRIVE_LENGTH = 2
EXTENDED_DRIVE_PREFIXES = ('\\\\?\\', '\\\\.\\')

_EXAMPLES_PREFIX_HINT = "The 'examples:' prefix was removed: type the sprite's path instead."

# The Save dialog's prompt after a refused name: short enough for its one-line prompt, and true
# on every platform that refuses (macOS refuses any ':', Windows one outside the drive letter)
REFUSED_FILE_NAME_PROMPT = "':' isn't allowed in this name"


def _is_letter_drive(drive: str) -> bool:
    r"""Say whether a PureWindowsPath drive is a drive letter and nothing else.

    That is 'C:' (also the drive of 'C:a' and 'C:/a'), or the extended or device form '\\?\C:'
    or '\\.\C:', with the letter in either case. A UNC drive ('\\server\share', or
    '\\?\UNC\server\share') is not one, even when its share name ends in ':'.

    Args:
        drive: The ``drive`` of a ``PureWindowsPath``

    Returns:
        bool: True when the drive is exactly a letter drive

    """
    letter_and_colon = drive
    for extended_prefix in EXTENDED_DRIVE_PREFIXES:
        if drive.startswith(extended_prefix):
            letter_and_colon = drive[len(extended_prefix) :]
            break
    return (
        len(letter_and_colon) == LETTER_DRIVE_LENGTH
        and letter_and_colon[0] in string.ascii_letters
        and letter_and_colon[1] == ':'
    )


def _file_name_problem(filename: str, *, platform: str = sys.platform) -> str | None:
    r"""Say why a file name cannot be saved on ``platform``, or None when it can.

    Windows (win32, cygwin): a ':' is allowed only in the drive designator ('C:\a.toml',
    'C:/a.toml', the drive-relative 'C:a.toml', the extended '\\?\C:\a.toml'). Anywhere else
    NTFS reads 'name:stream' as a hidden alternate data stream, so 'examples:foo.toml' would leave
    an empty file called 'examples'.

    macOS (darwin): any ':' is refused. The POSIX layer accepts it, but Finder shows ':' as '/'
    (a leftover of Classic Mac OS, where ':' was the path separator), so the file would appear
    under a confusing name.

    Every other platform (Linux, and emscripten, the browser, where Save is a download whose name
    the browser sanitizes): ':' is a legal character and is allowed.

    Args:
        filename: The file name, already stripped of surrounding whitespace
        platform: The sys.platform value to apply the rule of; this machine's by default

    Returns:
        str | None: The message to show the user, or None when the name is acceptable

    """
    if platform in WINDOWS_PLATFORMS:
        # PureWindowsPath splits off the drive: 'C:' for 'C:\a', 'C:/a' and 'C:a', and
        # '\\?\C:' for an extended path. Any other drive (UNC, '\\?\UNC\server\share') is no
        # drive designator: it stays in the remainder, where a ':' is refused too.
        drive = PureWindowsPath(filename).drive
        remainder = filename[len(drive) :] if _is_letter_drive(drive) else filename
        if ':' not in remainder:
            return None
        return (
            "':' is only allowed after a drive letter. A ':' elsewhere would hide the data in an "
            f'NTFS alternate data stream. {_EXAMPLES_PREFIX_HINT}'
        )

    if platform == MACOS_PLATFORM and ':' in filename:
        return (
            "':' isn't allowed in a file name on macOS (Finder shows it as '/'). "
            f'{_EXAMPLES_PREFIX_HINT}'
        )

    return None


def _get_save_path(filename: str) -> Path:
    """Get the path to save to for a filename.

    Args:
        filename: The filename, used as given apart from surrounding whitespace

    Returns:
        Path: The path where the file should be saved

    """
    save_path = Path(filename.strip())
    LOG.info('Save path: %s', save_path)
    return save_path


def _get_load_path(filename: str) -> Path:
    """Get the path to load from for a filename.

    Args:
        filename: The filename, used as given apart from surrounding whitespace

    Returns:
        Path: The path the file should be loaded from

    """
    load_path = Path(filename.strip())
    LOG.info('Load path: %s', load_path)
    return load_path


class InputConfirmationDialogScene(Scene):
    """Input Confirmation Dialog Scene."""

    log = LOG
    NAME = 'InputConfirmationDialog'
    DIALOG_TEXT = 'Would you like to do a thing?'
    CONFIRMATION_TEXT = 'Confirm'
    CANCEL_TEXT = 'Cancel'
    VERSION = ''

    def __init__(
        self: Self,
        previous_scene: Scene,
        options: dict[str, Any] | None = None,
        groups: pygame.sprite.LayeredDirty[Any] | None = None,
    ) -> None:
        """Initialize the Input Confirmation Dialog Scene.

        Args:
            previous_scene (Scene): The previous scene.
            options (dict, optional): Options for the scene. Defaults to None.
            groups (pygame.sprite.LayeredDirty, optional): Sprite groups.
                   Defaults to pygame.sprite.LayeredDirty().


        """
        if groups is None:
            # Create a new LayeredDirty group specifically for the dialog
            groups = pygame.sprite.LayeredDirty()

        super().__init__(options=options, groups=groups)
        # Black behind the dialog (named: a scene that sets no background shows the test pattern)
        self.background_color = BLACK
        self.previous_scene: Any = previous_scene

        # Create dialog with its own sprite group
        dialog_width = self.screen_width // 2
        dialog_height = self.screen_height // 2

        assert self.screen is not None
        self.dialog = InputDialog(
            name=self.NAME,
            dialog_text=self.DIALOG_TEXT,  # Use this instance's DIALOG_TEXT
            confirm_text=self.CONFIRMATION_TEXT,
            cancel_text=self.CANCEL_TEXT,
            x=self.screen.get_rect().center[0] - (dialog_width // 2),
            y=self.screen.get_rect().center[1] - (dialog_height // 2),
            width=dialog_width,
            height=dialog_height,
            parent=self,
            groups=self.all_sprites,
        )
        # Set the dialog text
        # Use this instance's DIALOG_TEXT
        self.dialog.dialog_text_sprite.text_box.text = self.DIALOG_TEXT
        self.dialog.dialog_text_sprite.border_width = 0

    @override
    def setup(self: Self) -> None:
        """Set up the scene."""
        self.dialog.cancel_button.callbacks = {
            'on_left_mouse_button_up_event': self.on_cancel_event,
        }
        self.dialog.confirm_button.callbacks = {
            'on_left_mouse_button_up_event': self.on_confirm_event,
        }

        self.dialog.add(self.all_sprites)

    @override
    def cleanup(self: Self) -> None:
        """Cleanup the scene."""
        self.next_scene = None

    def dismiss(self: Self) -> None:
        """Dismiss the dialog."""
        # Set next scene before cleanup
        self.previous_scene.next_scene = None
        self.next_scene = self.previous_scene

        # Clear all sprites from our group
        self.all_sprites.empty()

        # Force the previous scene to redraw completely
        for sprite in self.previous_scene.all_sprites:
            sprite.dirty = 1

    def on_cancel_event(self: Self, event: HashableEvent, trigger: object) -> None:
        """Handle the cancel event.

        Args:
            event (pygame.event.Event): The pygame event.
            trigger (object): The trigger object.


        """
        self.log.info('Cancel: event: %s, trigger: %s', event, trigger)
        self.dismiss()

    def on_confirm_event(self: Self, event: HashableEvent, trigger: object) -> None:
        """Handle confirm events."""
        self.log.info('Confirm: event: %s, trigger: %s', event, trigger)
        # Dismiss to restore the previous scene. The save, load and new-canvas dialogs
        # override this to hand the input box's text to the canvas.
        self.dismiss()

    def on_input_box_submit_event(self: Self, control: object) -> None:
        """Handle the input box submit event.

        Args:
            control (object): The control object.


        """
        input_box_name = getattr(control, 'name', '')
        input_box_text = getattr(control, 'text', '')
        self.log.info('%s Got text input from: %s: %s', self.name, input_box_name, input_box_text)

    @override
    def on_mouse_button_up_event(self: Self, event: MouseButtonEvent) -> None:
        """Handle the mouse button up event.

        Args:
            event (MouseButtonEvent): The pygame event.


        """
        self.dialog.input_box.activate()

    @override
    def on_key_up_event(self: Self, event: KeyEvent) -> None:
        """Handle the key up event.

        Args:
            event (KeyEvent): The pygame event.


        """
        if self.dialog.input_box.is_active:
            self.dialog.on_key_up_event(event)
        elif event.key == pygame.K_TAB:
            self.dialog.input_box.activate()
        else:
            super().on_key_up_event(event)

    @override
    def on_key_down_event(self: Self, event: KeyEvent) -> None:
        """Handle the key down event.

        Args:
            event (KeyEvent): The pygame event.


        """
        if self.dialog.input_box.is_active:
            self.dialog.on_key_down_event(event)
        else:
            super().on_key_down_event(event)


class NewCanvasDialogScene(InputConfirmationDialogScene):
    """New Canvas Dialog Scene."""

    log = LOG
    NAME = 'New Canvas Dialog'
    DIALOG_TEXT = 'Enter canvas size (WxH):'
    CONFIRMATION_TEXT = 'Create'
    CANCEL_TEXT = 'Cancel'

    def __init__(
        self: Self,
        previous_scene: Scene,
        options: dict[str, Any] | None = None,
        groups: pygame.sprite.LayeredDirty[Any] | None = None,
    ) -> None:
        """Initialize the New Canvas Dialog Scene.

        Args:
            previous_scene (Scene): The previous scene.
            options (dict, optional): Options for the scene. Defaults to None.
            groups (pygame.sprite.LayeredDirty, optional): Sprite groups.
                   Defaults to pygame.sprite.LayeredDirty().


        """
        if groups is None:
            groups = pygame.sprite.LayeredDirty()
        super().__init__(previous_scene, options=options, groups=groups)

    @override
    def on_confirm_event(self: Self, event: HashableEvent, trigger: object) -> None:
        """Handle the confirm event.

        Args:
            event (pygame.event.Event): The pygame event.
            trigger (object): The trigger object.


        """
        self.log.info('New Canvas: event: %s, trigger: %s', event, trigger)
        # Extract the text from the input box
        dimensions = self.dialog.input_box.text
        self.log.info('New Canvas dimensions: %s', dimensions)
        self.log.info('Calling scene.on_new_file_event with dimensions: %s', dimensions)
        self.previous_scene.on_new_file_event(dimensions)
        self.log.info('Scene.on_new_file_event completed')
        self.dismiss()


class LoadDialogScene(InputConfirmationDialogScene):
    """Load Dialog Scene."""

    log = LOG
    NAME = 'Load Dialog'
    DIALOG_TEXT = 'Enter filename to load:'
    CONFIRMATION_TEXT = 'Load'
    CANCEL_TEXT = 'Cancel'
    VERSION = ''

    def __init__(
        self: Self,
        previous_scene: Scene,
        options: dict[str, Any] | None = None,
        groups: pygame.sprite.LayeredDirty[Any] | None = None,
    ) -> None:
        """Initialize the Load Dialog Scene.

        Args:
            previous_scene (Scene): The previous scene.
            options (dict, optional): Options for the scene. Defaults to None.
            groups (pygame.sprite.LayeredDirty, optional): Sprite groups.
                   Defaults to pygame.sprite.LayeredDirty().


        """
        if groups is None:
            groups = pygame.sprite.LayeredDirty()

        super().__init__(previous_scene, options=options, groups=groups)

    @override
    def on_confirm_event(self: Self, event: HashableEvent, trigger: object) -> None:
        """Handle the confirm event.

        Args:
            event (pygame.event.Event): The pygame event.
            trigger (object): The trigger object.


        """
        self.log.info('Load File: event: %s, trigger: %s', event, trigger)
        # Get the filename from the input box text
        filename = self.dialog.input_box.text
        # The name is used as given, apart from surrounding whitespace
        load_path = _get_load_path(filename)
        LOG.info('Processed load path: %s', load_path)
        # Pass the path as string to maintain compatibility
        self.previous_scene.canvas.on_load_file_event(str(load_path))
        self.dismiss()


class SaveDialogScene(InputConfirmationDialogScene):
    """Save Dialog Scene."""

    log = LOG
    NAME = 'Save Dialog'
    DIALOG_TEXT = 'Enter filename to save:'
    CONFIRMATION_TEXT = 'Save'
    CANCEL_TEXT = 'Cancel'
    VERSION = ''

    def __init__(
        self: Self,
        previous_scene: Scene,
        options: dict[str, Any] | None = None,
        groups: pygame.sprite.LayeredDirty[Any] | None = None,
    ) -> None:
        """Initialize the Save Dialog Scene.

        Args:
            previous_scene (Scene): The previous scene.
            options (dict, optional): Options for the scene. Defaults to None.
            groups (pygame.sprite.LayeredDirty, optional): Sprite groups.
                   Defaults to pygame.sprite.LayeredDirty().


        """
        if groups is None:
            groups = pygame.sprite.LayeredDirty()

        super().__init__(previous_scene, options=options, groups=groups)

    @override
    def on_confirm_event(self: Self, event: HashableEvent, trigger: object) -> None:
        """Handle the confirm event.

        Args:
            event (pygame.event.Event): The pygame event.
            trigger (object): The trigger object.


        """
        self.log.info('Save File: event: %s, trigger: %s', event, trigger)
        # Get the filename from the input box
        filename = self.dialog.input_box.text
        # A name with a ':' this platform cannot hold is refused before anything is written
        problem = _file_name_problem(filename.strip())
        if problem is not None:
            # The dialog stays open with the name kept, so it can be corrected in place
            # (BUGS.md #231). The prompt is one short line, so it gets the short reason; the
            # full message, with its hint, goes to the editor's status text
            self.dialog.dialog_text_sprite.text_box.text = REFUSED_FILE_NAME_PROMPT
            self._show_save_error(message=problem)
            return

        # The name is used as given, apart from surrounding whitespace
        save_path = _get_save_path(filename)
        LOG.info('Processed save path: %s', save_path)
        # Pass the path as string to maintain compatibility. The canvas logs a failed save and
        # raises it for its caller to report: shown in the editor, which keeps the drawing and
        # goes on (it used to reach the engine's crash boundary and end the editor, BUGS.md #217)
        try:
            self.previous_scene.canvas.on_save_file_event(str(save_path))
        except (OSError, ValueError, KeyError) as error:
            self._show_save_error(message=f'Error saving {save_path}: {error}')
        else:
            # Where the game's files are not the player's (a browser), the saved file is handed
            # to the player (a download)
            user_files = installed_user_files()
            if user_files is not None:
                user_files.save_file(path=save_path)
        self.dismiss()

    def _show_save_error(self: Self, *, message: str) -> None:
        """Show ``message`` in the editor's debug text box, where a load error shows too.

        Args:
            message: The message.

        """
        debug_text = getattr(self.previous_scene, 'debug_text', None)
        if debug_text is not None:
            debug_text.text = message


class DeleteAnimationDialogScene(Scene):
    """Delete Animation Confirmation Dialog - requires typing exact name."""

    log = LOG
    NAME = 'DeleteAnimationDialog'

    def __init__(
        self,
        previous_scene: Scene,
        animation_name: str,
        on_confirm_callback: Callable[[], None],
        *,
        on_cancel_callback: Callable[[], None] | None = None,
        options: dict[str, Any] | None = None,
        groups: pygame.sprite.LayeredDirty[Any] | None = None,
    ) -> None:
        """Initialize the Delete Animation Dialog Scene.

        Args:
            previous_scene: The previous scene to return to
            animation_name: The name of the animation to delete
            on_confirm_callback: Function to call when user confirms
            on_cancel_callback: Function to call when user cancels (optional)
            options: Options for the scene
            groups: Sprite groups

        """
        if groups is None:
            groups = pygame.sprite.LayeredDirty()

        super().__init__(options=options, groups=groups)
        # Black behind the dialog (named: a scene that sets no background shows the test pattern)
        self.background_color = BLACK
        self.previous_scene: Any = previous_scene
        self.animation_name = animation_name
        self.on_confirm_callback = on_confirm_callback
        self.on_cancel_callback = on_cancel_callback

        # Create dialog
        dialog_width = 500
        dialog_height = 200

        message = f"Type '{animation_name}' to confirm deletion:"

        assert self.screen is not None
        self.dialog = InputDialog(
            name=self.NAME,
            dialog_text=message,
            confirm_text='Delete',
            cancel_text='Cancel',
            x=self.screen.get_rect().center[0] - (dialog_width // 2),
            y=self.screen.get_rect().center[1] - (dialog_height // 2),
            width=dialog_width,
            height=dialog_height,
            parent=self,
            groups=self.all_sprites,
        )
        self.dialog.dialog_text_sprite.text_box.text = message
        self.dialog.dialog_text_sprite.border_width = 0

    @override
    def setup(self) -> None:
        """Set up the scene."""
        self.dialog.cancel_button.callbacks = {
            'on_left_mouse_button_up_event': self.on_cancel_event,
        }
        self.dialog.confirm_button.callbacks = {
            'on_left_mouse_button_up_event': self.on_confirm_event,
        }
        self.dialog.add(self.all_sprites)
        # Activate input box so user can start typing immediately
        self.dialog.input_box.activate()

    def on_confirm_event(self, event: HashableEvent, trigger: object = None) -> None:  # ruff: ignore[unused-method-argument]
        """Handle confirm button click."""
        # Get the typed text
        typed_text = self.dialog.input_box.text.strip()

        # Validate that the typed text matches the animation name
        if typed_text == self.animation_name:
            LOG.info("DeleteAnimationDialog: User confirmed deletion of '%s'", self.animation_name)
            # Call the callback if provided
            self.on_confirm_callback()
            # Return to previous scene
            self.scene_manager.switch_to_scene(self.previous_scene)
        else:
            LOG.warning(
                "DeleteAnimationDialog: Typed name '%s' does not match '%s'",
                typed_text,
                self.animation_name,
            )
            # Could show an error message here, but for now just do nothing
            # Clear the input box to let user try again
            self.dialog.input_box.text = ''

    def on_cancel_event(self, event: HashableEvent, trigger: object = None) -> None:  # ruff: ignore[unused-method-argument]
        """Handle cancel button click."""
        LOG.info('DeleteAnimationDialog: User cancelled')
        # Call the cancel callback if provided
        if self.on_cancel_callback:
            self.on_cancel_callback()
        # Return to previous scene
        self.scene_manager.switch_to_scene(self.previous_scene)

    @override
    def on_key_down_event(self, event: KeyEvent) -> None:
        """Handle the key down event."""
        if self.dialog.input_box.is_active:
            self.dialog.on_key_down_event(event)
        else:
            super().on_key_down_event(event)

    @override
    def on_key_up_event(self, event: KeyEvent) -> None:
        """Handle the key up event."""
        if self.dialog.input_box.is_active:
            self.dialog.on_key_up_event(event)
        elif event.key == pygame.K_TAB:
            self.dialog.input_box.activate()
        else:
            super().on_key_up_event(event)


class DeleteFrameDialogScene(Scene):
    """Delete Frame Confirmation Dialog - requires typing 'YES'."""

    log = LOG
    NAME = 'DeleteFrameDialog'

    def __init__(
        self,
        previous_scene: Scene,
        animation_name: str,
        frame_index: int,
        on_confirm_callback: Callable[[], None],
        *,
        on_cancel_callback: Callable[[], None] | None = None,
        options: dict[str, Any] | None = None,
        groups: pygame.sprite.LayeredDirty[Any] | None = None,
    ) -> None:
        """Initialize the Delete Frame Dialog Scene.

        Args:
            previous_scene: The previous scene to return to
            animation_name: The name of the animation containing the frame
            frame_index: The index of the frame to delete
            on_confirm_callback: Function to call when user confirms
            on_cancel_callback: Function to call when user cancels (optional)
            options: Options for the scene
            groups: Sprite groups

        """
        if groups is None:
            groups = pygame.sprite.LayeredDirty()

        super().__init__(options=options, groups=groups)
        # Black behind the dialog (named: a scene that sets no background shows the test pattern)
        self.background_color = BLACK
        self.previous_scene: Any = previous_scene
        self.animation_name = animation_name
        self.frame_index = frame_index
        self.on_confirm_callback = on_confirm_callback
        self.on_cancel_callback = on_cancel_callback

        # Create dialog
        dialog_width = 500
        dialog_height = 200

        message1 = f"Delete this frame from '{animation_name}'?"
        message2 = "Type 'YES' to confirm:"

        assert self.screen is not None
        self.dialog = InputDialog(
            name=self.NAME,
            dialog_text=message1,
            confirm_text='Delete',
            cancel_text='Cancel',
            x=self.screen.get_rect().center[0] - (dialog_width // 2),
            y=self.screen.get_rect().center[1] - (dialog_height // 2),
            width=dialog_width,
            height=dialog_height,
            parent=self,
            groups=self.all_sprites,
        )
        self.dialog.dialog_text_sprite.text_box.text = message1
        self.dialog.dialog_text_sprite.border_width = 0

        # Add second label for the confirmation prompt
        from glitchygames.ui import TextSprite

        dialog_text_rect = self.dialog.dialog_text_sprite.rect
        assert dialog_text_rect is not None
        self.second_label = TextSprite(
            text=message2,
            x=int(dialog_text_rect.x),
            y=int(dialog_text_rect.y) + 30,  # Position below first label
            width=int(dialog_text_rect.width),
            height=20,
            groups=self.all_sprites,
        )
        self.second_label.border_width = 0
        self.second_label.background_color = self.dialog.dialog_text_sprite.background_color

    @override
    def setup(self) -> None:
        """Set up the scene."""
        self.dialog.cancel_button.callbacks = {
            'on_left_mouse_button_up_event': self.on_cancel_event,
        }
        self.dialog.confirm_button.callbacks = {
            'on_left_mouse_button_up_event': self.on_confirm_event,
        }
        self.dialog.add(self.all_sprites)
        # Activate input box so user can start typing immediately
        self.dialog.input_box.activate()

    def on_confirm_event(self, event: HashableEvent, trigger: object = None) -> None:  # ruff: ignore[unused-method-argument]
        """Handle confirm button click."""
        # Get the typed text
        typed_text = self.dialog.input_box.text.strip()

        # Validate that the typed text is "YES"
        if typed_text == 'YES':
            LOG.info(
                "DeleteFrameDialog: User confirmed deletion of frame %s from '%s'",
                self.frame_index,
                self.animation_name,
            )
            # Call the callback if provided
            self.on_confirm_callback()
            # Return to previous scene
            self.scene_manager.switch_to_scene(self.previous_scene)
        else:
            LOG.warning("DeleteFrameDialog: Typed text '%s' does not match 'YES'", typed_text)
            # Clear the input box to let user try again
            self.dialog.input_box.text = ''

    def on_cancel_event(self, event: HashableEvent, trigger: object = None) -> None:  # ruff: ignore[unused-method-argument]
        """Handle cancel button click."""
        LOG.info('DeleteFrameDialog: User cancelled')
        # Call the cancel callback if provided
        if self.on_cancel_callback:
            self.on_cancel_callback()
        # Return to previous scene
        self.scene_manager.switch_to_scene(self.previous_scene)

    @override
    def on_key_down_event(self, event: KeyEvent) -> None:
        """Handle the key down event."""
        if self.dialog.input_box.is_active:
            self.dialog.on_key_down_event(event)
        else:
            super().on_key_down_event(event)

    @override
    def on_key_up_event(self, event: KeyEvent) -> None:
        """Handle the key up event."""
        if self.dialog.input_box.is_active:
            self.dialog.on_key_up_event(event)
        elif event.key == pygame.K_TAB:
            self.dialog.input_box.activate()
        else:
            super().on_key_up_event(event)
