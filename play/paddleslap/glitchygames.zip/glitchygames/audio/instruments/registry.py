"""The assembled catalog and its lookups (re-exported by ``glitchygames.audio.instruments``)."""

from __future__ import annotations

import difflib
import functools
from typing import TYPE_CHECKING, Final

from glitchygames.audio.instruments.brass import BRASS
from glitchygames.audio.instruments.catalog import CatalogEntry, Family
from glitchygames.audio.instruments.keyboards import ELECTRONIC, KEYBOARDS, ORGANS
from glitchygames.audio.instruments.percussion import DRUMS_AND_PERCUSSION, TUNED_PERCUSSION
from glitchygames.audio.instruments.strings import (
    BOWED_STRINGS,
    HARPS,
    PLUCKED_STRINGS,
    STRUCK_STRINGS,
)
from glitchygames.audio.instruments.voices import CHOIRS, VOICES
from glitchygames.audio.instruments.winds import (
    BAGPIPES,
    CLARINETS,
    DOUBLE_REEDS,
    FLUTES,
    FREE_REEDS,
    SAXOPHONES,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from glitchygames.audio.instrument import Instrument

SUGGESTION_COUNT: Final[int] = 3


FAMILY_TABLES: Final[tuple[tuple[CatalogEntry, ...], ...]] = (
    FLUTES,
    CLARINETS,
    SAXOPHONES,
    DOUBLE_REEDS,
    BAGPIPES,
    FREE_REEDS,
    BRASS,
    BOWED_STRINGS,
    PLUCKED_STRINGS,
    HARPS,
    STRUCK_STRINGS,
    KEYBOARDS,
    ORGANS,
    ELECTRONIC,
    TUNED_PERCUSSION,
    DRUMS_AND_PERCUSSION,
    VOICES,
    CHOIRS,
)


def catalog_from(tables: Sequence[Sequence[CatalogEntry]]) -> dict[str, CatalogEntry]:
    """The catalog: every table's entries by name, in table order.

    Args:
        tables: The family tables.

    Returns:
        Name to entry.

    Raises:
        ValueError: When two entries share a name.
    """
    catalog: dict[str, CatalogEntry] = {}
    for table in tables:
        for catalog_entry in table:
            if catalog_entry.name in catalog:
                message = f'the catalog names {catalog_entry.name!r} twice'
                raise ValueError(message)
            catalog[catalog_entry.name] = catalog_entry
    return catalog


CATALOG: Final[dict[str, CatalogEntry]] = catalog_from(FAMILY_TABLES)


def entry(name: str) -> CatalogEntry:
    """The catalog entry named ``name``, in any case.

    Args:
        name: A catalog name, e.g. ``'tenor saxophone'`` (``'Tenor Saxophone'`` finds it too:
            the name is lowercased first).

    Returns:
        The entry.

    Raises:
        KeyError: When no instrument has that name (the message suggests close names).
    """
    try:
        return CATALOG[name.lower()]
    except KeyError:
        close = difflib.get_close_matches(name.lower(), CATALOG, n=SUGGESTION_COUNT)
        hint = f'; did you mean {", ".join(close)}?' if close else ''
        message = f'no instrument named {name!r} in the catalog{hint}'
        raise KeyError(message) from None


def get(name: str) -> Instrument:
    """The catalog instrument named ``name``, in any case, built on first use and kept.

    Args:
        name: A catalog name, e.g. ``'violin'`` (``'Violin'`` is the same instrument: the name
            is lowercased before the cache, so every spelling shares one build).

    Returns:
        The instrument.

    An unknown name raises ``entry``'s KeyError.
    """
    entry(name)  # an unknown name fails here, quoted as the caller spelled it
    return _built(name.lower())


@functools.cache
def _built(name: str) -> Instrument:
    return entry(name).build()


def _family(family: Family | str | None) -> Family | None:
    """``family`` as a Family, lowercased first when it is a string (None stays None).

    Returns:
        The family, or None. A string that names no family raises Family's ValueError.
    """
    if family is None:
        return None
    return Family(family.lower())


def names(*, family: Family | str | None = None) -> tuple[str, ...]:
    """Every catalog name, in catalog order, or only one family's.

    Args:
        family: A family, its name in any case (``'Double Reeds'``), or None for all.

    Returns:
        The names.

    An unknown family name raises ``ValueError``.
    """
    wanted = _family(family)
    return tuple(
        name for name, value in CATALOG.items() if wanted is None or value.family == wanted
    )


def entries(*, family: Family | str | None = None) -> tuple[CatalogEntry, ...]:
    """Every catalog entry, in catalog order, or only one family's.

    Args:
        family: A family, its name in any case (``'Double Reeds'``), or None for all.

    Returns:
        The entries.
    """
    return tuple(CATALOG[name] for name in names(family=family))


def families() -> tuple[Family, ...]:
    """The families, in catalog order.

    Returns:
        The families.
    """
    return tuple(Family)
