"""Game Over scene with optional score display and high score tracking."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Self, override

import pygame

from glitchygames.color import BLACK
from glitchygames.fonts import FontManager, font_manager
from glitchygames.scenes import Scene

if TYPE_CHECKING:
    from glitchygames.events.base import ControllerButtonEvent, JoyButtonEvent, KeyEvent
from glitchygames.scenes.builtin_scenes.gamepad_choice import GamepadChoice, GamepadChoiceButtons
from glitchygames.sprites import Sprite

log = logging.getLogger('game')


class GameOverScene(Scene):
    """Game Over scene with final score and high score display.

    Accepts an optional final_score to show the player's result and
    an optional high_scores list to display the leaderboard.
    """

    def __init__(
        self: Self,
        final_score: int | None = None,
        high_scores: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the Game Over scene.

        Args:
            final_score: The player's final score (displayed if provided).
            high_scores: List of high score dicts with 'score' key,
                sorted descending. Top 5 are displayed.
            **kwargs: Additional keyword arguments.

        """
        super().__init__(**kwargs)
        # Black behind the text (named: a scene that sets no background shows the test pattern)
        self.background_color = BLACK
        self.final_score = final_score
        self.high_scores = high_scores or []
        self.text_sprite = None
        self._space_pressed = False
        # A gamepad's Start or A restarts, B or Back quits, as SPACE and ESC do
        self._gamepad_buttons = GamepadChoiceButtons()
        # Don't set next_scene to self - this causes infinite loops
        # The scene will stay active until user input changes it

    @override
    def setup(self: Self) -> None:
        """Set up the Game Over scene with score display."""
        super().setup()
        log.info('GameOverScene setup() called')

        center_x = self.screen_width // 2
        current_y = self.screen_height // 4

        # Title
        self.text_sprite = TextSprite(
            'GAME OVER',
            (center_x, current_y),
            color=(255, 0, 0),
            font_size=28,
        )
        self.all_sprites.add(self.text_sprite)
        current_y += 60

        # Final score (if provided)
        if self.final_score is not None:
            score_sprite = TextSprite(
                f'Score: {self.final_score}',
                (center_x, current_y),
                color=(255, 255, 100),
                font_size=18,
            )
            self.all_sprites.add(score_sprite)
            current_y += 50

        # High scores (top 5)
        if self.high_scores:
            header = TextSprite(
                'HIGH SCORES',
                (center_x, current_y),
                color=(200, 200, 200),
                font_size=16,
            )
            self.all_sprites.add(header)
            current_y += 35

            max_displayed = 5
            for rank, entry in enumerate(self.high_scores[:max_displayed], start=1):
                score_value = entry.get('score', 0)
                entry_sprite = TextSprite(
                    f'{rank}. {score_value}',
                    (center_x, current_y),
                    color=(180, 180, 180),
                    font_size=13,
                )
                self.all_sprites.add(entry_sprite)
                current_y += 30

        # Subtitle
        current_y += 20
        subtitle = TextSprite(
            'Press SPACE or START to restart, ESC or BACK to quit',
            (center_x, current_y),
            color=(255, 255, 255),
            font_size=13,
        )
        self.all_sprites.add(subtitle)
        log.info('GameOverScene setup() completed')

    @override
    def update(self: Self) -> None:
        """Update the Game Over scene."""
        # Call the parent update method to handle sprite updates
        super().update()
        log.debug('GameOverScene update() called')

    @override
    def on_key_down_event(self: Self, event: KeyEvent) -> None:
        """Handle key down events for the Game Over scene.

        Args:
            event (KeyEvent): The key down event.

        """
        if event.key == pygame.K_SPACE:
            # Track that spacebar is pressed (but don't act on it yet)
            self._space_pressed = True
        elif event.key == pygame.K_ESCAPE:
            # Quit the game
            self.scene_manager.quit()
        else:
            # Let the base Scene class handle other keys (like 'q' for quit)
            super().on_key_down_event(event)

    @override
    def on_key_up_event(self: Self, event: KeyEvent) -> None:
        """Handle key up events for the Game Over scene.

        Args:
            event (KeyEvent): The key up event.

        """
        if event.key == pygame.K_SPACE and self._space_pressed:
            # Spacebar was pressed and now released - restart the game
            self._space_pressed = False
            self.play_again()
        else:
            # Let the base Scene class handle other keys
            super().on_key_up_event(event)

    @override
    def on_controller_button_down_event(self: Self, event: ControllerButtonEvent) -> None:
        """A mapped gamepad's B or Back quits; Start or A arms the restart (gamepad_choice.py).

        Args:
            event: The controller button down event.

        """
        self._on_gamepad_button_down(event)
        super().on_controller_button_down_event(event)

    @override
    def on_controller_button_up_event(self: Self, event: ControllerButtonEvent) -> None:
        """A mapped gamepad's Start or A, released after its press here, restarts the game.

        Args:
            event: The controller button up event.

        """
        self._on_gamepad_button_up(event)
        super().on_controller_button_up_event(event)

    @override
    def on_joy_button_down_event(self: Self, event: JoyButtonEvent) -> None:
        """Any other gamepad's B or Back quits; Start or A arms the restart (gamepad_choice.py).

        Args:
            event: The joystick button down event.

        """
        self._on_gamepad_button_down(event)
        super().on_joy_button_down_event(event)

    @override
    def on_joy_button_up_event(self: Self, event: JoyButtonEvent) -> None:
        """Any other gamepad's Start or A, released after its press here, restarts the game.

        Args:
            event: The joystick button up event.

        """
        self._on_gamepad_button_up(event)
        super().on_joy_button_up_event(event)

    def _on_gamepad_button_down(self: Self, event: ControllerButtonEvent | JoyButtonEvent) -> None:
        """Quit for B or Back, as ESC does (BUGS.md #209 item 10: no gamepad could).

        Args:
            event: The button down event, from either layer.

        """
        if self._gamepad_buttons.button_pressed(event) is GamepadChoice.QUIT:
            self.scene_manager.quit()

    def _on_gamepad_button_up(self: Self, event: ControllerButtonEvent | JoyButtonEvent) -> None:
        """Restart the game for a Start or A pressed here, as SPACE does.

        Args:
            event: The button up event, from either layer.

        """
        if self._gamepad_buttons.button_released(event) is GamepadChoice.CONTINUE:
            self.play_again()

    def play_again(self: Self) -> None:
        """Start a new game: a new instance of the previous scene's class, same options."""
        # Get the game class from the previous scene
        if self.scene_manager.previous_scene:
            game_class = type(self.scene_manager.previous_scene)
            self.log.info('Restarting game with class: %s', game_class)

            # Create a new instance of the game with the same options
            new_game = game_class(options=self.options)

            # Switch to the new game instance
            self.scene_manager.switch_to_scene(new_game)
        else:
            self.log.warning('No previous scene found to restart')


class TextSprite(Sprite):
    """A sprite class for displaying text."""

    def __init__(
        self: Self,
        text: str,
        position: tuple[int, int],
        color: tuple[int, int, int] = (255, 255, 255),
        font_size: int = 13,
        **kwargs: Any,
    ) -> None:
        """Initialize the text sprite.

        Args:
            text: The text to display.
            position: The position of the text (x, y).
            color: The color of the text.
            font_size: The point size of the bundled Vera Bold it is drawn in.
            **kwargs: Additional keyword arguments.

        """
        # The bundled Vera Bold, never pygame's default font: SDL_ttf lays the default font out
        # differently on Windows (1 px narrower at 28 points, PR #328), and this sprite's rect is
        # the text's size, so a recording made on one platform diverged on another
        font = font_manager.bundled_font(bold=True, size=font_size)

        # Render the text
        text_surface = font.render(text, FontManager.antialias(), color)

        # Initialize the sprite with the text surface
        super().__init__(
            x=position[0] - text_surface.get_width() // 2,  # Center horizontally
            y=position[1] - text_surface.get_height() // 2,  # Center vertically
            width=text_surface.get_width(),
            height=text_surface.get_height(),
            **kwargs,
        )

        # Set the image to the text surface
        self.image = text_surface
