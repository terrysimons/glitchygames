"""Game event manager for game-specific events."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, ClassVar, Self, override

if TYPE_CHECKING:
    import argparse

from glitchygames.events import (
    ActiveEvent,
    FpsEvent,
    GameEvent,
    GameEvents,
    HashableEvent,
    ResourceManager,
    VideoResizeEvent,
)

LOG = logging.getLogger(__name__)


class GameEventManager(ResourceManager, GameEvents):
    """Manager for game events."""

    log: ClassVar[logging.Logger] = LOG

    class GameEventProxy(ResourceManager):
        """Game event proxy."""

        # A proxy belongs to its manager: each construction is a new one (ResourceManager)
        SHARES_INSTANCE: ClassVar[bool] = False

        log: ClassVar[logging.Logger] = LOG

        def __init__(self: Self, game: object) -> None:
            """Initialize the game proxy.

            Args:
                game: the game instance

            """
            super().__init__(game=game)
            self.game: Any = game
            self.proxies: list[Any] = [self.game]

        def on_active_event(self: Self, event: ActiveEvent) -> None:
            """Handle active event.

            Args:
                event: The pygame event.

            """
            # ACTIVEEVENT      gain, state
            self.game.on_active_event(event=event)

        def on_fps_event(self: Self, event: FpsEvent) -> None:
            """Handle fps event.

            Args:
                event: The pygame event.

            """
            # FPSEVENT is pygame.USEREVENT + 1
            self.game.on_fps_event(event=event)

        def on_game_event(self: Self, event: GameEvent) -> None:
            """Handle game event.

            Args:
                event: The pygame event.

            """
            # GAMEEVENT is pygame.USEREVENT + 2
            self.game.on_game_event(event=event)

        def on_menu_item_event(self: Self, event: HashableEvent) -> None:
            """Handle menu item event.

            Args:
                event: The pygame event.

            """
            # MENUEVENT is pygame.USEREVENT + 3
            self.game.on_menu_item_event(event=event)

        def on_sys_wm_event(self: Self, event: HashableEvent) -> None:
            """Handle sys wm event.

            Args:
                event: The pygame event.

            """
            # SYSWMEVENT
            self.game.on_sys_wm_event(event=event)

        def on_user_event(self: Self, event: HashableEvent) -> None:
            """Handle user event.

            Args:
                event: The pygame event.

            """
            # USEREVENT        code
            self.game.on_user_event(event=event)

        def on_video_expose_event(self: Self, event: HashableEvent) -> None:
            """Handle video expose event.

            Args:
                event: The pygame event.

            """
            # VIDEOEXPOSE      none
            self.game.on_video_expose_event(event=event)

        def on_video_resize_event(self: Self, event: VideoResizeEvent) -> None:
            """Handle video resize event.

            Args:
                event: The pygame event.

            """
            # VIDEORESIZE      size, w, h
            self.game.on_video_resize_event(event=event)

        def on_quit_event(self: Self, event: HashableEvent) -> None:
            """Handle quit event.

            Args:
                event: The pygame event.

            """
            # QUIT             none
            self.game.on_quit_event(event=event)

        def on_render_device_reset_event(self: Self, event: HashableEvent) -> None:
            """Handle render device reset event.

            Args:
                event: The pygame event.

            """
            # RENDER_DEVICE_RESET
            self.game.on_render_device_reset_event(event=event)

        def on_render_targets_reset_event(self: Self, event: HashableEvent) -> None:
            """Handle render targets reset event.

            Args:
                event: The pygame event.

            """
            # RENDER_TARGETS_RESET
            self.game.on_render_targets_reset_event(event=event)

        def on_clipboard_update_event(self: Self, event: HashableEvent) -> None:
            """Handle clipboard update event.

            Args:
                event: The pygame event.

            """
            # CLIPBOARDUPDATE
            self.game.on_clipboard_update_event(event=event)

        def on_locale_changed_event(self: Self, event: HashableEvent) -> None:
            """Handle locale changed event.

            Args:
                event: The pygame event.

            """
            # LOCALECHANGED
            self.game.on_locale_changed_event(event=event)

    def __init__(self: Self, game: object) -> None:
        """Initialize the game event manager.

        Args:
            game: The game instance.

        """
        super().__init__(game=game)
        self.proxies: list[GameEventManager.GameEventProxy] = [
            GameEventManager.GameEventProxy(game=game),
        ]

    @override
    def on_active_event(self: Self, event: ActiveEvent) -> None:
        """Handle active event."""
        for proxy in self.proxies:
            proxy.on_active_event(event)

    @override
    def on_clipboard_update_event(self: Self, event: HashableEvent) -> None:
        """Handle clipboard update event."""
        for proxy in self.proxies:
            proxy.on_clipboard_update_event(event)

    @override
    def on_fps_event(self: Self, event: FpsEvent) -> None:
        """Handle fps event."""
        for proxy in self.proxies:
            proxy.on_fps_event(event)

    @override
    def on_game_event(self: Self, event: GameEvent) -> None:
        """Handle game event."""
        for proxy in self.proxies:
            proxy.on_game_event(event)

    @override
    def on_locale_changed_event(self: Self, event: HashableEvent) -> None:
        """Handle locale changed event."""
        for proxy in self.proxies:
            proxy.on_locale_changed_event(event)

    @override
    def on_menu_item_event(self: Self, event: HashableEvent) -> None:
        """Handle menu item event."""
        for proxy in self.proxies:
            proxy.on_menu_item_event(event)

    @override
    def on_quit_event(self: Self, event: HashableEvent) -> None:
        """Handle quit event."""
        for proxy in self.proxies:
            proxy.on_quit_event(event)

    @override
    def on_render_device_reset_event(self: Self, event: HashableEvent) -> None:
        """Handle render device reset event."""
        for proxy in self.proxies:
            proxy.on_render_device_reset_event(event)

    @override
    def on_render_targets_reset_event(self: Self, event: HashableEvent) -> None:
        """Handle render targets reset event."""
        for proxy in self.proxies:
            proxy.on_render_targets_reset_event(event)

    @override
    def on_sys_wm_event(self: Self, event: HashableEvent) -> None:
        """Handle sys wm event."""
        for proxy in self.proxies:
            proxy.on_sys_wm_event(event)

    @override
    def on_user_event(self: Self, event: HashableEvent) -> None:
        """Handle user event."""
        for proxy in self.proxies:
            proxy.on_user_event(event)

    @override
    def on_video_expose_event(self: Self, event: HashableEvent) -> None:
        """Handle video expose event."""
        for proxy in self.proxies:
            proxy.on_video_expose_event(event)

    @override
    def on_video_resize_event(self: Self, event: VideoResizeEvent) -> None:
        """Handle video resize event."""
        for proxy in self.proxies:
            proxy.on_video_resize_event(event)

    @classmethod
    def args(cls, parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
        """Add arguments to the argument parser.

        Args:
            parser (argparse.ArgumentParser): The argument parser.

        Returns:
            argparse.ArgumentParser: The result.

        """
        group = parser.add_argument_group('Game Options')
        group.add_argument(
            '-l',
            '--log-level',
            help='set the logging level (default: warning; a bug report asks for info)',
            choices=['debug', 'info', 'warning', 'error', 'critical'],
            type=str.lower,
            # The owner, 2026-10-28: games default to WARNING, as the tools do; a report of a
            # failure asks for --log-level info (exit_codes.BUG_REPORT_HINT)
            default='warning',
        )
        group.add_argument(
            '--no-unhandled-events',
            help='fail on unhandled events',
            action='store_true',
            default=False,
        )
        group.add_argument(
            '-p',
            '--profile',
            help='enable profiling',
            action='store_true',
            default=False,
        )

        return parser
