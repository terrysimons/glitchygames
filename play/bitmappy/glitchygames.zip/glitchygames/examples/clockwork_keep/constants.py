"""Constants for Clockwork Keep — a steampunk vertical tower climb."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Screen / World
# ---------------------------------------------------------------------------
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 480

# Tower layout: playfield is centered, walls on each side
WALL_WIDTH = 100
PLAYFIELD_LEFT = WALL_WIDTH
PLAYFIELD_RIGHT = SCREEN_WIDTH - WALL_WIDTH
PLAYFIELD_WIDTH = PLAYFIELD_RIGHT - PLAYFIELD_LEFT  # 600px

# ---------------------------------------------------------------------------
# Physics (pixels/sec or pixels/sec²)
# ---------------------------------------------------------------------------
GRAVITY = 1200.0
JUMP_VELOCITY = -480.0  # Normal jump — reaches ~96px up
JUMP_VELOCITY_RUNNING = -580.0  # Running jump — reaches ~140px up
MAX_FALL_SPEED = 800.0
PLAYER_WALK_SPEED = 160.0  # Normal movement
PLAYER_RUN_SPEED = 280.0  # Holding run button
PLAYER_ACCELERATION = 1600.0
PLAYER_DECELERATION = 1200.0
FALLING_VELOCITY_THRESHOLD = 50.0

# ---------------------------------------------------------------------------
# Player dimensions
# ---------------------------------------------------------------------------
PLAYER_WIDTH = 28
PLAYER_HEIGHT = 44

# ---------------------------------------------------------------------------
# Terrain dimensions
# ---------------------------------------------------------------------------
PLATFORM_HEIGHT = 12
ELEVATOR_WIDTH = 60
ELEVATOR_HEIGHT = 8

# ---------------------------------------------------------------------------
# Collectible dimensions
# ---------------------------------------------------------------------------
COG_SIZE = 16

# ---------------------------------------------------------------------------
# Camera (vertical only — no horizontal scroll)
# ---------------------------------------------------------------------------
CAMERA_LEAD_X = 0
# The player's top stays 200 px below the screen's top: a little less view above the player
# than below it on the 480 px screen
CAMERA_LEAD_Y = 200

# Parallax scroll factor of the floor's background (vertical)
PARALLAX_FAR = 0.1

# ---------------------------------------------------------------------------
# Layer depths (for LayeredDirty rendering order)
# ---------------------------------------------------------------------------
LAYER_FAR_BACKGROUND = 0
LAYER_TERRAIN = 4
LAYER_COLLECTIBLES = 5
LAYER_PLAYER = 7

# ---------------------------------------------------------------------------
# Animation
# ---------------------------------------------------------------------------
ANIMATION_SPEED = 8.0
LEG_SWING_AMPLITUDE = 3
ARM_SWING_AMPLITUDE = 2

# ---------------------------------------------------------------------------
# Gameplay
# ---------------------------------------------------------------------------
STARTING_LIVES = 3
PIT_DEATH_THRESHOLD = 100
ELEVATOR_SNAP_TOLERANCE = 5
GROUND_SNAP_TOLERANCE = 20

# Cog point values
COG_BRONZE_POINTS = 10
COG_SILVER_POINTS = 50
COG_GOLD_POINTS = 100

# ---------------------------------------------------------------------------
# Floor themes: (bg_color, platform_color, platform_top, wall_color,
#                wall_accent, window_sky, led_color)
# ---------------------------------------------------------------------------

# Floor 0: Boiler Room — dark, warm, furnace glow
BOILER_BG = (30, 20, 12)
BOILER_PLATFORM = (90, 60, 35)
BOILER_PLATFORM_TOP = (110, 75, 45)
BOILER_WALL = (60, 40, 25)
BOILER_WALL_ACCENT = (80, 55, 30)
BOILER_WINDOW_SKY = (40, 60, 90)
BOILER_LED = (255, 100, 0)
BOILER_GLOW = (200, 100, 20)

# Floor 1: Gear Works — grey, metallic, copper accents
GEAR_BG = (30, 30, 35)
GEAR_PLATFORM = (80, 80, 90)
GEAR_PLATFORM_TOP = (100, 100, 110)
GEAR_WALL = (55, 55, 60)
GEAR_WALL_ACCENT = (75, 70, 65)
GEAR_WINDOW_SKY = (80, 120, 160)
GEAR_LED = (180, 120, 60)
GEAR_COPPER = (180, 120, 60)

# Floor 2: Clock Face — midnight blue, brass gold
CLOCK_BG = (12, 12, 30)
CLOCK_PLATFORM = (130, 110, 60)
CLOCK_PLATFORM_TOP = (160, 140, 80)
CLOCK_WALL = (40, 35, 55)
CLOCK_WALL_ACCENT = (60, 50, 75)
CLOCK_WINDOW_SKY = (140, 160, 200)
CLOCK_LED = (255, 200, 50)
CLOCK_BRASS = (200, 170, 60)
CLOCK_SECOND_HAND = (190, 70, 50)  # Brass-red sweep hand

# ---------------------------------------------------------------------------
# Player colors
# ---------------------------------------------------------------------------
PLAYER_SKIN = (220, 180, 140)
PLAYER_VEST = (100, 60, 30)
PLAYER_GOGGLE_FRAME = (80, 80, 80)
PLAYER_GOGGLE_LENS = (120, 200, 220)
PLAYER_BOOTS = (60, 40, 20)
PLAYER_WRENCH = (160, 160, 170)

# ---------------------------------------------------------------------------
# HUD colors
# ---------------------------------------------------------------------------
HUD_TEXT_COLOR = (240, 220, 180)
HUD_SHADOW_COLOR = (40, 30, 20)

# ---------------------------------------------------------------------------
# Elevator ride feel (tuned by eye and ear)
# ---------------------------------------------------------------------------
ELEVATOR_RIDE_DURATION = 4.0
ELEVATOR_RIDE_EASING = 'ease_in_sine'  # Arrives at speed so the stop reads as a slam
ELEVATOR_SPEED_SAMPLES = 100  # Points used to find the easing's peak slope
ELEVATOR_MOTOR_IDLE_FREQUENCY = 45.0  # Hz, motor at rest
ELEVATOR_MOTOR_PEAK_FREQUENCY = 110.0  # Hz, motor at full speed
ELEVATOR_MOTOR_MINIMUM_VOLUME = 0.15
ELEVATOR_MOTOR_MAXIMUM_VOLUME = 0.6
ELEVATOR_MOTOR_LOW_PASS_CUTOFF = 600.0  # Hz, keeps the sawtooth deep
ELEVATOR_MOTOR_TREMOLO_RATE = 8.0  # Hz, the motor's chug
ELEVATOR_MOTOR_TREMOLO_DEPTH = 0.4
ELEVATOR_BOUNCE_STRENGTH = 14.0  # Pixels
ELEVATOR_BOUNCE_DURATION = 0.6
ELEVATOR_BOUNCE_FREQUENCY = 7.0  # Hz
ELEVATOR_RATTLE_STRENGTH = 5.0
ELEVATOR_RATTLE_DURATION = 0.35
ELEVATOR_RATTLE_FREQUENCY = 25.0
# Ascent rumble at full car speed, tuned by feel (small, sustained hum)
ELEVATOR_ASCENT_RUMBLE_LOW = 0.25
ELEVATOR_ASCENT_RUMBLE_HIGH = 0.05

# Floor-3 clock: starts two minutes to midnight, in seconds since midnight on a 12-hour dial
CLOCK_START_SECONDS = 11 * 3600 + 58 * 60
CLOCK_SECONDS_PER_MINUTE = 60
CLOCK_SECONDS_PER_HOUR = 3600
CLOCK_SECONDS_PER_HALF_DAY = 12 * 3600
CLOCK_HOUR_HAND_LENGTH = 55
CLOCK_HOUR_HAND_WIDTH = 4
CLOCK_MINUTE_HAND_LENGTH = 85
CLOCK_MINUTE_HAND_WIDTH = 3
CLOCK_SECOND_HAND_LENGTH = 100
CLOCK_SECOND_HAND_TAIL_LENGTH = 15
CLOCK_SECOND_HAND_WIDTH = 1
CLOCK_CENTER_CAP_RADIUS = 4
