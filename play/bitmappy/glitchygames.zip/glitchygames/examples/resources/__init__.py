"""Resources for examples."""
