#!/usr/bin/env python3
"""Vertical Movement.

This is a simple vertical movement class that can be used to move sprites up and down.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Self

if TYPE_CHECKING:
    from .speed import Speed


class Vertical:
    """Vertical movement."""

    def __init__(self: Self, speed: Speed) -> None:
        """Initialize the vertical movement.

        Args:
            speed (Speed): The speed object to move at.

        """
        self.speed = speed
        self.current_speed = self.speed.y

    def _change_speed(self: Self, value: float) -> None:
        """Change the current speed.

        Args:
            value (float): The value to change the speed by.

        """
        self.current_speed = value

    def up(self: Self) -> None:
        """Move up."""
        self._change_speed(-self.speed.y)

    def down(self: Self) -> None:
        """Move down."""
        self._change_speed(self.speed.y)

    def stop(self: Self) -> None:
        """Stop moving."""
        self._change_speed(0)

    def get_movement_with_dt(self: Self, dt: float) -> float:
        """Get the movement amount for this frame with delta time applied.

        Args:
            dt (float): The delta time in seconds.

        Returns:
            float: The movement amount for this frame.

        """
        return self.current_speed * dt
