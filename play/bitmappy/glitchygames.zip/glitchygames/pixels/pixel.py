#!/usr/bin/env python3
"""Pixel data handling functions.

Provides generators and utilities for converting raw pixel data into
RGB triplets and pygame surfaces.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator

import pygame

LOG = logging.getLogger('game.pixels')
LOG.addHandler(logging.NullHandler())


def indexed_rgb_triplet_generator[PixelValue](
    pixel_data: Iterable[tuple[PixelValue, ...]],
) -> Iterator[PixelValue]:
    """Yield the first value of each pixel datum.

    For indexed image data unpacked with struct.iter_unpack('<B', ...) each datum is a
    1-tuple holding a palette index, so this yields the indices to look up in the
    palette. For data whose first element is already an (R, G, B) tuple, it yields
    those tuples.

    Yields:
        PixelValue: The first element of each pixel datum.

    """
    for datum in pixel_data:
        yield datum[0]


def rgb_555_triplet_generator(
    pixel_data: Iterable[tuple[int, ...]],
) -> Iterator[tuple[int, int, int]]:
    """Yield (R, G, B) pixel tuples for 555 formated color data.

    Yields:
        tuple[int, int, int]: An (R, G, B) color tuple extracted from 555 packed data.

    """
    # Construct RGB triplets.
    for packed_rgb_triplet in pixel_data:
        # struct unpacks as a 1 element tuple.
        rgb_data = bin(packed_rgb_triplet[0])

        # binary conversions start with 0b, so chop that off.
        rgb_data = rgb_data[2:]

        # Pad the data out.
        pad_bits = 16 - len(rgb_data)
        pad_data = '0' * pad_bits

        rgb_data = pad_data + rgb_data

        LOG.info('Padded %s bits (now %s)', pad_bits, rgb_data)

        # red is 5 bits
        red = int(rgb_data[0:5] + '000', 2)

        if red:
            red += 7

        # green is 6 bits
        green = int(rgb_data[5:10] + '000', 2)

        if green:
            green += 7

        # blue is 5 bits
        blue = int(rgb_data[10:15] + '000', 2)

        # last bit is ignored or used for alpha.

        if blue:
            blue += 7

        LOG.info('Packed RGB: %s', rgb_data)
        LOG.info('Red: %s', red)
        LOG.info('Green: %s', green)
        LOG.info('Blue: %s', blue)

        yield (red, green, blue)


def rgb_565_triplet_generator(
    pixel_data: Iterable[tuple[int, ...]],
) -> Iterator[tuple[int, int, int]]:
    """Yield (R, G, B) tuples for 565 formatted color data.

    Yields:
        tuple[int, int, int]: An (R, G, B) color tuple extracted from 565 packed data.

    """
    # Construct RGB triplets.
    for packed_rgb_triplet in pixel_data:
        # struct unpacks as a 1 element tuple.
        rgb_data = bin(packed_rgb_triplet[0])

        # binary conversions start with 0b, so chop that off.
        rgb_data = rgb_data[2:]

        # Pad the data out.
        pad_bits = 16 - len(rgb_data)
        pad_data = '0' * pad_bits

        rgb_data = pad_data + rgb_data

        LOG.info('Padded %s bits (now %s)', pad_bits, rgb_data)

        # red is 5 bits
        red = int(rgb_data[0:5] + '000', 2)

        if red:
            red += 7

        # green is 6 bits
        green = int(rgb_data[5:11] + '00', 2)

        if green:
            green += 3

        # blue is 5 bits
        blue = int(rgb_data[11:] + '000', 2)

        if blue:
            blue += 7

        LOG.info('Packed RGB: %s', rgb_data)
        LOG.info('Red: %s', red)
        LOG.info('Green: %s', green)
        LOG.info('Blue: %s', blue)

        yield (red, green, blue)


def rgb_triplet_generator(pixel_data: bytes) -> Iterator[tuple[int, int, int]]:
    """Generate RGB triplets from pixel data.

    Args:
        pixel_data: Raw pixel data as bytes

    Yields:
        Tuples of (r,g,b) values

    Raises:
        ValueError: If pixel data is empty or its length is not divisible by 3.

    """
    # Validate input
    if not pixel_data:
        message = 'Empty pixel data'
        raise ValueError(message)

    if len(pixel_data) % 3 != 0:
        message = f'Pixel data length ({len(pixel_data)}) is not divisible by 3'
        raise ValueError(message)

    # Convert bytes to integers
    pixels = [int(b) for b in pixel_data]

    # Yield RGB triplets (the length is a multiple of 3, checked above, so each is whole)
    for i in range(0, len(pixels), 3):
        yield (pixels[i], pixels[i + 1], pixels[i + 2])


def image_from_pixels(
    pixels: list[tuple[int, int, int]],
    width: int,
    height: int,
) -> pygame.Surface:
    """Produce a pygame.image object for the specified [(R, G, B), ...] pixel data.

    Returns:
        pygame.Surface: The result.

    """
    image = pygame.Surface((width, height))
    y = 0
    x = 0
    for pixel in pixels:
        image.fill(pixel, ((x, y), (1, 1)))

        if (x + 1) % width == 0:
            x = 0
            y += 1
        else:
            x += 1

    return image


def pixels_from_data(pixel_data: bytes) -> list[tuple[int, int, int]]:
    """Expand raw pixel data into [(R, G, B), ...] triplets.

    Returns:
        list: The result.

    """
    pixels = rgb_triplet_generator(
        pixel_data=pixel_data,
    )

    # We are converting the data from a generator to
    # a list of data so that it can be referenced
    # multiple times.
    return list(pixels)


def pixels_from_path(path: str) -> list[tuple[int, int, int]]:
    """Expand raw pixel data from file into [(R, G, B), ...] triplets.

    Returns:
        list[tuple[int, int, int]]: The result.

    """
    pixel_data: bytes = Path(path).read_bytes()
    return pixels_from_data(pixel_data=pixel_data)
