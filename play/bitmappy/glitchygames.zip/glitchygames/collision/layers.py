"""Collision layer system for organizing sprite-vs-sprite collision checks.

CollisionManager groups sprites into named layers and provides efficient
pair-checking between layers with callbacks.

Usage:
    collisions = CollisionManager()
    player_layer = collisions.add_layer('player')
    enemy_layer = collisions.add_layer('enemies')
    player_layer.add(player_sprite)
    enemy_layer.add(cobra_sprite)
    collisions.check_overlap('player', 'enemies', on_player_hit_enemy)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, TypeIs

from glitchygames.collision.bounds import opaque_bounds, trims_transparent_hitbox
from glitchygames.collision.detection import (
    WorldRectSprite,
    check_aabb_overlap,
    get_collision_rect,
    is_world_rect_sprite,
    snapped_world_position,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    import pygame


class CollisionLayer:
    """A named group of sprites that participate in collision.

    Sprites in a layer can be checked against sprites in another
    layer (or the same layer for intra-group collisions).

    Args:
        name: Human-readable name for this layer.

    """

    def __init__(self, name: str) -> None:
        """Initialize the collision layer."""
        self.name = name
        self._sprites: list[Any] = []

    def add(self, sprite: object) -> None:
        """Add a sprite to this layer.

        Args:
            sprite: The sprite to track for collision.

        """
        if sprite not in self._sprites:
            self._sprites.append(sprite)

    def remove(self, sprite: object) -> None:
        """Remove a sprite from this layer.

        Args:
            sprite: The sprite to remove.

        """
        if sprite in self._sprites:
            self._sprites.remove(sprite)

    def clear(self) -> None:
        """Remove all sprites from this layer."""
        self._sprites.clear()

    @property
    def sprites(self) -> list[Any]:
        """All sprites currently in this layer.

        Returns:
            List of sprites in this layer.

        """
        return self._sprites

    def __len__(self) -> int:
        """Number of sprites in this layer.

        Returns:
            Sprite count.

        """
        return len(self._sprites)


class CollisionManager:
    """Manages collision layers and checks between them.

    Provides a clean API for registering sprite groups and running
    collision checks with callbacks. Replaces manual sprite list
    iteration in game code.
    """

    def __init__(self) -> None:
        """Initialize the collision manager."""
        self._layers: dict[str, CollisionLayer] = {}

    def add_layer(self, name: str) -> CollisionLayer:
        """Create and register a named collision layer.

        Args:
            name: Unique name for this layer (e.g., 'player', 'enemies').

        Returns:
            The created CollisionLayer.

        Raises:
            ValueError: If a layer with this name already exists.

        """
        if name in self._layers:
            msg = f"Collision layer '{name}' already exists"
            raise ValueError(msg)
        layer = CollisionLayer(name)
        self._layers[name] = layer
        return layer

    def get_layer(self, name: str) -> CollisionLayer:
        """Get a collision layer by name.

        Args:
            name: The layer name.

        Returns:
            The CollisionLayer.

        Raises:
            KeyError: If no layer with this name exists.

        """
        if name not in self._layers:
            msg = f"No collision layer named '{name}'"
            raise KeyError(msg)
        return self._layers[name]

    def check_overlap(
        self,
        layer_a_name: str,
        layer_b_name: str,
        callback: Callable[[Any, Any], None],
    ) -> None:
        """Check all pairs between two layers, calling callback on collision.

        For each sprite in layer_a that overlaps a sprite in layer_b,
        calls callback(sprite_a, sprite_b). Uses hitbox-aware collision
        rects when available.

        If layer_a and layer_b are the same, checks all unique pairs
        within the layer (no self-collision, no duplicate pairs).

        Each sprite_a's rect is computed once, before its inner loop, so a callback
        that moves sprite_a does not change which later sprite_b it is tested against
        in this pass. Both layers are iterated as snapshots taken at the start, so a
        callback may add or remove sprites (e.g. collect a pickup) without skipping
        pairs; a sprite removed during the pass can still be paired later in it.

        Args:
            layer_a_name: Name of the first layer.
            layer_b_name: Name of the second layer.
            callback: Called with (sprite_a, sprite_b) on each collision.

        """
        layer_a = self.get_layer(layer_a_name)
        layer_b = self.get_layer(layer_b_name)

        same_layer = layer_a_name == layer_b_name
        # Snapshots: callbacks may change the layers while we iterate
        sprites_a = list(layer_a.sprites)
        all_sprites_b = sprites_a if same_layer else list(layer_b.sprites)

        for index_a, sprite_a in enumerate(sprites_a):
            rect_a = get_sprite_collision_rect(sprite_a)

            sprites_b = all_sprites_b[index_a + 1 :] if same_layer else all_sprites_b

            for sprite_b in sprites_b:
                rect_b = get_sprite_collision_rect(sprite_b)
                if check_aabb_overlap(rect_a, rect_b):
                    callback(sprite_a, sprite_b)

    def check_single(
        self,
        sprite: object,
        layer_name: str,
        callback: Callable[[Any, Any], None],
    ) -> None:
        """Check one sprite against all sprites in a layer (iterating a snapshot of it).

        Args:
            sprite: The sprite to check.
            layer_name: Name of the layer to check against.
            callback: Called with (sprite, other) on each collision.

        """
        layer = self.get_layer(layer_name)
        rect = get_sprite_collision_rect(sprite)

        # Snapshot: the callback may change the layer while we iterate
        for other in list(layer.sprites):
            if other is sprite:
                continue
            other_rect = get_sprite_collision_rect(other)
            if check_aabb_overlap(rect, other_rect):
                callback(sprite, other)

    @property
    def layer_names(self) -> list[str]:
        """Names of all registered layers."""
        return list(self._layers.keys())


class ScreenRectSprite(Protocol):
    """A sprite with only a rect (UI elements), as get_sprite_collision_rect reads it.

    The rect is typed pygame.Rect because get_sprite_collision_rect returns it unchanged as
    its pygame.Rect result; a sprite whose rect is an FRect gets that FRect back.
    """

    @property
    def rect(self) -> pygame.Rect | None:
        """The sprite's screen rect, or None before it has one."""
        ...


def _has_rect(sprite: object) -> TypeIs[ScreenRectSprite]:
    """Whether a sprite has a rect attribute (which may still be None).

    Args:
        sprite: Any object; only the presence of rect is checked.

    Returns:
        True if the sprite has a rect attribute.

    """
    return hasattr(sprite, 'rect')


def get_sprite_collision_rect(sprite: object) -> pygame.Rect:
    """Extract a collision rect from a sprite.

    Handles sprites with world_x/world_y (game objects) and
    sprites with only rect (UI elements).

    Returns:
        A pygame.Rect for collision detection. Sprites with world_x/world_y
        get a rect in world coordinates (see get_collision_rect); sprites with
        only rect get a screen-space rect, trimmed to the visible pixels of
        their image unless they have no image or set
        TRIM_TRANSPARENT_HITBOX = False (then their rect, unchanged); sprites
        with neither get an empty rect.

    """
    import pygame

    if is_world_rect_sprite(sprite):
        return get_collision_rect(sprite, sprite.world_x, sprite.world_y)

    if _has_rect(sprite) and sprite.rect is not None:
        image = getattr(sprite, 'image', None)
        if image is not None and trims_transparent_hitbox(sprite):
            visible_bounds = opaque_bounds(image)
            return pygame.Rect(
                sprite.rect.x + visible_bounds.x,
                sprite.rect.y + visible_bounds.y,
                visible_bounds.width,
                visible_bounds.height,
            )
        return sprite.rect

    return pygame.Rect(0, 0, 0, 0)


def collision_rect_offset(sprite: WorldRectSprite) -> tuple[int, int]:
    """Return the offset of a world sprite's collision rect from its snapped world position.

    Terrain code uses it to place a sprite so its collision rect (not its whole image) is
    flush against a surface: ``world_x = wall_left - (offset_x + rect.width)`` puts the rect's
    right edge on ``wall_left``, and ``world_x = wall_right - offset_x`` puts its left edge on
    ``wall_right``.

    Args:
        sprite (WorldRectSprite): A sprite with world_x and world_y.

    Returns:
        tuple[int, int]: (offset_x, offset_y) of the collision rect's top-left.

    """
    collision_rect = get_collision_rect(sprite, sprite.world_x, sprite.world_y)
    snapped_world_x, snapped_world_y = snapped_world_position(
        sprite, sprite.world_x, sprite.world_y
    )
    return (collision_rect.x - snapped_world_x, collision_rect.y - snapped_world_y)
