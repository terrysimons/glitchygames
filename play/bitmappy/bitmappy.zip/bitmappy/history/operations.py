#!/usr/bin/env python3
"""Operation trackers that create Command objects for the undo/redo system.

Each tracker is a thin factory: it accepts the raw data about what happened
and creates the appropriate command, then pushes it onto the UndoRedoManager.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence

    from bitmappy.protocols import EditorContext

from .commands import (
    AnimationAddCommand,
    AnimationDeleteCommand,
    AnimationRenameCommand,
    BrushStrokeCommand,
    ControllerModeCommand,
    ControllerPositionCommand,
    FloodFillCommand,
    FrameAddCommand,
    FrameDeleteCommand,
    FrameReorderCommand,
    FrameSelectionCommand,
)
from .undo_redo import OperationType, UndoRedoManager

# Type alias for pixel change tuples: (x, y, old_color, new_color)
type PixelChangeTuple = tuple[int, int, tuple[int, int, int], tuple[int, int, int]]

LOG = logging.getLogger(__name__)
LOG.addHandler(logging.NullHandler())


class PixelChange:
    """Represents a single pixel change."""

    def __init__(
        self,
        x: int,
        y: int,
        old_color: tuple[int, int, int],
        new_color: tuple[int, int, int],
    ) -> None:
        """Initialize a pixel change record with position and color data."""
        self.x = x
        self.y = y
        self.old_color = old_color
        self.new_color = new_color


class CanvasOperationTracker:
    """Tracks canvas operations for undo/redo by creating command objects."""

    def __init__(self, undo_redo_manager: UndoRedoManager, *, editor: EditorContext) -> None:
        """Initialize the canvas operation tracker.

        Args:
            undo_redo_manager: The undo/redo manager to push commands onto.
            editor: The editor context (needed by command objects).

        """
        self.undo_redo_manager = undo_redo_manager
        self.editor = editor
        self._current_brush_pixels: list[PixelChangeTuple] = []
        LOG.debug('CanvasOperationTracker initialized')

    def add_pixel_changes(
        self,
        pixels: list[tuple[int, int, tuple[int, int, int], tuple[int, int, int]]],
    ) -> None:
        """Add pixel changes to the undo/redo history.

        Args:
            pixels: List of (x, y, old_color, new_color) tuples.

        """
        if not pixels:
            return

        command = BrushStrokeCommand(
            editor=self.editor,
            pixels=pixels,
            operation_type=OperationType.CANVAS_BRUSH_STROKE,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked pixel changes: %s', command.description)

    def add_single_pixel_change(
        self,
        x: int,
        y: int,
        old_color: tuple[int, int, int],
        new_color: tuple[int, int, int],
    ) -> None:
        """Add a single pixel change operation.

        Args:
            x: X coordinate of the pixel.
            y: Y coordinate of the pixel.
            old_color: Previous color of the pixel.
            new_color: New color of the pixel.

        """
        self.add_pixel_changes([(x, y, old_color, new_color)])

    def start_brush_stroke(self) -> None:
        """Start tracking a brush stroke (backward-compatible API).

        Call add_pixel_change() to add pixels, then end_brush_stroke() to commit.
        """
        self._current_brush_pixels = []
        LOG.debug('Started brush stroke tracking')

    def add_pixel_change(
        self,
        x: int,
        y: int,
        old_color: tuple[int, int, int],
        new_color: tuple[int, int, int],
    ) -> None:
        """Add a pixel to the current brush stroke (backward-compatible API).

        Args:
            x: X coordinate of the pixel.
            y: Y coordinate of the pixel.
            old_color: Previous color of the pixel.
            new_color: New color of the pixel.

        """
        self._current_brush_pixels.append((x, y, old_color, new_color))
        LOG.debug('Added pixel to brush stroke: (%s, %s)', x, y)

    def end_brush_stroke(self) -> None:
        """End brush stroke and commit to history (backward-compatible API)."""
        if self._current_brush_pixels:
            self.add_pixel_changes(self._current_brush_pixels)
            LOG.debug('Ended brush stroke: %s pixels', len(self._current_brush_pixels))
            self._current_brush_pixels = []
        else:
            LOG.debug('Ended brush stroke with no pixels')

    def add_flood_fill(
        self,
        x: int,
        y: int,
        old_color: tuple[int, int, int],
        new_color: tuple[int, int, int],
        affected_pixels: list[tuple[int, int]],
    ) -> None:
        """Add a flood fill operation.

        Args:
            x: Starting X coordinate.
            y: Starting Y coordinate.
            old_color: Color that was replaced.
            new_color: Color that was filled.
            affected_pixels: List of all pixels that were changed.

        """
        command = FloodFillCommand(
            editor=self.editor,
            start_x=x,
            start_y=y,
            old_color=old_color,
            new_color=new_color,
            affected_pixels=affected_pixels,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked flood fill: %s', command.description)

    def add_frame_pixel_changes(
        self,
        animation: str,
        frame: int,
        pixels: Sequence[PixelChange | PixelChangeTuple],
    ) -> None:
        """Add pixel changes for a specific frame.

        Args:
            animation: Name of the animation.
            frame: Frame index.
            pixels: List of pixel changes (PixelChange objects or tuples).

        """
        if not pixels:
            return

        # Normalise to tuple format
        pixel_tuples: list[PixelChangeTuple] = []
        for pixel in pixels:
            if isinstance(pixel, PixelChange):
                pixel_tuples.append((pixel.x, pixel.y, pixel.old_color, pixel.new_color))
            else:
                pixel_tuples.append(pixel)

        command = BrushStrokeCommand(
            editor=self.editor,
            pixels=pixel_tuples,
            operation_type=OperationType.CANVAS_BRUSH_STROKE,
        )

        self.undo_redo_manager.push_frame_command(animation, frame, command)
        LOG.debug('Tracked frame pixel changes: %s', command.description)


class FilmStripOperationTracker:
    """Tracks film strip operations for undo/redo by creating command objects."""

    def __init__(self, undo_redo_manager: UndoRedoManager, *, editor: EditorContext) -> None:
        """Initialize the film strip operation tracker.

        Args:
            undo_redo_manager: The undo/redo manager to push commands onto.
            editor: The editor context (needed by command objects).

        """
        self.undo_redo_manager = undo_redo_manager
        self.editor = editor
        LOG.debug('FilmStripOperationTracker initialized')

    def add_frame_added(
        self,
        frame_index: int,
        animation_name: str,
        frame_data: dict[str, Any],
    ) -> None:
        """Track when a frame is added.

        Args:
            frame_index: Index where the frame was added.
            animation_name: Name of the animation.
            frame_data: Data about the added frame.

        """
        command = FrameAddCommand(
            editor=self.editor,
            frame_index=frame_index,
            animation_name=animation_name,
            frame_data=frame_data,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked frame addition: %s', command.description)

    def add_frame_deleted(
        self,
        frame_index: int,
        animation_name: str,
        frame_data: dict[str, Any],
    ) -> None:
        """Track when a frame is deleted.

        Args:
            frame_index: Index of the deleted frame.
            animation_name: Name of the animation.
            frame_data: Data about the deleted frame.

        """
        command = FrameDeleteCommand(
            editor=self.editor,
            frame_index=frame_index,
            animation_name=animation_name,
            frame_data=frame_data,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked frame deletion: %s', command.description)

    def add_frame_reordered(self, old_index: int, new_index: int, animation_name: str) -> None:
        """Track when a frame is reordered.

        Args:
            old_index: Original index of the frame.
            new_index: New index of the frame.
            animation_name: Name of the animation.

        """
        command = FrameReorderCommand(
            editor=self.editor,
            old_index=old_index,
            new_index=new_index,
            animation_name=animation_name,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked frame reorder: %s', command.description)

    def add_animation_added(self, animation_name: str, animation_data: dict[str, Any]) -> None:
        """Track when an animation is added.

        Args:
            animation_name: Name of the animation that was added.
            animation_data: Data about the added animation.

        """
        command = AnimationAddCommand(
            editor=self.editor,
            animation_name=animation_name,
            animation_data=animation_data,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked animation addition: %s', command.description)

    def add_animation_deleted(self, animation_name: str, animation_data: dict[str, Any]) -> None:
        """Track when an animation is deleted.

        Args:
            animation_name: Name of the animation that was deleted.
            animation_data: Data about the deleted animation.

        """
        command = AnimationDeleteCommand(
            editor=self.editor,
            animation_name=animation_name,
            animation_data=animation_data,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked animation deletion: %s', command.description)

    def add_animation_renamed(self, *, old_name: str, new_name: str) -> None:
        """Track when an animation is renamed.

        Args:
            old_name: The animation's name before the rename.
            new_name: The animation's name after the rename.

        """
        command = AnimationRenameCommand(
            editor=self.editor,
            old_name=old_name,
            new_name=new_name,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked animation rename: %s', command.description)

    def add_frame_selection(self, animation: str, frame: int) -> None:
        """Track when a frame is selected.

        Args:
            animation: Name of the animation being selected.
            frame: Frame index being selected.

        """
        # Determine previous selection
        previous_animation = None
        previous_frame = None
        if self.undo_redo_manager.current_frame:
            previous_animation, previous_frame = self.undo_redo_manager.current_frame

        # Skip if selection unchanged
        if previous_animation == animation and previous_frame == frame:
            LOG.debug('Frame selection unchanged: %s[%s]', animation, frame)
            return

        # Only a fresh editor has no current frame (a load sets it: BUGS.md #211 item 5), and a
        # fresh editor starts on frame 0 of 'strip_1', so this is the frame undo goes back to
        if previous_animation is None or previous_frame is None:
            previous_animation, previous_frame = 'strip_1', 0

        command = FrameSelectionCommand(
            editor=self.editor,
            old_animation=previous_animation,
            old_frame=previous_frame,
            new_animation=animation,
            new_frame=frame,
        )

        self.undo_redo_manager.push_command(command)

        # Update current frame tracking
        self.undo_redo_manager.current_frame = (animation, frame)
        LOG.debug('Tracked frame selection: %s', command.description)


class ControllerPositionOperationTracker:
    """Tracks controller position and mode changes for undo/redo."""

    def __init__(self, undo_redo_manager: UndoRedoManager, *, editor: EditorContext) -> None:
        """Initialize the controller position operation tracker.

        Args:
            undo_redo_manager: The undo/redo manager to push commands onto.
            editor: The editor context (needed by command objects).

        """
        self.undo_redo_manager = undo_redo_manager
        self.editor = editor
        LOG.debug('ControllerPositionOperationTracker initialized')

    def add_controller_position_change(
        self,
        controller_id: int,
        old_position: tuple[int, int],
        new_position: tuple[int, int],
        old_mode: str | None = None,
        new_mode: str | None = None,
    ) -> None:
        """Track when a controller position changes.

        Args:
            controller_id: ID of the controller.
            old_position: Previous position (x, y).
            new_position: New position (x, y).
            old_mode: Previous mode (optional).
            new_mode: New mode (optional).

        """
        command = ControllerPositionCommand(
            editor=self.editor,
            controller_id=controller_id,
            old_position=old_position,
            new_position=new_position,
            old_mode=old_mode,
            new_mode=new_mode,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked controller position change: %s', command.description)

    def add_controller_mode_change(self, controller_id: int, old_mode: str, new_mode: str) -> None:
        """Track when a controller mode changes.

        Args:
            controller_id: ID of the controller.
            old_mode: Previous mode.
            new_mode: New mode.

        """
        command = ControllerModeCommand(
            editor=self.editor,
            controller_id=controller_id,
            old_mode=old_mode,
            new_mode=new_mode,
        )

        self.undo_redo_manager.push_command(command)
        LOG.debug('Tracked controller mode change: %s', command.description)
