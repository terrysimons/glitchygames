#!/usr/bin/env python3
"""Glitchy Games Bitmap Editor."""

from __future__ import annotations

import contextlib
import multiprocessing
import signal
from pathlib import Path
from typing import TYPE_CHECKING, Any, Self, override

import pygame

from glitchygames import clock
from glitchygames.color import (
    BLACK,
    RGBA_COMPONENT_COUNT,
)
from glitchygames.engine import ExitCode, GameEngine
from glitchygames.engine.game_engine import exit_on_signal
from glitchygames.input.state import current_input
from glitchygames.scenes import Scene
from glitchygames.ui.dialogs import (
    LoadDialogScene,
    NewCanvasDialogScene,
    SaveDialogScene,
)
from glitchygames.user_files import installed_user_files

from .ai_manager import AIManager, shut_down_running_ai_workers
from .animated_canvas import AnimatedCanvasSprite  # ruff: ignore[typing-only-first-party-import] - re-exported for test imports
from .constants import (
    LOG,
    MIN_FILM_STRIPS_FOR_PANEL_POSITIONING,
    SPRITE_FILE_EXTENSIONS,
)
from .controllers.event_handler import ControllerEventHandler
from .controllers.manager import MultiControllerManager
from .editor_setup import EditorSetup
from .file_io import FileIOManager
from .film_strip_coordinator import FilmStripCoordinator
from .frame_operations import FrameOperationManager
from .indicators.collision import VisualCollisionManager
from .masterhub import installed_masterhub
from .panning import PAN_GESTURE_KEYS
from .slider_manager import SliderManager
from .sprite_inspection import load_ai_training_data

if TYPE_CHECKING:
    import argparse

    from glitchygames import events
    from glitchygames.events.voice import VoiceEventManager
    from glitchygames.sprites.animated import AnimatedSprite
    from glitchygames.ui import (
        ColorWellSprite,
        MenuBar,
        MenuItem,
        MultiLineTextBox,
        SliderSprite,
        TabControlSprite,
        TextSprite,
    )

    from .controllers.selection import ControllerSelection
    from .film_strip import FilmStripWidget
    from .film_strip_sprite import FilmStripSprite
    from .history.operations import (
        CanvasOperationTracker,
        ControllerPositionOperationTracker,
        CrossAreaOperationTracker,
        FilmStripOperationTracker,
    )
    from .history.undo_redo import UndoRedoManager
    from .masterhub_push import MasterHubPush
    from .scroll_arrow import ScrollArrowSprite


class BitmapEditorScene(Scene):  # ruff: ignore[too-many-public-methods]
    """Bitmap Editor Scene.

    The scene expects a 'size' option in the format "WIDTHxHEIGHT" (e.g., "800x600")
    when initialized. This corresponds to the -s command line parameter.
    """

    log = LOG

    # Slider/color well attributes (created by SliderManager.setup_sliders_and_color_well)
    red_slider: SliderSprite
    green_slider: SliderSprite
    blue_slider: SliderSprite
    alpha_slider: SliderSprite
    color_well: ColorWellSprite
    tab_control: TabControlSprite
    slider_input_format: str

    # Attributes set by EditorSetup delegate during __init__
    menu_bar: MenuBar
    menu_icon: MenuItem
    animated_sprite: AnimatedSprite
    canvas: AnimatedCanvasSprite
    ai_label: TextSprite
    debug_text: MultiLineTextBox
    voice_manager: VoiceEventManager | None
    undo_redo_manager: UndoRedoManager
    canvas_operation_tracker: CanvasOperationTracker
    film_strip_operation_tracker: FilmStripOperationTracker
    cross_area_operation_tracker: CrossAreaOperationTracker
    controller_position_operation_tracker: ControllerPositionOperationTracker
    current_pixel_changes: list[tuple[int, int, tuple[int, ...], tuple[int, ...]]]
    _is_drag_operation: bool
    pixel_change_timer: float | None
    applying_undo_redo: bool
    _initialized: bool

    # The MasterHUB display mirror (browser only): wired lazily on the first frame, then fed the
    # canvas each frame. None/False off the browser (there is no sibling hub to push to).
    _masterhub_push: MasterHubPush | None = None
    _masterhub_configured: bool = False

    # Set your game name/version here.
    NAME = 'Bitmappy'
    VERSION = '1.0'

    def _update_ai_sprite_position(self) -> None:
        """Update AI sprite positioning when canvas changes."""
        if not hasattr(self, 'ai_label') or not hasattr(self, 'debug_text'):
            return  # AI sprites not initialized yet

        # Calculate new position using same logic as EditorSetup.setup_debug_text_box
        debug_height = 186  # Fixed height for AI chat box

        # Calculate film strip left x position (should be less than color well's right x - 1)
        if hasattr(self, 'color_well') and self.color_well:
            film_strip_left_x = (
                self.color_well.rect.right + 1
            )  # Film strip left x = color well right x + 1
        else:
            # Fallback if color well not available
            film_strip_left_x = self.screen_width - 200

        # AI sprite box should be clamped to right side of screen and grow left
        # but not grow left more than the film strip left x
        debug_x = film_strip_left_x  # Start from film strip left x
        debug_width = self.screen_width - debug_x  # Extend to right edge of screen

        # Position below the 2nd film strip if it exists, otherwise clamp to bottom of screen
        if (
            hasattr(self, 'film_strips')
            and self.film_strips
            and len(self.film_strips) >= MIN_FILM_STRIPS_FOR_PANEL_POSITIONING
        ):
            # Find the bottom of the 2nd film strip
            second_strip_bottom = 0
            # Safely get the second film strip to handle race conditions during sprite loading
            try:
                # Convert to list to safely access by index
                film_strip_list = list(self.film_strips.values())
                if len(film_strip_list) >= MIN_FILM_STRIPS_FOR_PANEL_POSITIONING and hasattr(
                    film_strip_list[1],
                    'rect',
                ):
                    second_strip_bottom = film_strip_list[1].rect.bottom
            except IndexError, KeyError, AttributeError:
                # Handle race condition where film strips are in transition
                second_strip_bottom = 0
            debug_y = second_strip_bottom + 30  # 30 pixels below the 2nd strip
            # Ensure it doesn't go above the bottom of the screen
            debug_y = min(debug_y, self.screen_height - debug_height)
        else:
            # Fallback: clamp to bottom of screen
            debug_y = self.screen_height - debug_height

        # Update AI label position
        self.ai_label.rect.x = debug_x
        self.ai_label.rect.y = debug_y - 20  # Position above the text box
        self.ai_label.rect.width = debug_width
        self.ai_label.rect.height = 20

        # Update debug text position
        self.debug_text.rect.x = debug_x
        self.debug_text.rect.y = debug_y
        self.debug_text.rect.width = debug_width
        self.debug_text.rect.height = debug_height

    def clear_ai_sprite_box(self) -> None:
        """Clear the AI sprite text box."""
        if hasattr(self, 'debug_text') and self.debug_text:
            self.debug_text.text = ''
            self.log.info('AI sprite box cleared via voice command')
        else:
            self.log.warning('Cannot clear AI sprite box - debug_text not available')

    def __init__(
        self,
        options: dict[str, Any],
        groups: pygame.sprite.LayeredDirty | None = None,  # type: ignore[type-arg]
    ) -> None:
        """Initialize the Bitmap Editor Scene.

        Args:
            options: Dictionary of configuration options for the scene.
            groups: Optional pygame sprite groups for sprite management.

        """
        if options is None:  # type: ignore[reportUnnecessaryComparison]
            options = {}

        # Set default size if not provided
        if 'size' not in options:
            options['size'] = '32x32'  # Default canvas size

        super().__init__(options=options, groups=groups)  # type: ignore[arg-type]
        # Black between the panels (named: a scene that sets no background shows the test pattern)
        self.background_color = BLACK

        # Initialize film strip scrolling attributes
        self.film_strip_scroll_offset = 0
        self.max_visible_strips = 2

        # Legacy film_strip_widget reference for backward compatibility
        # Used by _refresh_all_film_strip_widgets and undo/redo methods
        self.film_strip_widget: FilmStripWidget | None = None

        # Pixel change tracking dict for deduplication (used alongside _current_pixel_changes list):
        # (x, y) -> (x, y, old_color, new_color), as canvas_interfaces and the canvas's drag fill it
        self.current_pixel_changes_dict: dict[
            tuple[int, int],
            tuple[int, int, tuple[int, ...], tuple[int, ...]],
        ] = {}

        # Initialize scroll arrows
        self.scroll_up_arrow = None

        # Initialize mouse drag scrolling state
        self.film_strip_drag_start_y = None
        self.film_strip_drag_start_offset = None
        self.is_dragging_film_strips = False

        # Initialize film strip state (populated by FilmStripCoordinator.setup_film_strips)
        self.film_strips: dict[str, FilmStripWidget] = {}
        self.film_strip_sprites: dict[str, FilmStripSprite] = {}
        self.scroll_up_arrow: ScrollArrowSprite | None = None

        # Initialize selection state for multi-selection system
        self.selected_animation: str | None = ''
        self.selected_frame: int | None = 0

        # OLD SYSTEM REMOVED - Using new multi-controller system instead

        # Debug state tracking to prevent redundant logging
        self._last_debug_controller_animation = ''
        self._last_debug_controller_frame = -1
        self._last_debug_keyboard_animation = ''
        self._last_debug_keyboard_frame = -1

        # Initialize multi-controller system
        self.multi_controller_manager = MultiControllerManager()
        self.controller_selections: dict[int, ControllerSelection] = {}

        # Initialize mode switching system
        from bitmappy.controllers.modes import ModeSwitcher

        # Create setup delegate and initialize undo/redo system
        self._setup = EditorSetup(editor=self)
        self._setup.init_undo_redo_system()

        self.mode_switcher = ModeSwitcher()
        self.visual_collision_manager = VisualCollisionManager()

        # Selected frame visibility toggle for canvas comparison
        self.selected_frame_visible = True

        # Initialize extracted subsystem managers
        self._file_io = FileIOManager(self)
        self._ai_integration = AIManager(self)
        self._slider_manager = SliderManager(self)
        self._frame_operations = FrameOperationManager(self)
        self.controller_handler = ControllerEventHandler(self)
        self.mode_switcher.set_handler(self.controller_handler)
        self.film_strip_coordinator = FilmStripCoordinator(self)

        # Set up all components via the setup delegate
        self._setup.setup_menu_bar()
        self._setup.setup_canvas(options)
        self._slider_manager.setup_sliders_and_color_well()
        self._setup.setup_debug_text_box()

        # Set up film strips after canvas is ready
        self.film_strip_coordinator.setup_film_strips()

        # Set up callback for when sprites are loaded
        if hasattr(self, 'canvas') and self.canvas:
            # Set up the callback on the canvas to call the main scene
            self.canvas.on_sprite_loaded = self.film_strip_coordinator.on_sprite_loaded  # type: ignore[attr-defined] # ty: ignore[invalid-assignment]
            self.log.debug('Set up on_sprite_loaded callback for canvas')
            LOG.debug('DEBUG: Set up on_sprite_loaded callback for canvas')

        # Controller selection will be initialized when START button is pressed

        # Voice recognition is currently disabled.
        # See EditorSetup.setup_voice_recognition() for details about enabling it.

        self.all_sprites.clear(self.screen, self.background)  # pyright: ignore[reportArgumentType]  # ty: ignore[invalid-argument-type]

    @override
    def on_menu_item_event(self: Self, event: events.HashableEvent) -> None:
        """Handle the menu item event.

        Args:
            event (pygame.event.Event): The pygame event.

        """
        self.log.info('Scene got menu item event: %s', event)
        if not event.menu.name:
            # This is for the system menu.
            self.log.info('System Menu Clicked')
        elif event.menu.name == 'New':
            self.on_new_canvas_dialog_event(event=event)
        elif event.menu.name == 'Save':
            self.on_save_dialog_event(event=event)
        elif event.menu.name == 'Load':
            self.on_load_dialog_event(event=event)
        elif event.menu.name == 'Quit':
            self.log.info('User quit from menu item.')
            self.scene_manager.quit()
        else:
            self.log.info('Unhandled Menu Item: %s', event.menu.name)
        self.dirty = 1

    # NB: Keepings this around causes GG-7 not to manifest... curious.
    # This function is extraneous now that on_new_canvas_dialog_event exists.
    #
    # There is also some dialog drawing goofiness when keeping this which
    # goes away when we remove it.
    #
    # Keeping as a workaround for GG-7 for now.
    def _reset_canvas_for_new_file(self, width: int, height: int, pixel_size: int) -> None:
        """Reset canvas state for a new file with the given dimensions.

        Args:
            width: Canvas width in pixels.
            height: Canvas height in pixels.
            pixel_size: Display pixel size.

        """
        self.canvas.pixels_across = width
        self.canvas.pixels_tall = height
        self.canvas.pixel_width = pixel_size
        self.canvas.pixel_height = pixel_size

        self.canvas.pixels = [(255, 0, 255, 255)] * (width * height)
        self.canvas.dirty_pixels = [True] * len(self.canvas.pixels)

        # A pan gesture of the old canvas must not carry over to the new one
        self.canvas.end_panning()

    def _create_fresh_animated_sprite(self, width: int, height: int, pixel_size: int) -> None:
        """Create a fresh animated sprite and update the canvas.

        Args:
            width: Sprite width in pixels.
            height: Sprite height in pixels.
            pixel_size: Display pixel size.

        """
        from glitchygames.sprites.animated import AnimatedSprite, SpriteFrame

        fresh_sprite = AnimatedSprite()
        fresh_sprite.name = 'new_canvas'
        fresh_sprite.description = 'New canvas sprite'

        fresh_frame = SpriteFrame(surface=pygame.Surface((width, height)))
        fresh_frame.set_pixel_data([(255, 0, 255)] * (width * height))

        fresh_sprite._animations['default'] = [fresh_frame]  # type: ignore[reportPrivateUsage]
        fresh_sprite.frame_manager.current_animation = 'default'
        fresh_sprite.frame_manager.current_frame = 0

        self.canvas.animated_sprite = fresh_sprite
        self.canvas.image = pygame.Surface((width * pixel_size, height * pixel_size))
        self.canvas.rect = self.canvas.image.get_rect(x=0, y=24)
        self.canvas._update_border_thickness()  # type: ignore[reportPrivateUsage]
        self.canvas.force_redraw()

    def on_new_file_event(self: Self, dimensions: str) -> None:
        """Handle the new file event.

        Args:
            dimensions (str): The canvas dimensions in WxH format.

        """
        self.log.info('Creating new canvas with dimensions: %s', dimensions)

        try:
            width, height = self._parse_canvas_dimensions(dimensions)
        except ValueError:
            # One log.exception: two printed the same traceback twice
            self.log.exception(
                "Invalid dimensions format '%s': expected WxH (e.g., '32x32')", dimensions
            )
        else:
            self.log.info('Parsed dimensions: %sx%s', width, height)

            available_height = self.screen_height - 80 - 24
            new_pixel_size = min(
                available_height // height,
                (self.screen_width * 1 // 2) // width,
                350 // width,
            )
            self.log.info('Calculated new pixel size: %s', new_pixel_size)

            # A size too large for the canvas area leaves each pixel 0 screen pixels wide: a
            # canvas that can't be seen or drawn on, so it is refused and the canvas kept
            # (BUGS.md #176)
            if new_pixel_size < 1:
                self.log.error(
                    "Invalid dimensions '%s': too large to fit the canvas area", dimensions
                )
                self.dirty = 1
                return

            self._reset_canvas_for_new_file(width, height, new_pixel_size)
            self._create_fresh_animated_sprite(width, height, new_pixel_size)
            self.film_strip_coordinator.clear_film_strips_for_new_canvas()
            self.clear_ai_sprite_box()

            if hasattr(self, '_ai_integration'):
                self._ai_integration.pending_ai_requests.clear()
                self.log.info('Cleared AI request cache for new canvas')

            self._update_ai_sprite_position()
            self.canvas.update()
            self.canvas.dirty = 1
            # The previous sprite's undo steps must not apply to the new canvas (BUGS.md #150)
            self.start_new_undo_history()
            self.log.info(
                'Canvas resized to %sx%s with pixel size %s',
                width,
                height,
                new_pixel_size,
            )

        self.dirty = 1

    @staticmethod
    def _parse_canvas_dimensions(dimensions: str) -> tuple[int, int]:
        """Parse canvas dimensions typed as WxH (e.g. '32x32').

        Args:
            dimensions: The dimensions text from the new canvas dialog.

        Returns:
            The canvas width and height in pixels.

        Raises:
            ValueError: If the text is not two whole numbers joined by 'x', or either is not
                positive (a zero width or height would divide by zero sizing the pixels).

        """
        width, height = map(int, dimensions.lower().split('x'))
        if width <= 0 or height <= 0:
            msg = f'Canvas dimensions must be positive, got {width}x{height}'
            raise ValueError(msg)
        return width, height

    def on_new_canvas_dialog_event(self: Self, event: events.HashableEvent) -> None:  # ruff: ignore[unused-method-argument]
        """Handle the new canvas dialog event."""
        # Create a fresh dialog scene each time
        new_canvas_dialog_scene = NewCanvasDialogScene(options=self.options, previous_scene=self)
        # Set the dialog's background to the screenshot
        new_canvas_dialog_scene.background = self.screenshot
        self.next_scene = new_canvas_dialog_scene
        self.dirty = 1

    def on_load_dialog_event(self: Self, event: events.HashableEvent) -> None:  # ruff: ignore[unused-method-argument]
        """Handle the load dialog event.

        Where the game's files are not the player's (a browser: glitchygames/user_files.py),
        the player picks one of their own files instead of typing a name.
        """
        user_files = installed_user_files()
        if user_files is not None:
            user_files.open_file(
                accepted_extensions=SPRITE_FILE_EXTENSIONS, on_opened=self.load_opened_file
            )
            return
        # Create a fresh dialog scene each time
        load_dialog_scene = LoadDialogScene(options=self.options, previous_scene=self)
        # Set the dialog's background to the screenshot
        load_dialog_scene.background = self.screenshot
        self.next_scene = load_dialog_scene
        self.dirty = 1

    def load_opened_file(self: Self, path: Path) -> None:
        """Load a file the player opened through the installed user files into the canvas.

        Args:
            path: The file's copy in the game's file system.

        """
        self.canvas.on_load_file_event(str(path))

    def on_save_dialog_event(self: Self, event: events.HashableEvent) -> None:  # ruff: ignore[unused-method-argument]
        """Handle the save dialog event."""
        # Create a fresh dialog scene each time
        save_dialog_scene = SaveDialogScene(options=self.options, previous_scene=self)
        # Set the dialog's background to the screenshot
        save_dialog_scene.background = self.screenshot
        self.next_scene = save_dialog_scene
        self.dirty = 1

    def on_slider_event(
        self: Self,
        event: events.HashableEvent,
        trigger: events.HashableEvent,
    ) -> None:
        """Handle the slider event by delegating to SliderManager."""
        self._slider_manager.on_slider_event(event, trigger)

    @override
    def on_right_mouse_button_up_event(self: Self, event: events.MouseButtonEvent) -> None:
        """Handle the right mouse button up event.

        Args:
            event (MouseButtonEvent): The pygame event.

        """
        # Check for shift-right-click (screen sampling)
        held_keys = current_input()
        is_shift_click = held_keys.key_pressed(pygame.K_LSHIFT) or held_keys.key_pressed(
            pygame.K_RSHIFT
        )

        # First, check if any sprites have handled the event
        collided_sprites = self.sprites_at_position(pos=event.pos)
        for sprite in collided_sprites:
            if hasattr(sprite, 'on_right_mouse_button_up_event'):
                result = sprite.on_right_mouse_button_up_event(event)
                if result:  # Event was handled by sprite
                    return

        # If no sprite handled the event, proceed with scene-level handling
        # Check if the click is on the canvas to sample canvas pixel data
        if self._sample_canvas_pixel(event, is_shift_click=is_shift_click):
            return

        # Fallback to screen sampling (RGB only)
        try:
            assert self.screen is not None
            # Surface.get_at always returns an RGBA Color; ignore the screen's alpha
            red, green, blue, _ = tuple(self.screen.get_at(event.pos))
            alpha = 255  # Screen has no alpha, default to opaque
            self.log.info(
                'Screen pixel sampled - Red: %s, Green: %s, Blue: %s, Alpha: %s (default)',
                red,
                green,
                blue,
                alpha,
            )

            # Update sliders with RGB values and default alpha
            self._slider_manager.apply_color(red=red, green=green, blue=blue, alpha=alpha)
        except IndexError:
            pass

    def _sample_canvas_pixel(
        self,
        event: events.HashableEvent,
        *,
        is_shift_click: bool,
    ) -> bool:
        """Sample a pixel from the canvas and update sliders.

        Args:
            event: The mouse event with position.
            is_shift_click: Whether shift was held during the click.

        Returns:
            True if a canvas pixel was sampled, False otherwise.

        """
        if not (
            hasattr(self, 'canvas')
            and self.canvas
            and self.canvas.rect is not None  # pyright: ignore[reportUnnecessaryComparison]
            and self.canvas.rect.collidepoint(event.pos)
        ):
            return False

        if is_shift_click:
            # Shift-right-click: sample screen directly (RGB only)
            self.log.info('Shift-right-click detected on canvas - sampling screen directly')
            self._slider_manager.sample_color_from_screen(event.pos)
            return True

        # Regular right-click: sample from canvas pixel data (RGBA)
        canvas_x = (event.pos[0] - self.canvas.rect.x) // self.canvas.pixel_width
        canvas_y = (event.pos[1] - self.canvas.rect.y) // self.canvas.pixel_height

        if not (
            0 <= canvas_x < self.canvas.pixels_across and 0 <= canvas_y < self.canvas.pixels_tall
        ):
            return False

        pixel_num = canvas_y * self.canvas.pixels_across + canvas_x
        if pixel_num >= len(self.canvas.pixels):
            return False

        color: tuple[int, ...] = self.canvas.pixels[pixel_num]  # type: ignore[assignment]

        # Handle both RGB and RGBA pixel formats
        if len(color) == RGBA_COMPONENT_COUNT:  # type: ignore[reportUnknownArgumentType]
            red, green, blue, alpha = (
                int(color[0]),  # pyright: ignore[reportUnknownArgumentType]
                int(color[1]),  # pyright: ignore[reportUnknownArgumentType]
                int(color[2]),  # pyright: ignore[reportUnknownArgumentType]
                int(color[3]),  # pyright: ignore[reportUnknownArgumentType]
            )
        else:
            red, green, blue = int(color[0]), int(color[1]), int(color[2])  # type: ignore[reportUnknownArgumentType]
            alpha = 255  # Default to opaque for RGB pixels

        self.log.info(
            'Canvas pixel sampled - Red: %s, Green: %s, Blue: %s, Alpha: %s',
            red,
            green,
            blue,
            alpha,
        )

        # Update all sliders with the sampled RGBA values
        self._slider_manager.apply_color(red=red, green=green, blue=blue, alpha=alpha)
        return True

    @override
    def on_left_mouse_button_down_event(self: Self, event: events.MouseButtonEvent) -> None:
        """Handle the left mouse button down event.

        Args:
            event (MouseButtonEvent): The pygame event.

        """
        sprites = self.sprites_at_position(pos=event.pos)

        # Check for clicks on scroll arrows first (only if visible)
        if self._handle_scroll_arrow_click(sprites):
            return

        # Check if click is on any slider text box and deactivate others
        clicked_slider = self._slider_manager.detect_clicked_slider(event.pos)

        # Commit and deactivate every editing slider text box (alpha included) except the one
        # clicked (if any), as Enter would
        self._slider_manager.commit_slider_text_boxes(event=event, clicked_slider=clicked_slider)

        # If a slider text box was clicked, also trigger the slider's normal behavior
        if clicked_slider is not None:
            clicked_slider.on_left_mouse_button_down_event(event)

        # Handle other sprite clicks
        for sprite in sprites:
            sprite.on_left_mouse_button_down_event(event)

        # Check if click is in film strip area for drag scrolling (only if no sprite handled it)
        if self.film_strip_coordinator.is_mouse_in_film_strip_area(event.pos):
            self.is_dragging_film_strips = True
            self.film_strip_drag_start_y = event.pos[1]
            self.film_strip_drag_start_offset = self.film_strip_scroll_offset
            self.log.debug(
                'Started film strip drag at Y=%s, offset=%s',
                event.pos[1],
                self.film_strip_scroll_offset,
            )

    def _handle_scroll_arrow_click(self, sprites: list[Any]) -> bool:
        """Handle clicks on scroll arrow sprites.

        Args:
            sprites: List of sprites at the click position.

        Returns:
            True if a scroll arrow was clicked and handled.

        """
        for sprite in sprites:
            if hasattr(sprite, 'direction') and hasattr(sprite, 'visible') and sprite.visible:
                LOG.debug(
                    f'Scroll arrow clicked: direction={sprite.direction}, visible={sprite.visible}',
                )
                if sprite.direction == 'up':
                    LOG.debug('Navigating to previous animation')
                    if hasattr(self, 'canvas') and self.canvas:
                        self.canvas.previous_animation()
                        self.film_strip_coordinator.scroll_to_current_animation()
                        self.film_strip_coordinator.update_film_strips_for_animated_sprite_update()
                    return True
        return False

    def on_tab_change_event(self, tab_format: str) -> None:
        """Handle tab control format change by delegating to SliderManager."""
        self._slider_manager.on_tab_change_event(tab_format)

    @override
    def on_left_mouse_button_up_event(self: Self, event: events.MouseButtonEvent) -> None:
        """Handle the left mouse button up event.

        Args:
            event (MouseButtonEvent): The pygame event.

        """
        # Stop film strip drag scrolling if active
        if self.is_dragging_film_strips:
            self.is_dragging_film_strips = False
            self.film_strip_drag_start_y = None
            self.film_strip_drag_start_offset = None
            self.log.debug('Stopped film strip drag scrolling')

        sprites = self.sprites_at_position(pos=event.pos)

        for sprite in sprites:
            sprite.on_left_mouse_button_up_event(event)

        # A canvas drag released outside the canvas must still finish: flush the stroke, submit
        # it to undo and clear _drag_active (BUGS.md #120). The canvas ignores a release when no
        # drag is active.
        if self.canvas not in sprites:
            self.canvas.on_left_mouse_button_up_event(event)

    @override
    def on_left_mouse_drag_event(
        self: Self, event: events.MouseMotionEvent, trigger: object
    ) -> None:
        """Handle the left mouse drag event.

        Args:
            event (MouseMotionEvent): The pygame event.
            trigger (object): The trigger object.

        """
        # Handle film strip drag scrolling
        if self.is_dragging_film_strips:
            self.log.debug('Handling film strip drag at Y=%s', event.pos[1])
            self.film_strip_coordinator.handle_film_strip_drag_scroll(event.pos[1])
            return  # Don't process other drag events when dragging film strips

        # Optimized: If dragging on canvas, skip expensive sprite collision detection
        # The canvas already handles its own drag events efficiently
        if (
            hasattr(self, 'canvas')
            and self.canvas is not None  # pyright: ignore[reportUnnecessaryComparison]
            and self.canvas.rect is not None  # pyright: ignore[reportUnnecessaryComparison]
            and self.canvas.rect.collidepoint(event.pos)
        ):
            # Directly call canvas drag handler - skip sprite iteration
            self.canvas.on_left_mouse_drag_event(event, trigger)
            return

        # Only do expensive sprite iteration if not dragging on canvas
        self.canvas.on_left_mouse_drag_event(event, trigger)

        try:
            sprites = self.sprites_at_position(pos=event.pos)

            for sprite in sprites:
                sprite.on_left_mouse_drag_event(event, trigger)
        except AttributeError:
            pass

    @override
    def on_mouse_button_up_event(self: Self, event: events.MouseButtonEvent) -> None:
        """Handle mouse button up events."""
        # Check if debug text box should handle the event
        if (
            hasattr(self, 'debug_text')
            and self.debug_text is not None  # pyright: ignore[reportUnnecessaryComparison]
            and self.debug_text.rect is not None  # pyright: ignore[reportUnnecessaryComparison]
            and self.debug_text.rect.collidepoint(event.pos)
        ):
            self.debug_text.on_mouse_up_event(event)
            return

        # Submit collected pixel changes for undo/redo tracking
        self._frame_operations.submit_pixel_changes_if_ready()

        # Reset drag operation flag
        self._is_drag_operation = False

        # Always release all sliders on mouse up to prevent stickiness
        if (
            hasattr(self, 'red_slider')
            and hasattr(self.red_slider, 'dragging')
            and self.red_slider.dragging
        ):
            self.red_slider.dragging = False
            self.red_slider.on_left_mouse_button_up_event(event)
        if (
            hasattr(self, 'green_slider')
            and hasattr(self.green_slider, 'dragging')
            and self.green_slider.dragging
        ):
            self.green_slider.dragging = False
            self.green_slider.on_left_mouse_button_up_event(event)
        if (
            hasattr(self, 'blue_slider')
            and hasattr(self.blue_slider, 'dragging')
            and self.blue_slider.dragging
        ):
            self.blue_slider.dragging = False
            self.blue_slider.on_left_mouse_button_up_event(event)
        if (
            hasattr(self, 'alpha_slider')
            and hasattr(self.alpha_slider, 'dragging')
            and self.alpha_slider.dragging
        ):
            self.alpha_slider.dragging = False
            self.alpha_slider.on_left_mouse_button_up_event(event)

        # Pass to other visible sprites
        for sprite in self.all_sprites:
            if (
                sprite.visible
                and hasattr(sprite, 'on_mouse_button_up_event')
                and sprite.rect.collidepoint(event.pos)
            ):
                sprite.on_mouse_button_up_event(event)

    @override
    def on_mouse_drag_event(self: Self, event: events.MouseMotionEvent, trigger: object) -> None:
        """Handle mouse drag events.

        Args:
            event (MouseMotionEvent): The event to handle
            trigger (object): The trigger object

        """
        for sprite in self.all_sprites:
            if sprite.visible and hasattr(sprite, 'on_mouse_drag_event'):
                sprite.on_mouse_drag_event(event, trigger)

    @override
    def on_mouse_motion_event(self: Self, event: events.MouseMotionEvent) -> None:
        """Handle mouse motion events.

        Args:
            event (MouseMotionEvent): The event to handle

        """
        # Handle slider hover effects
        self._slider_manager.update_slider_hover_effects(event.pos)

        for sprite in self.all_sprites:
            if sprite.visible and hasattr(sprite, 'on_mouse_motion_event'):
                sprite.on_mouse_motion_event(event)

    # ──────────────────────────────────────────────────────────────────────
    # AI integration delegation (methods extracted to ai_integration.py)
    # ──────────────────────────────────────────────────────────────────────

    @override
    def on_text_submit_event(self, text: str) -> None:
        """Handle text submission by delegating to AIManager."""
        self._ai_integration.on_text_submit_event(text)

    @override
    def setup(self) -> None:
        """Set up the bitmap editor scene."""
        super().setup()
        self._ai_integration.setup()

    def _update_animated_canvas(self) -> None:
        """Update the animated canvas with delta time, film strips, and frame transitions."""
        # Debug animation state
        if hasattr(self, '_debug_animation_counter'):
            self._debug_animation_counter += 1
        else:
            self._debug_animation_counter = 1

        # Log animation state approximately once per second, regardless of fps
        if not hasattr(self, '_last_animation_log_time'):
            self._last_animation_log_time = clock.frame_clock_seconds()
        current_time = clock.frame_clock_seconds()
        if current_time - self._last_animation_log_time >= 1.0:
            self._last_animation_log_time = current_time

        # Pass delta time to the canvas for animation updates
        self.canvas.update_animation(self.dt)

        self.film_strip_coordinator.update_film_strip_animation_timing()

        # Render visual indicators for multi-controller system
        self.controller_handler.render_visual_indicators()

        # Check for frame transitions
        frame_index = self.canvas.animated_sprite.current_frame

        if not hasattr(self, '_last_animation_frame') or self._last_animation_frame != frame_index:
            self._last_animation_frame = frame_index

            # Don't update the canvas frame - it should stay on the frame being edited
            # Only the live preview should animate

            # Note: Live preview functionality is now integrated into the film strip

    def set_masterhub_push(self, push: MasterHubPush) -> None:
        """Attach the display mirror's push (idempotent; the browser bridge calls this)."""
        if self._masterhub_push is None:
            self._masterhub_push = push

    def _mirror_canvas_to_masterhub(self) -> None:
        """In the browser, post the canvas to a MasterHUB web hub when it changes (else a no-op).

        Wires the browser bridge once (lazily, on the first frame), then feeds it the canvas each
        frame. Off the browser the bridge is absent, so nothing is wired and nothing is pushed.
        """
        if not self._masterhub_configured:
            self._masterhub_configured = True
            self._install_masterhub_mirror()
        if self._masterhub_push is not None:
            self._masterhub_push.push_if_changed()

    def _install_masterhub_mirror(self) -> None:
        """Wire the installed MasterHUB bridge to this scene; a no-op where none is installed.

        The browser page registers the bridge installer (browser/boot.py, via bitmappy.masterhub);
        off the browser nothing is registered, so this does nothing. Only "nothing registered" is
        the silent case -- an error raised by the installer itself propagates, never swallowed.
        """
        installer = installed_masterhub()
        if installer is not None:
            installer(self)

    @override
    def update(self) -> None:
        """Update scene state."""
        # Advance film strip animations BEFORE Scene.update() so that
        # mark_dirty() sets dirty=1 before the dirty-sprite loop runs.
        if (
            hasattr(self, 'canvas')
            and hasattr(self.canvas, 'animated_sprite')
            and self.canvas.animated_sprite
        ):
            self._update_animated_canvas()
            self._mirror_canvas_to_masterhub()  # browser only: push the canvas to the hub

        super().update()  # Call the base Scene.update() method

        # Update continuous slider adjustments
        self.controller_handler.update_continuous_adjustments()

        # Update continuous canvas movements
        self.controller_handler.update_continuous_movements()

        # Check for single click timer
        self._frame_operations.check_single_click_timer()

        # Check for AI responses
        self._ai_integration.check_responses()

    def _cleanup_voice_recognition(self) -> None:
        """Clean up voice recognition resources.

        **STATUS: Part of disabled voice recognition feature**

        This method is called during scene teardown to properly release microphone
        resources and stop any background threads used by voice recognition.

        **Important:** Always call this even if voice recognition was never enabled,
        as it safely handles the case where voice_manager is None.

        This method:
        - Stops the voice recognition listening thread (if active)
        - Releases microphone resources
        - Clears the voice_manager reference
        - Logs success or error status

        See EditorSetup.setup_voice_recognition() documentation for more information about
        the voice recognition feature status.
        """
        if hasattr(self, 'voice_manager') and self.voice_manager:
            try:
                self.log.info('Stopping voice recognition...')
                self.voice_manager.stop_listening()
                self.voice_manager = None
                self.log.info('Voice recognition stopped successfully')
            except OSError, AttributeError, RuntimeError:
                self.log.exception('Error stopping voice recognition')

    @override
    def cleanup(self) -> None:
        """Clean up resources."""
        self.log.info('Starting cleanup...')

        self._ai_integration.cleanup()

        # Clean up voice recognition
        self._cleanup_voice_recognition()

        super().cleanup()

    @override
    def on_key_up_event(self, event: events.KeyEvent) -> None:
        """Handle key release events.

        Releasing any key of Ctrl+Shift+Arrow (in any order) ends the pan gesture in
        progress and records it as one undoable step.
        """
        if (
            event.key in PAN_GESTURE_KEYS
            and hasattr(self, 'canvas')
            and self.canvas
            and self.canvas.pan_session is not None
        ):
            self.log.debug('Pan key released - finishing the pan')
            self._frame_operations.finish_canvas_panning()

        # Call parent class handler
        super().on_key_up_event(event)

    def _handle_film_strip_text_input(self, event: events.KeyEvent) -> bool | None:
        """Handle text input for film strips in text editing mode.

        Args:
            event: The key down event.

        Returns:
            True if escape was pressed (consume event), None if handled but not escape,
            or False if no film strip was in editing mode.

        """
        if not hasattr(self, 'film_strips'):
            return False

        for film_strip in self.film_strips.values():
            if (
                hasattr(film_strip, 'editing_animation')
                and film_strip.editing_animation
                and film_strip.handle_keyboard_input(event)
            ):
                # If escape was pressed, consume the event to prevent game quit
                if event.key == pygame.K_ESCAPE:
                    return True
                return None
        return False

    def _handle_ctrl_key_shortcuts(self, event: events.KeyEvent, mod: int) -> bool:  # ruff: ignore[too-many-return-statements]
        """Handle Ctrl-based keyboard shortcuts (undo, redo, copy, paste, panning).

        Args:
            event: The key down event.
            mod: The modifier key bitmask.

        Returns:
            True if the event was handled, False otherwise.

        """
        if not (mod & pygame.KMOD_CTRL):
            return False

        if event.key == pygame.K_z:
            if mod & pygame.KMOD_SHIFT:
                self.log.debug('Ctrl+Shift+Z pressed - redo')
                self.handle_redo()
            else:
                self.log.debug('Ctrl+Z pressed - undo')
                self.handle_undo()
            return True

        if event.key == pygame.K_y:
            self.log.debug('Ctrl+Y pressed - redo')
            self.handle_redo()
            return True

        if event.key == pygame.K_c:
            self.log.debug('Ctrl+C pressed - copying frame')
            self._frame_operations.handle_copy_frame()
            return True

        if event.key == pygame.K_v:
            self.log.debug('Ctrl+V pressed - pasting frame')
            self._frame_operations.handle_paste_frame()
            return True

        # Handle panning with Ctrl+Shift+Arrow keys
        if (mod & pygame.KMOD_SHIFT) and hasattr(self, 'canvas') and self.canvas:
            panning_map = {
                pygame.K_LEFT: (-1, 0, 'LEFT'),
                pygame.K_RIGHT: (1, 0, 'RIGHT'),
                pygame.K_UP: (0, -1, 'UP'),
                pygame.K_DOWN: (0, 1, 'DOWN'),
            }
            if event.key in panning_map:
                delta_x, delta_y, direction = panning_map[event.key]
                self.log.debug(
                    'Ctrl+Shift+%s arrow pressed - panning %s',
                    direction,
                    direction.lower(),
                )
                self._frame_operations.handle_canvas_panning(delta_x=delta_x, delta_y=delta_y)
                return True

        return False

    def _handle_arrow_key_navigation(self, event: events.KeyEvent) -> bool:
        """Handle UP/DOWN arrow keys for animation navigation.

        Args:
            event: The key down event.

        Returns:
            True if the event was handled, False otherwise.

        """
        if event.key == pygame.K_UP:
            self.log.debug('UP arrow pressed - navigating to previous animation')
            if hasattr(self, 'canvas') and self.canvas:
                self.canvas.previous_animation()
                self.film_strip_coordinator.scroll_to_current_animation()
            return True

        if event.key == pygame.K_DOWN:
            self.log.debug('DOWN arrow pressed - navigating to next animation')
            if hasattr(self, 'canvas') and self.canvas:
                self.canvas.next_animation()
                self.film_strip_coordinator.scroll_to_current_animation()
            return True

        return False

    def _route_to_canvas_or_parent(self, event: events.KeyEvent) -> None:
        """Route keyboard event to canvas or fall back to parent handler.

        Args:
            event: The key down event.

        """
        # Check if any film strip is in text editing mode before routing to canvas
        for film_strip in self.film_strips.values():
            if hasattr(film_strip, 'editing_animation') and film_strip.editing_animation:
                return

        if hasattr(self, 'canvas') and hasattr(self.canvas, 'handle_keyboard_event'):
            self.log.debug('Routing keyboard event to canvas')
            self.canvas.handle_keyboard_event(event.key)
        else:
            # Fall back to parent class handling
            self.log.debug('No canvas found, using parent class handling')
            super().on_key_down_event(event)

    @override
    def on_key_down_event(self, event: events.KeyEvent) -> None:
        """Handle keyboard events for frame navigation and text input."""
        self.log.debug('Key down event received: key=%s', event.key)

        # Check if debug text box is active and handle text input
        if hasattr(self, 'debug_text') and self.debug_text.is_active:
            self.debug_text.on_key_down_event(event)
            return

        # Check if any slider text box is active and handle text input
        slider_result = self._slider_manager.handle_slider_text_input(event)
        if slider_result is not False:
            return

        # Check if any film strip is in text editing mode and handle text input
        film_strip_result = self._handle_film_strip_text_input(event)
        if film_strip_result is not False:
            return

        # Handle onion skinning toggle, ctrl shortcuts, slider navigation,
        # arrow keys, or route to canvas
        self._handle_key_down_actions(event)

    def _handle_key_down_actions(self, event: events.KeyEvent) -> None:
        """Handle remaining key-down actions after text input checks.

        Args:
            event: The key down event.

        """
        # Handle onion skinning keyboard shortcuts
        if event.key == pygame.K_o:
            self.log.debug('O key pressed - toggling global onion skinning')
            from .onion_skinning import get_onion_skinning_manager

            onion_manager = get_onion_skinning_manager()
            new_state = onion_manager.toggle_global_onion_skinning()
            self.log.debug('Onion skinning %s', 'enabled' if new_state else 'disabled')
            # Force canvas redraw to show/hide onion skinning
            if hasattr(self, 'canvas') and self.canvas:
                self.canvas.force_redraw()
            return

        # Handle undo/redo and Ctrl-based keyboard shortcuts
        mod = getattr(event, 'mod', 0)
        if self._handle_ctrl_key_shortcuts(event, mod):
            return

        # Handle slider mode navigation with arrow keys
        if self._slider_manager.is_any_controller_in_slider_mode():
            if event.key == pygame.K_UP:
                self.log.debug('UP arrow pressed - navigating to previous slider mode')
                self.controller_handler.handle_slider_mode_navigation('up')
            elif event.key == pygame.K_DOWN:
                self.log.debug('DOWN arrow pressed - navigating to next slider mode')
                self.controller_handler.handle_slider_mode_navigation('down')
            return

        # Handle animation navigation and film strip scrolling (UP/DOWN arrows)
        if self._handle_arrow_key_navigation(event):
            return

        # Route to canvas or parent (only if not in slider mode)
        if not self._slider_manager.is_any_controller_in_slider_mode():
            self._route_to_canvas_or_parent(event)

    def start_new_undo_history(self) -> None:
        """Forget the undo/redo history and any paint not yet recorded in it.

        Called when the canvas gets another sprite (a load, a new canvas): the history's steps,
        and paint collected but not yet submitted, belong to the sprite that was there, and
        applying them to the new one would write the old sprite's pixels and animations into it
        (BUGS.md #150).
        """
        self.undo_redo_manager.clear_history()
        self.current_pixel_changes = []
        self.current_pixel_changes_dict.clear()
        self.pixel_change_timer = None
        self.log.debug('Started a new undo history')

    def _finish_pan_gesture_in_progress(self) -> None:
        """Record a pan gesture still in progress (an arrow still held) before undo or redo.

        Undo or redo applied inside the gesture left the redo stack in place until the keys
        were released (BUGS.md #152). Finishing first makes the pan an undoable step of its
        own, which clears the redo stack as any new edit does; holding the arrow afterwards
        starts a new gesture.
        """
        canvas = getattr(self, 'canvas', None)
        if canvas and canvas.pan_session is not None:
            self._frame_operations.finish_canvas_panning()

    def handle_undo(self) -> None:
        """Handle undo operation."""
        if not hasattr(self, 'undo_redo_manager'):
            self.log.warning('Undo/redo manager not initialized')
            return

        self._finish_pan_gesture_in_progress()

        # Get current frame information
        current_animation = None
        current_frame = None
        if hasattr(self, 'canvas') and self.canvas:
            current_animation = getattr(self.canvas, 'current_animation', None)
            current_frame = getattr(self.canvas, 'current_frame', None)

        # Try frame-specific undo first if we have a current frame
        if current_animation is not None and current_frame is not None:
            if self.undo_redo_manager.can_undo_frame(current_animation, current_frame):
                success = self.undo_redo_manager.undo_frame(current_animation, current_frame)
                if success:
                    self.log.info(
                        'Frame-specific undo successful for %s[%s]',
                        current_animation,
                        current_frame,
                    )
                    # Force canvas redraw to show the undone changes (a current frame
                    # was read from the canvas above, so there is one)
                    self.canvas.force_redraw()
                    return
                self.log.warning(
                    'Frame-specific undo failed for %s[%s]',
                    current_animation,
                    current_frame,
                )
            else:
                self.log.warning('No frame-specific undo operations available')

        # Fall back to global undo for film strip operations
        if self.undo_redo_manager.can_undo():
            success = self.undo_redo_manager.undo()
            if success:
                self.log.info('Global undo successful')

                # CRITICAL: Ensure canvas state is valid after film strip operations
                self._synchronize_canvas_state_after_undo()

                # Force canvas redraw to show the undone changes
                if hasattr(self, 'canvas') and self.canvas:
                    self.canvas.force_redraw()
            else:
                self.log.warning('Global undo failed')
        else:
            self.log.debug('No operations available to undo')

    def _synchronize_canvas_state_after_undo(self) -> None:
        """Synchronize canvas state after undo operations to prevent invalid states.

        This method ensures that:
        1. The canvas is pointing to a valid animation
        2. The canvas is pointing to a valid frame index
        3. The canvas state is consistent with the current animation structure
        """
        if not hasattr(self, 'canvas') or not self.canvas:
            self.log.warning('No canvas available for state synchronization')
            return

        if not hasattr(self.canvas, 'animated_sprite') or not self.canvas.animated_sprite:
            self.log.warning('No animated sprite available for state synchronization')
            return

        animations = self.canvas.animated_sprite._animations  # type: ignore[reportPrivateUsage]
        current_animation = getattr(self.canvas, 'current_animation', None)
        current_frame = getattr(self.canvas, 'current_frame', None)

        self.log.debug(
            'Canvas state before sync: animation=%s, frame=%s',
            current_animation,
            current_frame,
        )
        self.log.debug('Available animations: %s', list(animations.keys()))

        # Check if current animation still exists
        if current_animation not in animations:
            self.log.warning(
                "Current animation '%s' no longer exists, switching to first available",
                current_animation,
            )
            if animations:
                # Switch to the first available animation
                first_animation = next(iter(animations.keys()))
                self.canvas.show_frame(first_animation, 0)
                self.log.info("Switched to animation '%s', frame 0", first_animation)
                return
            self.log.error('No animations available - this should not happen')
            return

        # Check if current frame index is valid
        frames = animations[current_animation]
        if current_frame is None or current_frame < 0 or current_frame >= len(frames):
            self.log.warning(
                "Current frame %s is invalid for animation '%s' with %s frames",
                current_frame,
                current_animation,
                len(frames),
            )
            # Switch to the last valid frame
            valid_frame = max(0, len(frames) - 1)
            self.canvas.show_frame(current_animation, valid_frame)
            self.log.info("Switched to frame %s of animation '%s'", valid_frame, current_animation)
            return

        # If we get here, the canvas state is valid
        self.log.debug(
            "Canvas state is valid: animation='%s', frame=%s",
            current_animation,
            current_frame,
        )

        # Force a complete canvas refresh to ensure everything is in sync
        self.canvas.force_redraw()

        # Update film strips to reflect the current state. Only the coordinator has this
        # method; the old hasattr(self, ...) guard was always False (BUGS.md #98)
        self.film_strip_coordinator.update_film_strips_for_frame(
            current_animation,
            current_frame,
        )

    def handle_redo(self) -> None:
        """Handle redo operation."""
        if not hasattr(self, 'undo_redo_manager'):
            self.log.warning('Undo/redo manager not initialized')
            return

        self._finish_pan_gesture_in_progress()

        # Get current frame information
        current_animation = None
        current_frame = None
        if hasattr(self, 'canvas') and self.canvas:
            current_animation = getattr(self.canvas, 'current_animation', None)
            current_frame = getattr(self.canvas, 'current_frame', None)

        # Try frame-specific redo first if we have a current frame
        if current_animation is not None and current_frame is not None:
            if self.undo_redo_manager.can_redo_frame(current_animation, current_frame):
                success = self.undo_redo_manager.redo_frame(current_animation, current_frame)
                if success:
                    self.log.info(
                        'Frame-specific redo successful for %s[%s]',
                        current_animation,
                        current_frame,
                    )
                    # Force canvas redraw to show the redone changes (a current frame
                    # was read from the canvas above, so there is one)
                    self.canvas.force_redraw()
                    return
                self.log.warning(
                    'Frame-specific redo failed for %s[%s]',
                    current_animation,
                    current_frame,
                )
            else:
                self.log.warning('No frame-specific redo operations available')

        # Fall back to global redo for film strip operations
        if self.undo_redo_manager.can_redo():
            success = self.undo_redo_manager.redo()
            if success:
                self.log.info('Global redo successful')

                # CRITICAL: Ensure canvas state is valid after film strip operations
                self._synchronize_canvas_state_after_undo()

                # Force canvas redraw to show the redone changes
                if hasattr(self, 'canvas') and self.canvas:
                    self.canvas.force_redraw()
            else:
                self.log.warning('Global redo failed')
        else:
            self.log.debug('No operations available to redo')

    @classmethod
    def args(cls, parser: argparse.ArgumentParser) -> None:
        """Add command line arguments.

        Args:
            parser (argparse.ArgumentParser): The argument parser.

        """
        # argparse's version action prints and exits; store_true did nothing (BUGS.md #178 item 25)
        parser.add_argument(
            '-v',
            '--version',
            action='version',
            version=f'{cls.NAME} {cls.VERSION}',
            help='print the game version and exit',
        )
        parser.add_argument(
            '-s',
            '--size',
            default='32x32',
            help='the canvas size in pixels, WIDTHxHEIGHT (default: 32x32)',
        )

    @override
    def _handle_scene_key_events(self, event: events.KeyEvent) -> None:
        """Handle scene-level key events."""
        self.log.debug('Scene-level key event: %s', event.key)

        # Call our custom keyboard handler
        self.on_key_down_event(event)

    @override
    def on_drop_file_event(self, event: events.DropFileEvent) -> None:
        """Handle drop file event by delegating to FileIOManager."""
        self._file_io.on_drop_file_event(event)

    def handle_event(self, event: events.HashableEvent) -> None:
        """Handle pygame events."""
        # Debug logging for keyboard events
        if event.type == pygame.KEYDOWN:
            self.log.debug('KEYDOWN event received in handle_event: key=%s', event.key)

        # Handle confirmation dialog clicks first (highest priority)
        if (
            event.type == pygame.MOUSEBUTTONDOWN
            and hasattr(self, 'confirmation_dialog')
            and self.confirmation_dialog
        ):
            mouse_position = current_input().mouse_position
            if self.confirmation_dialog.rect.collidepoint(mouse_position):
                # Convert to dialog-relative coordinates
                dialog_relative_pos = (
                    mouse_position[0] - self.confirmation_dialog.rect.x,
                    mouse_position[1] - self.confirmation_dialog.rect.y,
                )
                if self.confirmation_dialog.handle_mouse_down(dialog_relative_pos):
                    self.confirmation_dialog = None  # Clear reference after handling
                    return  # Event handled, don't pass to other handlers

        # No parent class defines handle_event (Scene receives events through its on_*_event
        # methods), so the old super().handle_event(event) fallback raised AttributeError for
        # every event the dialog did not take (BUGS.md #91). Nothing more to pass on here.

        if event.type == pygame.WINDOWLEAVE:
            # Notify sprites that mouse left window
            for sprite in self.all_sprites:
                if hasattr(sprite, 'on_mouse_leave_window_event'):
                    sprite.on_mouse_leave_window_event(event)

    # ──────────────────────────────────────────────────────────────────────
    # Film strip delegation (methods extracted to film_strip_coordinator.py)
    # These satisfy the EditorContext protocol so other subsystems can call them.
    # ──────────────────────────────────────────────────────────────────────

    def update_film_strip_visibility(self) -> None:
        """Delegate to FilmStripCoordinator."""
        self.film_strip_coordinator.update_film_strip_visibility()

    def update_scroll_arrows(self) -> None:
        """Delegate to FilmStripCoordinator."""
        self.film_strip_coordinator.update_scroll_arrows()

    def on_film_strip_frame_selected(
        self,
        film_strip_widget: FilmStripWidget,
        animation: str,
        frame: int,
    ) -> None:
        """Delegate to FilmStripCoordinator."""
        self.film_strip_coordinator.on_film_strip_frame_selected(
            film_strip_widget,
            animation,
            frame,
        )

    def update_film_strip_selection_state(self) -> None:
        """Delegate to FilmStripCoordinator."""
        self.film_strip_coordinator.update_film_strip_selection_state()

    def on_animation_rename(self, old_name: str, new_name: str) -> None:
        """Delegate to FilmStripCoordinator."""
        self.film_strip_coordinator.on_animation_rename(old_name, new_name)

    def scroll_film_strips_up(self) -> None:
        """Delegate to FilmStripCoordinator."""
        self.film_strip_coordinator.scroll_film_strips_up()

    def scroll_film_strips_down(self) -> None:
        """Delegate to FilmStripCoordinator."""
        self.film_strip_coordinator.scroll_film_strips_down()

    # ──────────────────────────────────────────────────────────────────────
    # Frame operation delegation (methods extracted to frame_operations.py)
    # animated_canvas.py calls _submit_pixel_changes_if_ready via parent_scene.
    # ──────────────────────────────────────────────────────────────────────

    def _submit_pixel_changes_if_ready(self) -> None:
        """Delegate to FrameOperationManager."""
        self._frame_operations.submit_pixel_changes_if_ready()

    # ──────────────────────────────────────────────────────────────────────
    # Color state methods (used by both keyboard and controller handlers)
    # ──────────────────────────────────────────────────────────────────────

    def get_current_color(self) -> tuple[int, int, int, int]:
        """Get the current color by delegating to SliderManager.

        Returns:
            tuple: The current (red, green, blue, alpha) color from the sliders.

        """
        return self._slider_manager.get_current_color()

    def apply_color(self, *, red: int, green: int, blue: int, alpha: int) -> None:
        """Set the editor's color (sliders, color well and canvas) via SliderManager."""
        self._slider_manager.apply_color(red=red, green=green, blue=blue, alpha=alpha)

    def set_onion_skin_transparency(self, transparency: float) -> None:
        """Set the global onion-skin translucency (0.0 transparent .. 1.0 opaque) and redraw.

        A MasterHUB fader drives this. It redraws the canvas so the new translucency shows at once,
        the way the 'O' toggle does.

        Args:
            transparency: The onion-skin translucency, 0.0 (transparent) to 1.0 (opaque).

        """
        from .onion_skinning import get_onion_skinning_manager

        get_onion_skinning_manager().set_transparency(transparency)
        self.canvas.force_redraw()

    # ──────────────────────────────────────────────────────────────────────
    # Controller event delegation (methods extracted to controllers/event_handler.py)
    # ──────────────────────────────────────────────────────────────────────

    @override
    def on_controller_button_down_event(self, event: events.ControllerButtonEvent) -> None:
        """Handle controller button down events by delegating to ControllerEventHandler."""
        self.controller_handler.on_controller_button_down_event(event)

    @override
    def on_controller_button_up_event(self, event: events.ControllerButtonEvent) -> None:
        """Handle controller button up events by delegating to ControllerEventHandler."""
        self.controller_handler.on_controller_button_up_event(event)

    @override
    def on_joy_button_down_event(self, event: events.JoyButtonEvent) -> None:
        """Handle joystick button down events by delegating to ControllerEventHandler."""
        self.controller_handler.on_joy_button_down_event(event)

    @override
    def on_joy_button_up_event(self, event: events.JoyButtonEvent) -> None:
        """Handle joystick button up events by delegating to ControllerEventHandler."""
        self.controller_handler.on_joy_button_up_event(event)

    @override
    def on_joy_hat_motion_event(self, event: events.JoyHatEvent) -> None:
        """Handle joystick hat motion events by delegating to ControllerEventHandler."""
        self.controller_handler.on_joy_hat_motion_event(event)

    @override
    def on_joy_axis_motion_event(self, event: events.JoyAxisEvent) -> None:
        """Handle joystick axis motion events by delegating to ControllerEventHandler."""
        self.controller_handler.on_joy_axis_motion_event(event)

    @override
    def on_joy_ball_motion_event(self, event: events.JoyBallEvent) -> None:
        """Handle joystick ball motion events by delegating to ControllerEventHandler."""
        self.controller_handler.on_joy_ball_motion_event(event)

    @override
    def on_controller_axis_motion_event(self, event: events.ControllerAxisEvent) -> None:
        """Handle controller axis motion events by delegating to ControllerEventHandler."""
        self.controller_handler.on_controller_axis_motion_event(event)


def main() -> None:
    """Run the main function.

    Raises:
        SystemExit: When the engine's run ends with one (a signal's ``ExitCode`` included).

    """
    # No logger level here: --log-level (default info) is the level, which shows the signal
    # lines below (BUGS.md #236)

    # SIGINT and SIGTERM end the editor through SystemExit with the signal's exit code
    # (INTERRUPTED, TERMINATED), the engine's own handler: it ignores a repeated signal while the
    # run tears down, and does nothing else (logging there could fail with "reentrant call
    # inside BufferedWriter" while the interrupted code writes to stderr, and a queue put could
    # block on a lock it holds). SystemExit unwinds the engine (releasing whatever the main
    # thread held); the finally below then logs and shuts the AI worker down. Installed before
    # the engine, which then leaves them alone (it claims only signals still at their default)
    signal.signal(signal.SIGINT, exit_on_signal)
    signal.signal(signal.SIGTERM, exit_on_signal)
    # The signal that ended the run, logged once the engine has stopped
    received_signals: list[int] = []

    # Set multiprocessing start method to avoid macOS issues
    with contextlib.suppress(RuntimeError):
        multiprocessing.set_start_method('spawn', force=True)

    icon_path = Path(__file__).parent / 'resources' / 'bitmappy.png'

    # Initialize the game engine first to set up display
    engine = GameEngine(game=BitmapEditorScene, icon=icon_path)

    # Load AI training data after engine initialization
    load_ai_training_data()

    # Start the engine
    try:
        engine.start()
    except SystemExit as exit_request:
        received_signals.extend(
            signal_number
            for signal_number in (signal.SIGINT, signal.SIGTERM)
            if exit_request.code == ExitCode.for_signal(signal_number)
        )
        raise
    finally:
        for received_signal in received_signals:
            LOG.info(f'Received signal {received_signal}, shutting down gracefully...')
        # A signal ends the engine with SystemExit, which skips the scenes' cleanup, so shut
        # the AI worker down here the way a normal quit does: send its shutdown message, join
        # with a timeout, terminate only if it does not exit (a no-op after a normal quit)
        shut_down_running_ai_workers()


if __name__ == '__main__':
    main()
